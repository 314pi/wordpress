<?php
if(!defined('ABSPATH')) die();
/**
 * User: shahnuralam
 * Date: 8/29/17
 * Time: 5:16 AM
 * Since: 4.6.9
 */

__( "Download Count" , "download-manager" );
__( "Version" , "download-manager" );
__( "Stock" , "download-manager" );
__( "File Size" , "download-manager" );
__( "File Type" , "download-manager" );
__( "File Count" , "download-manager" );
__( "Create Date" , "download-manager" );
__( "Last Updated" , "download-manager" );
__( "Title" , "download-manager" );
__( "Description" , "download-manager" );
__( "Package Info" , "download-manager" );
__( "Attached Files" , "download-manager" );
__( "Total Files" , "download-manager" );
__( "file(s)", "download-manager" );
__( "Buy Now", "download-manager" );
__( "Price", "download-manager" );