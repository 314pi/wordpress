<!-- WPDM Template: Terms in Modal Popup -->

<div class="row">
<div class="col-md-12">
[thumb_900x0]
</div>
    <div class="col-md-12"><br/>
<table class="table table-bordered">
<tbody>
<tr class="[hide_empty:verion]"><td>[txt=Version]</td><td>[version]</td></tr>
<tr class="[hide_empty:download_count]"><td>[txt=Download]</td><td>[download_count]</td></tr>
<tr class="[hide_empty:quota]"><td>[txt=Stock]</td><td>[quota]</td></tr>
<tr class="[hide_empty:file_size]"><td>[txt=File Size]</td><td>[file_size]</td></tr>
<tr class="[hide_empty:create_date]"><td>[txt=Create Date]</td><td>[create_date]</td></tr>
<tr><td colspan="2">[download_link]</td></tr>
</tr>
</tbody></table>
        </div>


<div class="col-md-12">
[description]



</div>
</div>
 
