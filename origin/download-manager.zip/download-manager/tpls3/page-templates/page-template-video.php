<!-- WPDM Template: Video Player -->

<div class="row">

    <div class="col-md-12">

     [video_player_800]

<ul class="list-group">
  <li class="list-group-item [hide_empty:version]">
    <span class="badge">[version]</span>
    [txt=Version]
  </li>
  <li class="list-group-item [hide_empty:download_count]">
    <span class="badge">[download_count]</span>
    [txt=Download]
  </li>
  <li class="list-group-item [hide_empty:file_size]">
    <span class="badge">[file_size]</span>
    [txt=File Size]
  </li>
  <li class="list-group-item [hide_empty:create_date]">
    <span class="badge">[create_date]</span>
    [txt=Create Date]
  </li>
  <li class="list-group-item [hide_empty:download_link_extended]">
    [download_link_extended]
  </li>
</ul>
        </div>


<div class="col-md-12">
[description]



</div>
</div>
