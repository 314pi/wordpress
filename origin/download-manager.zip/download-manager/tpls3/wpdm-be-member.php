<?php
if (!defined('ABSPATH')) die();

echo WPDM()->shortCode->loginForm();

?>


