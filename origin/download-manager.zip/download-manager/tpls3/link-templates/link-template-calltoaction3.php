<!-- WPDM Link Template: Call to Action -->

<div class="wpdm-link-template well c2a3">
    <div class="media">
        <div class="pull-left" align="left">
            [icon]
        </div>
        <div class="pull-right" align="right">
            [download_link]
        </div>

        <div class="media-body">
            <h2 class="package-title"><a href="[page_url]">[title]</a> <span style="margin-left:30px;font-size:8pt;font-weight:300"><i style="margin: 2px 0 0 5px;" class="far fa-hdd color-green"></i> [file_size] <i style="margin: 2px 0 0 5px;" class="far fa-arrow-alt-circle-down color-purple"></i> [download_count] downloads</span></h2>
            [excerpt_40]
        </div>

    </div>

</div>
