<!-- WPDM Link Template: Default Template -->


<div class="wpdm-link-template link-template-default thumbnail" >

    <div class="media" style="display: flex">
        <div class="pull-left">[icon]</div>
        <div class="media-body"><h3 class="package-title">[title]</h3>
            <small class="text-muted"><i class="fas fa-copy"></i> [file_count] [txt=file(s)] &nbsp; <i class="fas fa-hdd"></i> [file_size]</small>
        </div>
        <div>
            [download_link]
        </div>
    </div>

</div>
<div style="clear: both"></div>

