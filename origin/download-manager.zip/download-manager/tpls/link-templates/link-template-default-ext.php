<!-- WPDM Link Template: Default Template (Extended) -->

<div class="card card-default">
    <div class="card-body">

    <div class="media">
        <div class="mr-3">[icon]</div>
        <div class="media-body"><h3 class="ptitle m-0 p-0">[title]</h3>
            [description]
            <div><strong>[download_link_extended]</strong></div>
        </div>
    </div>


    </div>
    <div class="card-footer"><span class="pull-right">[download_count] downloads</span>[file_size]</div>
</div>
