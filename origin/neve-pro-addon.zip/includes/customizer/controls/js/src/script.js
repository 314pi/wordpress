import initializeRepeater from './repeater.js'

document.addEventListener('DOMContentLoaded', function () {
  initializeRepeater()
})
