<?php
/*
Plugin Name: WPDM - The Movie Database
Description: The Movie Database
Plugin URI: http://www.wpdownloadmanager.com/
Author: Shaon
Version: 1.0.0
Author URI: http://www.wpdownloadmanager.com/
Text Domain: wpdm-tmdb
*/

namespace WPDM\AddOn;


use WPDM\Package;

if (!defined('ABSPATH')) die();

include_once dirname(__FILE__) . '/tmdb-api.php';

// https://www.themoviedb.org/settings/api
// https://github.com/pixelead0/tmdb_v3-PHP-API-

class MovieDB
{
    function __construct()
    {

        $this->settingsTabs();
        $this->addMetaBox();

        add_action('wp_ajax_wpdm_tmdb_search', array($this, 'search'));
        add_action('wp_ajax_wpdm_tmdb_add_movie', array($this, 'add'));
    }

    function settingsTabs()
    {
        add_filter('add_wpdm_settings_tab', array($this, 'addTabs'));
    }

    function addTabs($tabs)
    {
        $tabs['tmdb'] = \WPDM\admin\menus\Settings::createMenu('tmdb', 'Movie DB', array($this, 'tabPage'), 'fas fa-film');
        return $tabs;
    }

    function tabPage()
    {

        if (isset($_POST['section']) && $_POST['section'] == 'tmdb' && wpdm_query_var('task') === 'wdm_save_settings' && is_admin()) {
            //Save Settings
            _e('Nothing To Save! Click Search Button To Search Movies');
            die();
        }
        include dirname(__FILE__) . '/tpls/search-movies.php';
    }

    function search()
    {
        $tmdb = new \TMDB();
        $tmdb->setAPIKey('53698563d2f0933751671f2db5deff6f');
        $title = wpdm_query_var('strm');
        $movies = $tmdb->searchMovie($title);
        foreach ($movies as $movie) {
            $poster = $movie->getPoster();
            if ($poster) {
                $res[] = array(
                    'name' => $movie->getTitle(),
                    'poster' => "https://image.tmdb.org/t/p/w1280" . $poster,
                    'id' => $movie->getID(),
                    //'overview' => $movie->getOverview(),
                    //'original_name' => $movie->getOriginalName()
                );
            }
        }
        wp_send_json($res);
        die();
    }

    function add()
    {
        $tmdb = new \TMDB();
        $tmdb->setAPIKey('53698563d2f0933751671f2db5deff6f');
        $id = wpdm_query_var('id');
        $movie = $tmdb->getMovie($id);
        $cp = get_page_by_title($movie->getTitle(), OBJECT, 'wpdmpro');
        if($cp) $data['ID'] = $cp->ID;
        $data['post_title'] = $movie->getTitle();
        $data['post_excerpt'] = $movie->getTagline();
        $data['import_id'] = $movie->getID();
        $data['access'] = array('guest');
        $data['package_type'] = 'movie';
        $data['featured_image'] = "https://image.tmdb.org/t/p/w1280" . $movie->getPoster();
        $movieid = Package::create($data);

        $genres = $movie->getGenres();
        foreach ($genres as $genre){
            $term = get_term_by('name', $genre->getName(), 'wpdmcategory');

            if(!$term) {
                $term = wp_insert_term($genre->getName(), 'wpdmcategory');
            }

            wp_set_post_terms($movieid, array($term->term_id), 'wpdmcategory');

        }

        update_post_meta($movieid, '__wpdm_tmdb_trailer', $movie->getTrailer());
        update_post_meta($movieid, '__wpdmtmdb_movieid', $movie->getID());
        update_post_meta($movieid, '__wpdm_tmdb_rating', $movie->getVoteAverage());
        update_post_meta($movieid, '__tmdb_movie', $movie->get());


        $_upload_dir = wp_upload_dir();
        $upload_url = $_upload_dir['baseurl'] . '/wpdm-tmdb/casts/';
        $upload_dir = $_upload_dir['basedir'] . '/wpdm-tmdb/casts/';
        $backdrop_dir = $_upload_dir['basedir'] . '/wpdm-tmdb/backdrops/';
        if (!file_exists($upload_dir)) mkdir($upload_dir, 0755, 1);
        if (!file_exists($backdrop_dir)) mkdir($backdrop_dir, 0755, 1);

        $movie = $movie->get();

        update_post_meta($movieid, '__wpdm_tmdb_year', date("Y", strtotime($movie['release_date'])));


        $backdrop = "https://image.tmdb.org/t/p/w1280{$movie['backdrop_path']}";
        $filename = $id . ".jpg";
        $filepath = \WPDM\libs\FileSystem::copyURL($backdrop, $filename, false);
        rename($filepath, $backdrop_dir . $filename);
        $backdropurl = $_upload_dir['baseurl'] . '/wpdm-tmdb/backdrops/' . $filename;
        update_post_meta($movieid, '__tmdb_backdrop', $backdropurl);

        foreach ($movie['credits']['cast'] as $char) {
            if ($char['profile_path'] != '') {
                $filename = sanitize_file_name($char['name']) . '.jpg';
                if (!file_exists($upload_dir . $filename)) {
                    $filepath = \WPDM\libs\FileSystem::copyURL("https://image.tmdb.org/t/p/w1280" . $char['profile_path'], $filename, false);
                    rename($filepath, $upload_dir . $filename);
                }
            }
        }
        die('ok');
    }

    function addMetaBox()
    {
        add_filter('wpdm_meta_box', array($this, 'metaBoxes'));
    }

    function metaBoxes($metaboxes)
    {
        $meta_box['title'] = 'Movie Info';
        $meta_box['callback'] = array($this, 'metaBoxContent');
        $metaboxes['movie-info'] = $meta_box;
        return $metaboxes;
    }

    function metaBoxContent($post)
    {
        $pid = is_object($post)?$post->ID:0;
        include dirname(__FILE__).'/tpls/movie-info.php';
    }


}

new MovieDB();

