<?php
/**
 * User: shahnuralam
 * Date: 6/23/18
 * Time: 12:00 AM
 */
if (!defined('ABSPATH')) die();
?>
<div class="panel panel-default">
    <div class="panel-heading">
        <span id="tmdb-busy" class="pull-right" style="display: none"><i class="fas fa-sun fa-spin"></i> <?php _e('Processing...', 'wpdm-tmdb'); ?></span>
        <?php _e('Search Movies', 'wpdm-tmdb'); ?>
    </div>
    <div class="panel-body" style="padding: 30px">
        <div class="input-group input-group-lg">
            <input id="tmdmsrc" type="search" class="form-control" />
            <span class="input-group-btn"><button type="button" id="tmdmsrcbtn" style="border-radius: 0 3px 3px 0" class="btn btn-default"><i class="fas fa-search"></i></button></span>
        </div>
        <br/>
        <div id="tmdbres">

        </div>
    </div>
</div>
<style>
    #tmdbres  img{
        max-width: 100%;
        height: 250px;
    }
    #tmdbres .panel-default .panel-body .overlay a{
        color: #ffffff !important;
    }
    #tmdbres .panel-default .panel-body .overlay{
        background: rgba(0,0,0,0.5);
        position: absolute;
        width: calc(100% - 30px);
        height: calc(100% - 30px);
        display: none;
        line-height: 250px;
        text-align: center;
        font-size: 28pt;
        -webkit-transition: ease-in-out 400ms;
        -moz-transition: ease-in-out 400ms;
        -ms-transition: ease-in-out 400ms;
        -o-transition: ease-in-out 400ms;
        transition: ease-in-out 400ms;
    }
    #tmdbres .panel-default .panel-body:hover .overlay{
        display: block;
        -webkit-transition: ease-in-out 400ms;
        -moz-transition: ease-in-out 400ms;
        -ms-transition: ease-in-out 400ms;
        -o-transition: ease-in-out 400ms;
        transition: ease-in-out 400ms;
    }
    #tmdbres .panel-default .panel-body{
        position: relative;
    }
    #tmdbres .panel-default{
        border-radius: 4px !important;
    }
    #tmdbres .panel-footer{
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
<script>
    jQuery(function ($) {
        $('#tmdmsrcbtn').click(function (e) {
            e.preventDefault();
            var strm = $('#tmdmsrc').val();
            $('#tmdmsrcbtn .fas').removeClass('fa-search').addClass('fa-sun fa-spin');
            $.get(ajaxurl, {action: 'wpdm_tmdb_search', strm: strm}, function (res) {
                //$('#tmdbres').html(res);
                var html  ="<div class='row'>";
                $.each(res, function (id, movie) {
                    html += "<div class='col-md-4'><div class='panel panel-default'><div class='panel-body'><div class=\"overlay\"><a href=\"#\" class='add-movie' rel='"+movie.id+"'><i class=\"fas fa-plus-square\"></i></a></div><img src='"+movie.poster+"' /></div><div class='panel-footer'>"+movie.name+"</div></div></div>";
                });
                html += "</div>";
                $('#tmdbres').html(html);
                $('#tmdmsrcbtn .fas').removeClass('fa-sun fa-spin').addClass('fa-search');
            });
        });

        $('body').unbind('.add-movie');
        $('body').on('click', '.add-movie', function (e) {
            e.preventDefault();
            e.stopImmediatePropagation();
            $('#tmdb-busy').fadeIn();
            $('#wpdm_message').hide();
            var $this = $(this);
            $this.find('.fas').removeClass('fa-plus-square').addClass('fa-sun fa-spin');
            $.get(ajaxurl, {action: 'wpdm_tmdb_add_movie', id: $(this).attr('rel')},function (res) {
                $('#wpdm_message').html('<?php _e('Movie Added Successfully', 'wpdm-tmdb'); ?>').show();
                $('#tmdb-busy').fadeOut();
                $this.find('.fas').removeClass('fa-sun fa-spin').addClass('fa-check-square');
            });
        });
    });
</script>
