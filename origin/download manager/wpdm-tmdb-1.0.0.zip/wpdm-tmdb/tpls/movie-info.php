<?php
/**
 * User: shahnuralam
 * Date: 6/23/18
 * Time: 2:55 AM
 */
if (!defined('ABSPATH')) die();
//wpdmprecho(get_post_meta($pid, '__tmdb_movie', true));
?>
<div class="w3eden">

    <div class="form-group">
        <label><?php _e('Torrent URL', 'wpdm-tmdb'); ?></label>
        <input type="text" name="file[tmdb_torrent]" class="form-control" value="<?php echo get_post_meta($pid, '__wpdm_tmdb_torrent', true); ?>">
        <em class="note"><?php _e('YouTube video ID', 'wpdm-tmdb'); ?></em>
    </div>
    <div class="form-group">
        <label><?php _e('Trailer', 'wpdm-tmdb'); ?></label>
        <input type="text" name="file[tmdb_trailer]" class="form-control" value="<?php echo get_post_meta($pid, '__wpdm_tmdb_trailer', true); ?>">
        <em class="note"><?php _e('YouTube video ID', 'wpdm-tmdb'); ?></em>
    </div>
    <div class="form-group">
        <label><?php _e('Average Rating', 'wpdm-tmdb'); ?></label>
        <input type="text" name="file[tmdb_rating]" class="form-control" value="<?php echo get_post_meta($pid, '__wpdm_tmdb_rating', true); ?>">
    </div>
    <div class="form-group">
        <label><?php _e('Release Year', 'wpdm-tmdb'); ?></label>
        <input type="text" name="file[tmdb_rating]" class="form-control" value="<?php echo get_post_meta($pid, '__wpdm_tmdb_year', true); ?>">
    </div>

</div>
