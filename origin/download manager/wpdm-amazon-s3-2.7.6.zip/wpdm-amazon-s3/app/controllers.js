var accessKey = '', secretKey = '';
jQuery(function ($) {
    $.get(ajaxurl+'?action=awsAccess', function (res) {
        accessKey = res.access;
        secretKey = res.secret;
    });
    $('#bucketlist').load(ajaxurl+'?action=awsBuckets');
    window.localStorage.setItem('current_bucket', '');
    window.localStorage.setItem('current_prefix', '');

    $('body').on('click', '.explore-bucket', function (e) {
        e.preventDefault();
        $('.explore-bucket').removeClass('bselected');
        $(this).addClass('bselected');
        window.localStorage.setItem('current_bucket', $(this).data('bucket'));
        window.localStorage.setItem('current_prefix', '');
        $('#ngloading').fadeIn();
        $('#contentarea').load(ajaxurl+"?action=exploreBucket&region="+$(this).data('region')+"&bucket="+encodeURIComponent($(this).data('bucket')), function () {
            $('#ngloading').fadeOut();
        });
        
    });
    $('body').on('click', '.explore-object', function (e) {
        e.preventDefault();
        $('#ngloading').fadeIn();
        window.localStorage.setItem('current_bucket', $(this).data('bucket'));
        window.localStorage.setItem('current_prefix', $(this).data('prefix'));
        $('#contentarea').load(ajaxurl+"?action=exploreObject&region="+$(this).data('region')+"&bucket="+$(this).data('bucket')+"&prefix="+encodeURIComponent($(this).data('prefix')), function () {
            $('#ngloading').fadeOut();
        });

    });

    $('#create-bucket').click(function () {
        $('.acthtml').hide();
        $('#cbhtml').show();
        $('#awsModal .modal-title').html('Create Bucket');
        $('#awsModal').modal('show');
        $('#cbmsg').html('');
    });

    $('#create-folder').click(function () {
        $('.acthtml').hide();
        $('#cfhtml').show();
        $('#awsModal .modal-title').html('Create Folder');
        $('#awsModal').modal('show');
        $('#flmsg').html('');
    });

    $('#upload-file').click(function () {
        $('.acthtml').hide();
        $('#ufhtml').show();
        $('#awsModal .modal-title').html('Upload File');
        $('#awsModal').modal('show');
        $('#ufmsg').html('');
    });


    $('#cbbtn').on('click', function () {
        var bucketname = $('#bktname').val();
        $('#cbmsg').html('<i class="fa fa-spinner fa-spin"></i> Please Wait...');
        $.post(ajaxurl, {bucketname: bucketname, action: 'CreateBucket'}, function (res) {
            if(res == 'Done!') {
                res = 'Created Successfully! Refreshing Bucket List...';
                $('#cbmsg').html(res);
                $('#bucketlist').load(ajaxurl+'?action=awsBuckets', function () {
                    $('#awsModal').modal('hide');
                    $('#cbmsg').html('');
                });
            }
            $('#cbmsg').html(res);
        });
    });


    $('#flbtn').on('click', function () {

        $('#flmsg').html('<i class="fa fa-spinner fa-spin"></i> Please Wait...');
        var foldername = $('#fldname').val();
        var bucketname = window.localStorage.getItem('current_bucket') || '';
        var prefix = window.localStorage.getItem('current_prefix') || '';

        if(bucketname == ''){
            $('#flmsg').html('Select a bucket first from bucket menu').show();
            return false;
        }
        $('#cbmsg').html('<i class="fa fa-spinner fa-spin"></i> Please Wait...');
        $.post(ajaxurl, {bucket: bucketname,prefix: prefix,folder: foldername, action: 'createObject'}, function (res) {
            if(res == 'Done!') {
                res = 'Created Successfully! Refreshing Folder List...';
                $('#flmsg').html(res);
                if(prefix != '')
                    var command = ajaxurl+"?action=exploreObject&bucket="+bucketname+"&prefix="+encodeURIComponent(prefix);
                else
                    var command = ajaxurl+"?action=exploreBucket&bucket="+bucketname;
                $('#contentarea').load(command, function () {
                    $('#awsModal').modal('hide');
                    $('#flmsg').html('');
                });
            }
            $('#cbmsg').html(res);
        });
    });

    $('#uploadform').submit(function (e) {
        e.preventDefault();
        AWS.config.update({
            accessKeyId : accessKey,
            secretAccessKey : secretKey
        });
        //AWS.config.region = 'us-standard';

        var bucketname = window.localStorage.getItem('current_bucket') || '';
        var prefix = window.localStorage.getItem('current_prefix') || '';

        if(bucketname == ''){
            $('#ufmsg').html("<span class='text-danger'><i class='fa fa-warning'></i> Select a bucket first from bucket menu").show();
            return false;
        }

        var bucket = new AWS.S3({params: {Bucket: bucketname}});
        var fileChooser = document.getElementById('ufile');
        var file = fileChooser.files[0];
        console.log(file);

        if (file) {
            var params = {Key: file.name, ContentType: file.type, Body: file};
            bucket.upload(params).on('httpUploadProgress', function(evt) {
                $('#ufmsg').html("<span class='text-info'><i class='fa fa-spinner fa-spin'></i> Uploaded :: " + parseInt((evt.loaded * 100) / evt.total)+'%</span>');
            }).send(function(err, data) {
                $('#ufmsg').html("<span class='text-success'><i class='fa fa-check-circle'></i> Completed Successfully. Refreshing...</span>");
                if(prefix != '')
                    var command = ajaxurl+"?action=exploreObject&bucket="+bucketname+"&prefix="+prefix;
                else
                    var command = ajaxurl+"?action=exploreBucket&bucket="+bucketname;
                $('#contentarea').load(command, function () {
                    $('#awsModal').modal('hide');
                    $('#ufmsg').html('');
                });
            });
        } else{
            $('#ufmsg').html("<span class='text-danger'><i class='fa fa-warning'></i> No file selected</span>");
        }
        return false;

    });

    $('.btn-file :file').on('fileselect', function(event, numFiles, label) {

        var input = $(this).parents('.input-group').find(':text'),
            log = numFiles > 1 ? numFiles + ' files selected' : label;

        if( input.length ) {
            input.val(log);
        } else {
            if( log ) alert(log);
        }

    });

    $(document).on('change', '.btn-file :file', function() {
        var input = $(this),
            numFiles = input.get(0).files ? input.get(0).files.length : 1,
            label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [numFiles, label]);
    });

});




