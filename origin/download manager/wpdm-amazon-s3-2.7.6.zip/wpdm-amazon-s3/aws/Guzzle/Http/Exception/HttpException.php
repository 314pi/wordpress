<?php

namespace Guzzle\Http\Exception;

use Guzzle\Common\Exception\GuzzleException;

/**
 * Http exception interface
 */
interface HttpException extends GuzzleException {}
