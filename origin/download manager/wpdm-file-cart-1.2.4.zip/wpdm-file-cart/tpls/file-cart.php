
<div id="file-cart" class="w3eden">

    <div class="alert alert-info"><?php _e('Loading File Cart....','file-cart'); ?></div>

</div>

<?php
if(class_exists('WPDM_FormLock') && get_option('__wpdm_file_cart_form', 0) !== '0'){
    $fcf = get_option('__wpdm_file_cart_form', '');
    $fcf = explode("|", $fcf);
    do_action("wpdm_filecart_{$fcf[0]}_html", $fcf[1]);

}
?>

<script>
    jQuery(function($){

        var fc_tmp_data = localStorage.getItem('file_cart_data');
        var file_cart_data;
        try{
            file_cart_data = JSON.parse(fc_tmp_data);
        } catch(e){
            file_cart_data = {};
        }

        $.post("<?php echo admin_url('admin-ajax.php'); ?>", {action:'file_cart', data: file_cart_data}, function(res){
            $('#file-cart').html(res);
        });


    });
</script>

