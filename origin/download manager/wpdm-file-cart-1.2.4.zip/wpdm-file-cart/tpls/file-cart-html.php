

    <ul class="list-group file-cart-list">
    <?php
    $cart_data = isset($_POST['data'])?$_POST['data']:array();
    $_SESSION['file_cart_data'] = $cart_data;
    if(is_array($cart_data) && count($cart_data) > 0){
    foreach($cart_data as $key => $file){
        $skey = explode("_", $key);
        $pid = $skey[0];
        $file_index = $skey[1];
        $package = get_post($pid);
        $pfiles = \WPDM\Package::getFiles($pid);
        $file = isset($pfiles[$file])?$pfiles[$file]:\WPDM\libs\Crypt::Decrypt($file);
        $fileinfo = get_post_meta($pid, '__wpdm_fileinfo', true);
        ?>

        <li class="list-group-item" id="li_<?php echo $key; ?>">
            <h3 style="margin: 0"><button class="btn btn-danger btn-xs pull-right btn-remove-item" data-index="<?php echo $key; ?>"><i class="far fa-trash-alt"></i></button>
                <?php echo isset($fileinfo[$file])?$fileinfo[$file]['title']:''; ?><?php echo basename($file); ?></h3>
            <small><em><a href="<?php echo get_permalink($pid); ?>"><?php echo $package->post_title; ?></a></em></small>

        </li>



        <?php
    }} else {
        echo '<li class="list-group-item">'.__('File cart is empty','file-cart').'</li>';
    }
    ?>
    </ul>
<?php if(!class_exists('WPDM_FormLock') || get_option('__wpdm_file_cart_form', 0) === '0'){ ?>
    <div class="well">
        <div class="input-group">
            <span class="input-group-addon"><i id="fae" class="fa fa-envelope"></i></span>
            <input class="form-control group-item" id="cmail" placeholder="Email Address" type="email">
            <span class="input-group-btn">
            <button id="email-file-cart" style="width:180px" type="button" class="btn btn-primary">Email This Cart</button>
        </span>
        </div>
    </div>
   <?php } ?>

<?php

    if(is_array($cart_data) && count($cart_data) > 0) {
        if(class_exists('WPDM_FormLock') && get_option('__wpdm_file_cart_form', 0) !== '0'){


        } else { ?>



    <button class="btn btn-primary" id="download-file-cart"><i class="fa fa-download"></i> &nbsp; <?php _e('Download','file-cart'); ?></button>
            <?php } ?>
    <!-- button class="btn btn-info"><i class="fa fa-floppy-o"></i>  &nbsp; <?php _e('Save as Custom Package','file-cart'); ?></button -->
    <button class="btn btn-danger pull-right" id="btn-empty-fc"><i class="fa fa-trash-o"></i> &nbsp; <?php _e('Empty Cart','file-cart'); ?></button>

<?php } ?>
<div class="clear"><br/></div>
<style>
    .w3eden .file-cart-list .list-group-item:not(:first-child){
        border-top: 1px solid #ddd !important;
    }
    .w3eden .file-cart-list{
        margin: 0 0 15px 0 !important;
        padding: 0 !important;
    }
    .w3eden .file-cart-list li{
        margin-left: 0;
        font-size: 10pt;
    }
    .w3eden .dashboard-panel .file-cart-list h3{
        margin: 0;
        padding: 0;
        font-weight: 800;
        font-size: 11pt;
    }
    .w3eden .file-cart-list li em a{
        font-style: italic;
        color: #ccc;
    }
</style>
<script>

    function fc_remove_item(index){
        var fc_tmp_data = localStorage.getItem('file_cart_data');
        var new_file_cart_data = {};
        var file_cart_data;
        try{
            file_cart_data = JSON.parse(fc_tmp_data);
        } catch(e){
            file_cart_data = {};
        }
        jQuery.each(file_cart_data, function(k, v){
            if(k!=index){
                new_file_cart_data[k] = v;
            }
        });
        //console.log(new_file_cart_data);
        localStorage.setItem('file_cart_data', JSON.stringify(new_file_cart_data));
    }

    jQuery(function($){

        var fc_tmp_data = localStorage.getItem('file_cart_data');
        var file_cart_data;
        try{
            file_cart_data = JSON.parse(fc_tmp_data);
        } catch(e){
            file_cart_data = {};
        }

        $('body').on('click', '#download-file-cart', function(){

            $(this).find('.fa').removeClass('fa-download fa-check-circle-o').addClass('fa-spin fa-refresh');
            $.post("<?php echo admin_url('admin-ajax.php'); ?>", {action:'file_cart_download', data: file_cart_data}, function(response, status, xhr){
                var tmp = response.split("||");
                var fileid = tmp[1];
                location.href = "<?php echo home_url('/'); ?>?wpdmcustompack="+fileid;
                $('#download-file-cart .fa').removeClass('fa-spin fa-refresh').addClass('fa-check-circle-o');

            });
        });

        $('.btn-remove-item').on('click', function(){
            if(!confirm('Are you sure?')) return false;
            fc_remove_item($(this).data('index'));
            $("#li_"+$(this).data('index')).slideUp();

            var fc_tmp_data = localStorage.getItem('file_cart_data');
            var file_cart_data;
            try{
                file_cart_data = JSON.parse(fc_tmp_data);
            } catch(e){
                file_cart_data = {};
            }
            $.post("<?php echo admin_url('admin-ajax.php'); ?>", {action:'file_cart', data: file_cart_data}, function(res){
            });
        });

        $('#btn-empty-fc').on('click', function(){
            if(!confirm('Are you sure?')) return false;
            localStorage.setItem('file_cart_data', null);
            $('.file-cart-list').slideUp(function(){
                $('#file-cart').html('');
            });
        });

        $('body').on('click', '#email-file-cart', function(){
            $('#fae').removeClass('fa-envelope').addClass('fa-spinner fa-spin');
            $('#email-cart').attr('disabled','disabled').html('Sending...');
            $.post("<?php echo admin_url('admin-ajax.php'); ?>", { action:'email_file_cart', data: file_cart_data, email: $('#cmail').val() }, function(response, status, xhr){
                $('#fae').removeClass('fa-spinner fa-spin').addClass('fa-envelope');
                if(response === 'sent')
                    $('#email-file-cart').html('Email Sent');
                else
                    $('#email-file-cart').html(response);
            });

    });

    });

</script>