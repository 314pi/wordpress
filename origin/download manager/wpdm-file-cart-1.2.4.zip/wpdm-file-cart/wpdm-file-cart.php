<?php
/*
Plugin Name: WPDM - File Cart
Description: WPDM - File Cart helps your to choose random files from different package and download those as a custom pack
Plugin URI: https://www.wpdownloadmanager.com/download/wpdm-file-cart/
Author: Shaon
Version: 1.2.4
Author URI: https://www.wpdownloadmanager.com/
*/

if (defined('WPDM_Version')) {


    if (!defined('WPDM_CLOUD_STORAGE'))
        define('WPDM_CLOUD_STORAGE', 1);

    if(!isset($_SESSION)) session_start();

    class WPDM_FileCart
    {
        function __construct()
        {

            add_action('individual_file_action', array($this, 'IndividualFileAction'), 10, 4);
            add_action('wp_footer', array($this, 'AddToFileCartJS'));
            add_action('wp_ajax_nopriv_file_cart', array($this, 'FileCartHTML'));
            add_action('wp_ajax_file_cart', array($this, 'FileCartHTML'));
            add_shortcode('wpdm_file_cart', array($this, 'FileCart'));
            add_action('wp_ajax_file_cart_download', array($this, 'FileCartPrepareDownload'));
            add_action('wp_ajax_nopriv_file_cart_download', array($this, 'FileCartPrepareDownload'));

            add_action('wp_ajax_email_file_cart', array($this, 'EmailFileCart'));
            add_action('wp_ajax_nopriv_email_file_cart', array($this, 'EmailFileCart'));

            add_action('wp', array($this, 'FileCartDownload'));
            add_action('wp', array($this, 'FileCartDownloadEmailLink'));
            add_action('basic_settings_section', array($this, 'formLock'));

            add_filter("wpdm_user_dashboard_menu", array($this, 'DashboardMenu'));

            add_filter( 'wpdm_after_prepare_package_data', array( $this, 'templateTag' ) );
            add_filter( 'wdm_before_fetch_template', array( $this, 'templateTag' ) );

        }

        function DashboardMenu($items){
            $items = array_merge(array_splice($items,0,1),array('file-cart' => array('name' => 'File Cart', 'shortcode' => '[wpdm_file_cart]')), $items);
            return $items;
        }



        function AddToFileCartJS(){
            $pageid = get_option('__wpdm_file_cart_pageid', false);
            if(!$pageid) return false;
            $cart_url = get_permalink($pageid);
            $title = get_the_title($pageid);
            ?>

            <div class="w3eden" style="position: fixed;z-index: 9999;top: 150px;right: -50px;transform:rotate(-90deg)"><div class="btn-group"><a href="<?php echo $cart_url; ?>" class="btn btn-primary btn-simple btn-sm"><i class="fas fa-copy"></i> <?php  echo $title; ?></a><div id="fcount" class="btn btn-default btn-sm btn-simple"></div></div></div>
            <script>

                jQuery(function($){

                    function fcinit(){
                        var fc_tmp_data = localStorage.getItem('file_cart_data');
                        var file_cart_data = {};
                        try{
                            file_cart_data = JSON.parse(fc_tmp_data);
                            if(file_cart_data == null) file_cart_data = {};
                        } catch(e){
                            file_cart_data = {};
                        }
                        var count = Object.keys(file_cart_data).length;
                        $('#fcount').html(count+" files");
                    }

                    fcinit();

                    $('.btn-addtfc').on('click', function(){
                        var fc_tmp_data = localStorage.getItem('file_cart_data');
                        var file_cart_data;
                        try{
                            file_cart_data = JSON.parse(fc_tmp_data);
                            if(file_cart_data == null) file_cart_data = {};
                        } catch(e){
                            file_cart_data = {};
                        }
                        var pid = $(this).data('pid');
                        var fileindex = $(this).data('fileindex');
                        var index = pid+"_"+fileindex;
                        file_cart_data[index] = $(this).data('file');
                        var count = file_cart_data.length;
                        $('#fcount').html(count+" files");
                        localStorage.setItem('file_cart_data', JSON.stringify(file_cart_data));
                        $(this).attr('disabled', 'disabled').html('<i class="fa fa-check"></i>');
                        $(this).next('.tooltip').remove();
                        fcinit();
                    });

                });

            </script>

            <?php
        }

        function IndividualFileAction($data, $package_id, $file, $file_index){
            //$file =  WPDM_Crypt::Encrypt($file);
            $data .= "<button title='Add To File Cart' data-placement='right'  class='ttip btn btn-sm btn-info btn-addtfc' data-pid='{$package_id}' data-fileindex='{$file_index}' data-file='{$file_index}'><i class='fa fa-plus'></i></button>";
            return $data;
        }


        function FileCart()
        {
            ob_start();
            include(wpdm_tpl_path("file-cart.php", dirname(__FILE__).'/tpls/'));
            return ob_get_clean();
        }

        function FileCartHTML(){
            include(wpdm_tpl_path("file-cart-html.php", dirname(__FILE__).'/tpls/'));
            die();
        }

        static function FileCartURL(){
            $pageid = get_option('__wpdm_file_cart_pageid', false);
            if(!$pageid) return false;
            $cart_url = get_permalink($pageid);
            return $cart_url;
        }

        function FileCartPrepareDownload()
        {
            $cart_data = $_POST['data'];
            $files = array();
            if (is_array($cart_data)) {
                foreach ($cart_data as $key => $file) {
                    $key = explode("_", $key);
                    $pid = $key[0];
                    $file_index = $key[1];
                    $package = get_post($pid);
                    $pfiles = maybe_unserialize(get_post_meta($pid, "__wpdm_files", true));
                    $dir = get_post_meta($pid, '__wpdm_package_dir', true);

                    if($dir != ''){
                        $dfiles = wpdm_get_files($dir);
                        foreach($dfiles as $fd){
                            $pfiles[] = $fd;
                        }
                    }
                    //$file = WPDM_Crypt::Decrypt($file);
                    //echo "<pre>".print_r($pfiles,1)."</pre>";
                    //if (in_array($file, $pfiles))
                        $files[] = $pfiles[$file];
                }
            }
            $zipname = isset($_POST['zipname']) && $_POST['zipname'] != '' ? $_POST['zipname'] : 'custom-pack';
            $ip = str_replace(".", "-", $_SERVER['REMOTE_ADDR']);
            $zipped = wpdm_zip_files($files, $zipname . "-" . $ip);
            $uniqid = uniqid();
            $_SESSION[$uniqid] = $zipped;
            die("||".$uniqid."||");
        }

        function FileCartDownload(){
            if(!isset($_GET['wpdmcustompack'])) return;
            $sid = $_GET['wpdmcustompack'];
            if(!isset($_SESSION[$sid])) wpdm_download_data("something-wrong.txt", "Session Error!");
            $zipped = $_SESSION[$sid];
            if(!file_exists($zipped)) wpdm_download_data("something-wrong.txt", "File not found!");
            $zipname = basename($zipped);
            wpdm_download_file($zipped, $zipname);
            die();
        }


        /**
         * Email the current cart link to the provided email address
         */
        static function EmailFileCart($_email = null, $cartdata = ''){

            $cart_data = $cartdata?$cartdata:(isset($_POST['data'])?$_POST['data']:array());

            $files = array();
            if (is_array($cart_data)) {
                foreach ($cart_data as $key => $file) {
                    $key = explode("_", $key);
                    $pid = $key[0];
                    $file_index = $key[1];
                    $package = get_post($pid);
                    $pfiles = \WPDM\Package::getFiles($pid);
                    $dir = get_post_meta($pid, '__wpdm_package_dir', true);

                    if($dir != ''){
                        $dfiles = wpdm_get_files($dir);
                        foreach($dfiles as $fd){
                            $pfiles[] = $fd;
                        }
                    }

                    if(isset($pfiles[$file]))
                        $files[] = $pfiles[$file];
                }
            }
            $zipname = isset($_POST['zipname']) && $_POST['zipname'] != '' ? $_POST['zipname'] : 'custom-pack';
            $uniqid = uniqid();
            $zipped = wpdm_zip_files($files, $zipname . "-" . $uniqid);
            $zipped = basename($zipped);
            $download_url = home_url('/').'?fcpack='.$zipped;

            $_email = $_email?$_email:(isset($_POST['email'])?$_POST['email']:'');
            if( isset($_email) ){
                if(is_array($_email) && !is_email($_email[0])) return;
                else if(!is_array($_email) && !is_email($_email)) return;
                $admin_email = get_bloginfo("admin_email");
                $email = array();
                $subject = "Someone sent you a download link!";


                wp_mail($_email,$email['subject'],$email['body'],$email['headers']);

                $message =  get_bloginfo('name')." sent you some files. Use the following link to download: <br/><a style='display:inline-block;padding:4px 30px 0;border:1px solid #4cd370;color:#4cd370;font-weight:bold;letter-spacing:1px;border-radius:5px;text-decoration: none;text-transform: uppercase;line-height: 40px;margin: 10px;' href='{$download_url}'>Download</a><br/>";
                $params = array('subject' => $subject, 'to_email' => $_email, 'message' => $message);
                \WPDM\Email::send("default", $params);

                if(isset($_POST['email']))
                    die('sent');
            }
            if(isset($_POST['email']))
                die('error');
        }


        /**
         * Download the custom pack through the email link
         */
        function FileCartDownloadEmailLink(){
            if(!isset($_GET['fcpack'])) return;
            $zipped = WPDM_CACHE_DIR.$_GET['fcpack'];

            if(!file_exists($zipped)) wpdm_download_data("something-wrong.txt", "File not found!");
            $zipname = basename($zipped);
            wpdm_download_file($zipped, $zipname);
            die();
        }

        function formLock(){
                ?>




                        <div class="panel panel-default">
                            <div class="panel-heading">File Cart Settings</div>
                            <div class="panel-body">
                                <?php if(class_exists('WPDM_FormLock')){ ?>
                            <select id="fl" class="chzn-select" name="__wpdm_file_cart_form" style="min-width: 250px;width: 300px;">
                                <option value="0">Do Not Apply</option>
                            <?php if(is_plugin_active( 'liveforms/liveforms.php' )){ ?>
                                <optgroup label="Live Forms">
                                    <?php
                                    $forms = get_posts('post_type=form&posts_per_page=1000');

                                    foreach ($forms as $form) {

                                        // foreach($res as $row){
                                        ?>

                                        <option value="liveforms|<?php echo $form->ID; ?>" <?php if (get_option('__wpdm_file_cart_form', 0) == 'liveforms|'.$form->ID) echo "selected=selected"; ?> ><?php echo $form->post_title; ?></option>


                                        <?php

                                    }

                                    ?>
                                </optgroup>
                            <?php  } ?>
                            <?php if(is_plugin_active( 'gravityforms/gravityforms.php' )){ ?>
                                <optgroup label="Gravity Forms">
                                    <?php
                                    $forms = GFAPI::get_forms();

                                    foreach ($forms as $form) {
                                        ?>

                                        <option value="gravityforms|<?php echo $form['id']; ?>" <?php if (get_option('__wpdm_file_cart_form', 0) == 'gravityforms|'.$form['id']) echo "selected=selected"; ?> ><?php echo $form['title']; ?></option>


                                        <?php

                                    }

                                    ?>
                                </optgroup>
                            <?php  } ?>
                            <?php if(is_plugin_active( 'contact-form-7/wp-contact-form-7.php' )){ ?>
                                <optgroup label="Contact Form 7">
                                    <?php
                                    $forms = get_posts('post_type=wpcf7_contact_form&posts_per_page=1000');

                                    foreach ($forms as $form) {
                                        ?>

                                        <option value="contactform7|<?php echo $form->ID; ?>" <?php if (get_option('__wpdm_file_cart_form', 0) == 'contactform7|'.$form->ID) echo "selected=selected"; ?> ><?php echo $form->post_title; ?></option>


                                        <?php

                                    }

                                    ?>
                                </optgroup>
                            <?php  } ?>
                            <?php do_action('wpdm_file_cart_form_dropdown'); ?>
                        </select>
                        <hr/>
                        <label><input type="hidden" value="0" name="__wpdm_file_cart_email_downlad_link" /><input type="checkbox" name="__wpdm_file_cart_email_downlad_link" value="1" <?php checked(1, get_option('__wpdm_file_cart_email_downlad_link', 0)); ?> /> Email Download Link</label>
                                    <hr/>
                                <?php } ?>
                                <div class="form-group">
                                    <label for="__wpdm_user_dashboard"><?php echo __( "File Cart Page" , "download-manager" ); ?></label><br/>
                                    <?php wp_dropdown_pages(array('name' => '__wpdm_file_cart_pageid', 'id' => '__wpdm_file_cart_pageid', 'show_option_none' => __( "None Selected" , "download-manager" ), 'option_none_value' => '' , 'selected' => get_option('__wpdm_file_cart_pageid'))) ?><br/>
                                    <em class="note"><?php printf(__( "The page where you used short-code %s" , "download-manager" ),'<code>[wpdm_file_cart]</code>'); ?></em>
                                </div>
                            </div>
                            </div>

                <?php

        }

        function templateTag($vars){
            $package_id = $vars['ID'];
            $files = \WPDM\Package::getFiles($package_id);
            if(count($files) > 0) {
                $indices = array_keys($files);
                $file_index = $indices[0];
                $vars['addto_file_cart'] = "<button title='Add To File Cart' data-placement='right'  class='ttip btn btn-info btn-addtfc' data-pid='{$package_id}' data-fileindex='{$file_index}' data-file='{$file_index}'><i class='fa fa-plus'></i></button>";
                $vars['addto_file_cart_sm'] = "<button title='Add To File Cart' data-placement='right'  class='ttip btn btn-sm btn-info btn-addtfc' data-pid='{$package_id}' data-fileindex='{$file_index}' data-file='{$file_index}'><i class='fa fa-plus'></i></button>";
                $vars['addto_file_cart_lg'] = "<button title='Add To File Cart' data-placement='right'  class='ttip btn btn-lg btn-info btn-addtfc' data-pid='{$package_id}' data-fileindex='{$file_index}' data-file='{$file_index}'><i class='fa fa-plus'></i></button>";
            } else {
                $vars['addto_file_cart'] = $vars['addto_file_cart_sm'] = $vars['addto_file_cart_lg'] = "";
            }
            return $vars;
        }


    }

    new WPDM_FileCart();

}
 

