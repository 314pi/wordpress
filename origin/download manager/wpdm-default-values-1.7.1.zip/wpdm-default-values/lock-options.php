<?php
if(!isset($default['terms_lock'])) $default['terms_lock'] = '';
if(!isset($default['password_lock'])) $default['password_lock'] = '';
if(!isset($default['linkedin_lock'])) $default['linkedin_lock'] = '';
if(!isset($default['tweet_lock'])) $default['tweet_lock'] = '';
if(!isset($default['gplusone_lock'])) $default['gplusone_lock'] = '';
if(!isset($default['twitterfollow_lock'])) $default['twitterfollow_lock'] = '';
if(!isset($default['facebooklike_lock'])) $default['facebooklike_lock'] = '';
if(!isset($default['email_lock'])) $default['email_lock'] = '';
if(!isset($default['captcha_lock'])) $default['captcha_lock'] = '';

?>
<div id="lock-options"  class="tab-pane">
    <?php echo __('You can use one or more of following methods to lock your package download:','wpdmpro'); ?>
    <br/>
    <br/>
    <div class="wpdm-accordion w3eden">

        <!-- Terms Lock -->
        <div class="panel panel-default">
            <h3 class="panel-heading"><label><input type="checkbox" class="wpdmlock" rel='terms' name="wpdm_defaults[terms_lock]" <?php if($default['terms_lock']  == '1') echo "checked=checked"; ?> value="1"><?php echo __('Must Agree with Terms','wpdmpro'); ?></label></h3>
            <div  id="terms" class="fwpdmlock panel-body" <?php if( $default['terms_lock'] != '1' ) echo "style='display:none'"; ?> >

                <label for="pps_z"><?php echo __('Terms Title:','wpdmpro'); ?></label>
                <input type="text" class="form-control" name="wpdm_defaults[terms_title]" value="<?php echo esc_html($default['terms_title']); ?>" />
                <label for="pps_z"><?php echo __('Terms and Conditions:','wpdmpro'); ?></label>
                <textarea class="form-control" type="text" name="wpdm_defaults[terms_conditions]" id="tc_z"><?php echo esc_html($default['terms_conditions']); ?></textarea>
                <label for="pps_z"><?php echo __('Terms Checkbox Label:','wpdmpro'); ?></label>
                <input type="text" class="form-control" name="wpdm_defaults[terms_check_label]" value="<?php echo esc_html($default['terms_check_label']); ?>" />


            </div>
        </div>

        <div class="panel panel-default">
            <h3 class="panel-heading">
                <label><input type="checkbox" class="wpdmlock" rel='password' name="wpdm_defaults[password_lock]" <?php if( $default['password_lock']  == '1' ) echo "checked=checked"; ?> value="1"><?php echo __('Enable Password Lock','wpdmpro'); ?></label>
            </h3>
            <div  id="password" class="fwpdmlock panel-body" <?php if( $default['password_lock'] != '1' ) echo "style='display:none'"; ?> >
                <table class="table table-striped">
                    <tr id="password_row">
                        <td>
                            <?php echo __('Password:','wpdmpro'); ?> <i class="info fa fa-info" title="You can use single or multiple password<br/>for a package. If you are using multiple password then<br/>separate each password by []. example [password1][password2]"></i>
                        </td>
                        <td>
                            <div class="input-group">
                                <input class="form-control" type="text" name="wpdm_defaults[password]" id="pps_z" value="<?php echo $default['password']; ?>" />
                                <span class="input-group-btn">
                                <button class="btn btn-default"  onclick="return generatepass('pps_z')" type="button"><i class="fa fa-ellipsis-h"></i></button>
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr id="password_usage_row">
                        <td><?php echo __('PW Usage Limit:','wpdmpro'); ?></td>
                        <td><input size="10" style="width: 80px;display: inline" class="form-control input-sm" type="text" name="wpdm_defaults[password_usage_limit]" value="<?php echo $default['password_usage_limit']; ?>" /> / <?php echo __('password','wpdmpro'); ?> <i class="info fa fa-info" title="<?php echo __('Password will expire after it exceed this usage limit','wpdmpro'); ?>"></i></td>
                    </tr>
                    <tr id="password_usage_row">
                        <td colspan="2"><label><input type="checkbox" name="wpdm_defaults[password_usage]" value="0" /> <?php echo __('Reset Password Usage Count','wpdmpro'); ?></label></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel panel-default">
            <h3 class="panel-heading">
                <label><input type="checkbox" rel="linkedin" class="wpdmlock" name="wpdm_defaults[linkedin_lock]" <?php if ( $default['linkedin_lock'] == '1') echo "checked=checked"; ?> value="1"><?php echo __('LinkedIn Share Lock','wpdmpro'); ?></label>
            </h3>
            <div id="linkedin" class="frm fwpdmlock panel-body" <?php if( $default['linkedin_lock'] != '1') echo "style='display:none'"; ?> >
                <table class="table table-stripped">
                    <tr>
                        <td>
                            <?php _e("Message:","wpdmpro"); ?>
                            </br><textarea class="form-control" name="wpdm_defaults[linkedin_message]"><?php echo $default['linkedin_message']; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php _e("URL to share (keep empty for current page url):","wpdmpro"); ?>
                            <br/><input class="form-control input-sm" type="text" name="wpdm_defaults[linkedin_url]" value="<?php echo $default['linkedin_url']; ?>" />
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="panel panel-default">
            <h3 class="panel-heading"><label><input type="checkbox" rel="tweeter" class="wpdmlock" name="wpdm_defaults[tweet_lock]" <?php if( $default['tweet_lock'] == '1') echo "checked=checked"; ?> value="1"><?php echo __('Tweet Lock','wpdmpro'); ?></label></h3>
            <div id="tweeter" class="frm fwpdmlock panel-body" <?php if( $default['tweet_lock'] != '1' ) echo "style='display:none'"; ?> >
                <table width="100%"  cellpadding="0" cellspacing="0" >
                    <tr>
                        <td><?php echo __('Custom tweet message:','wpdmpro'); ?><br/>
                            <textarea class="form-control" type="text" name="wpdm_defaults[tweet_message]"><?php echo $default['tweet_message']; ?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel panel-default">
            <h3 class="panel-heading"><label><input type="checkbox" rel="gplusone" class="wpdmlock" name="wpdm_defaults[gplusone_lock]" <?php if( $default['gplusone_lock'] == '1' ) echo "checked=checked"; ?> value="1"><?php echo __('Enable Google +1 Lock','wpdmpro'); ?></label></h3>
            <div id="gplusone" class="frm fwpdmlock panel-body" <?php if( $default['gplusone_lock'] != '1' ) echo "style='display:none'"; ?> >
                <table width="100%"  cellpadding="0" cellspacing="0" >
                    <tr>
                        <td width="90px"><?php echo __('URL for +1:','wpdmpro'); ?></td>
                        <td><input size="10" class="form-control input-sm" style="width: 200px;display: inline;" type="text" name="wpdm_defaults[google_plus_1]" value="<?php echo $default['google_plus_1']; ?>" /></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel panel-default">
            <h3 class="panel-heading"><label><input type="checkbox" rel="gplusshare" class="wpdmlock" name="wpdm_defaults[twitterfollow_lock]" <?php if( $default['twitterfollow_lock'] == '1' ) echo "checked=checked"; ?> value="1"><?php echo __('Enable Twitter Follow Lock','wpdmpro'); ?></label></h3>
            <div id="gplusshare" class="frm fwpdmlock panel-body" <?php if( $default['twitterfollow_lock'] != '1' ) echo "style='display:none'"; ?> >
                <table width="100%"  cellpadding="0" cellspacing="0" >
                    <tr>
                        <td width="90px"><?php echo __('Twiiter Handle:','wpdmpro'); ?></td>
                        <td><input size="10" class="form-control input-sm" style="width: 200px;display: inline;" type="text" name="wpdm_defaults[twitter_handle]" value="<?php echo $default['twitter_handle']; ?>" /></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel panel-default">
            <h3 class="panel-heading"><label><input type="checkbox" rel="facebooklike" class="wpdmlock" name="wpdm_defaults[facebooklike_lock]" <?php if( $default['facebooklike_lock'] == '1' ) echo "checked=checked"; ?> value="1"><?php echo __('Enable Facebook Like Lock','wpdmpro'); ?></label></h3>
            <div id="facebooklike" class="frm fwpdmlock panel-body" <?php if( $default['facebooklike_lock'] != '1' ) echo "style='display:none;'"; ?> >
                <table  width="100%" cellpadding="0" cellspacing="0">
                    <?php if(get_option('_wpdm_facebook_app_id')=='') echo "<tr><td colspan=2>You have to add a Facebook appID <a href='admin.php?page=file-manager/settings#fbappid'>here</a></td></tr>"; ?>
                    <tr>
                        <td width="90px"><?php echo __('URL to Like:','wpdmpro'); ?></td>
                        <td><input size="10" style="width: 200px;display: inline;"  class="form-control input-sm" type="text" name="wpdm_defaults[facebook_like]" value="<?php echo $default['facebook_like']; ?>" /></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel panel-default">
            <h3 class="panel-heading"><label><input type="checkbox" rel="email" class="wpdmlock" name="wpdm_defaults[email_lock]" <?php if( $default['email_lock'] == '1' ) echo "checked=checked"; ?> value="1"><?php echo __('Enable Email Lock','wpdmpro'); ?></label></h3>
            <div id="email" class="frm fwpdmlock panel-body"  <?php if( $default['email_lock'] != '1' ) echo "style='display:none'"; ?> >
                <table cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            <?php //do_action('wpdm_custom_form_field'); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php echo __('Will ask for email before download','wpdmpro'); ?><br/>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel panel-default">
            <h3 class="panel-heading"><label><input type="checkbox" rel="captcha_lock" class="wpdmlock" name="wpdm_defaults[captcha_lock]" <?php if( $default['captcha_lock'] == '1' ) echo "checked=checked"; ?> value="1"><?php echo __('Enable CAPTCHA Lock','wpdmpro'); ?></label></h3>
        </div>
            <?php //do_action('wpdm_download_lock_option',$post); ?>
    </div>
    <div class="clear"></div>
</div>


<!-- all js ------>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery( "#tabs" ).tabs();

        jQuery('body').on('click', ".cb-enable",function(){
            var parent = jQuery(this).parents('.switch');
            jQuery('.cb-disable',parent).removeClass('selected');
            jQuery(this).addClass('selected');
            jQuery('.checkbox',parent).attr('checked', true);
        });
        jQuery('body').on('click', ".cb-disable",function(){
            var parent = jQuery(this).parents('.switch');
            jQuery('.cb-enable',parent).removeClass('selected');
            jQuery(this).addClass('selected');
            jQuery('.checkbox',parent).attr('checked', false);
        });

        var n = 0;

        jQuery('body').on('click', '.wpdm-label',function(){
            if(jQuery(this).hasClass('wpdm-checked')) jQuery(this).addClass('wpdm-unchecked').removeClass('wpdm-checked');
            else jQuery(this).addClass('wpdm-checked').removeClass('wpdm-unchecked');

        });

        jQuery(window).scroll(function(){
            if(jQuery(window).scrollTop()>100)
                jQuery('#action').addClass('action-float').removeClass('action');
            else
                jQuery('#action').removeClass('action-float').addClass('action');
        });

        jQuery("#wpdm-settings select").chosen({no_results_text: ""});

        jQuery('.handlediv').click(function(){
            jQuery(this).parent().find('.inside').slideToggle();
        });

        jQuery('.handle').click(function(){
            alert(2);
            jQuery(this).parent().find('.inside').slideToggle();
        });

        jQuery('.nopro').click(function(){
            if(this.checked) jQuery('.wpdmlock').removeAttr('checked');
        });

        jQuery('.wpdmlock').click(function(){
            if(this.checked) {
                jQuery('#'+jQuery(this).attr('rel')).slideDown();
                jQuery('.nopro').removeAttr('checked');
            } else {
                jQuery('#'+jQuery(this).attr('rel')).slideUp();
            }
        });

        jQuery('.w3eden .info.fa').tooltip({html:true, placement: 'right'});

    });

    function generatepass(id){
        tb_show('Generate Password',ajaxurl+'?action=wpdm_generate_password&w=300&h=500&id='+id);
    }
</script>
<style>
    .w3eden .tooltip-inner{ border-radius: 2px !important; font-family: courier, monospace; padding: 8px 13px;  text-align: left; font-size: 12px; max-width: 250px; }
    .w3eden input[type=radio]{ margin-top: 0; }
    .form-control.input-sm{ display: inline; }

    .ui-tabs .ui-tabs-nav li a{
        font-size: 10pt !important;
        outline: none !important;

    }
    .ui-tabs .ui-tabs-nav li{
        margin-bottom: 0 !important;
        border-bottom: 1px solid #dddddd !important;
    }

    .ui-tabs .ui-tabs-nav li.ui-state-active{
        border-bottom: 1px solid #ffffff !important;
    }
    .wdmiconfile{
        -webkit-border-radius: 6px;
        -moz-border-radius: 6px;
        border-radius: 6px;
    }


    .w3eden input[type=checkbox], .w3eden input[type=radio], .w3eden label{ margin: 0 !important;}

    #wpdm-files_length{
        display: none;
    }
    #wpdm-files_filter{
        margin-bottom:10px !important;
    }
    .adp-ui-state-highlight{
        width:50px;
        height:50px;
        background: #fff;
        float:left;
        padding: 4px;
        border:1px solid #aaa;
    }
    #wpdm-files tbody .ui-sortable-helper{
        background: transparent;

    }
    #wpdm-files tbody .ui-sortable-helper td{
        vertical-align: middle;
        background: #eeeeee;
    }
    input[type=text]{
        padding: 4px 7px;
        border-radius: 3px;
    }


    .dfile{background: #ffdfdf;}
    .cfile{
        cursor: move;
    }
    .cfile img, .dfile img{cursor: pointer;}

    #editorcontainer textarea{border:0px;width:99.9%;}
    #icon_uploadUploader,#file_uploadUploader {background: transparent url('<?php echo plugins_url(); ?>/download-manager/images/browse.png') left top no-repeat; }
    #icon_uploadUploader:hover,#file_uploadUploader:hover {background-position: left bottom; }
    .frm td{line-height: 30px; border-bottom: 1px solid #EEEEEE; padding:5px; font-size:9pt;font-family: Tahoma;}

    .fwpdmlock td{
        border:0px !important;
        vertical-align: middle !important;
    }
    #filelist {
        margin-top: 10px;
    }
    #filelist .file{
        margin-top: 5px;
        padding: 0px 10px;
        color:#444;
        display: block;
        margin-bottom: 5px;
        font-weight: normal;
    }

    table.widefat{
        border-bottom:0px;
    }

    .genpass{
        cursor: pointer;
    }

    h3,
    h3.handle{
        cursor: default !important;
    }


    @-webkit-keyframes progress-bar-stripes {
        from {
            background-position: 40px 0;
        }
        to {
            background-position: 0 0;
        }
    }

    @-moz-keyframes progress-bar-stripes {
        from {
            background-position: 40px 0;
        }
        to {
            background-position: 0 0;
        }
    }

    @-ms-keyframes progress-bar-stripes {
        from {
            background-position: 40px 0;
        }
        to {
            background-position: 0 0;
        }
    }

    @-o-keyframes progress-bar-stripes {
        from {
            background-position: 0 0;
        }
        to {
            background-position: 40px 0;
        }
    }

    @keyframes progress-bar-stripes {
        from {
            background-position: 40px 0;
        }
        to {
            background-position: 0 0;
        }
    }

    .progress {
        height: 15px;
        margin-bottom: 10px;
        overflow: hidden;
        background-color: #f7f7f7;
        background-image: -moz-linear-gradient(top, #f5f5f5, #f9f9f9);
        background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#f5f5f5), to(#f9f9f9));
        background-image: -webkit-linear-gradient(top, #f5f5f5, #f9f9f9);
        background-image: -o-linear-gradient(top, #f5f5f5, #f9f9f9);
        background-image: linear-gradient(to bottom, #f5f5f5, #f9f9f9);
        background-repeat: repeat-x;
        -webkit-border-radius: 4px;
        -moz-border-radius: 4px;
        border-radius: 4px;
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5', endColorstr='#fff9f9f9', GradientType=0);
        -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        -moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    }

    .progress .bar {
        float: left;
        width: 0;
        height: 100%;
        font-size: 12px;
        color: #ffffff;
        text-align: center;
        text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
        background-color: #0e90d2;
        background-image: -moz-linear-gradient(top, #149bdf, #0480be);
        background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#149bdf), to(#0480be));
        background-image: -webkit-linear-gradient(top, #149bdf, #0480be);
        background-image: -o-linear-gradient(top, #149bdf, #0480be);
        background-image: linear-gradient(to bottom, #149bdf, #0480be);
        background-repeat: repeat-x;
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf', endColorstr='#ff0480be', GradientType=0);
        -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
        -moz-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
        box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        -webkit-transition: width 0.6s ease;
        -moz-transition: width 0.6s ease;
        -o-transition: width 0.6s ease;
        transition: width 0.6s ease;
    }

    .progress .bar + .bar {
        -webkit-box-shadow: inset 1px 0 0 rgba(0, 0, 0, 0.15), inset 0 -1px 0 rgba(0, 0, 0, 0.15);
        -moz-box-shadow: inset 1px 0 0 rgba(0, 0, 0, 0.15), inset 0 -1px 0 rgba(0, 0, 0, 0.15);
        box-shadow: inset 1px 0 0 rgba(0, 0, 0, 0.15), inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    }

    .progress-striped .bar {
        background-color: #149bdf;
        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.15)), color-stop(0.75, rgba(255, 255, 255, 0.15)), color-stop(0.75, transparent), to(transparent));
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        -webkit-background-size: 40px 40px;
        -moz-background-size: 40px 40px;
        -o-background-size: 40px 40px;
        background-size: 40px 40px;
    }

    .progress.active .bar {
        -webkit-animation: progress-bar-stripes 2s linear infinite;
        -moz-animation: progress-bar-stripes 2s linear infinite;
        -ms-animation: progress-bar-stripes 2s linear infinite;
        -o-animation: progress-bar-stripes 2s linear infinite;
        animation: progress-bar-stripes 2s linear infinite;
    }

    .progress-danger .bar,
    .progress .bar-danger {
        background-color: #dd514c;
        background-image: -moz-linear-gradient(top, #ee5f5b, #c43c35);
        background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#ee5f5b), to(#c43c35));
        background-image: -webkit-linear-gradient(top, #ee5f5b, #c43c35);
        background-image: -o-linear-gradient(top, #ee5f5b, #c43c35);
        background-image: linear-gradient(to bottom, #ee5f5b, #c43c35);
        background-repeat: repeat-x;
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffee5f5b', endColorstr='#ffc43c35', GradientType=0);
    }

    .progress-danger.progress-striped .bar,
    .progress-striped .bar-danger {
        background-color: #ee5f5b;
        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.15)), color-stop(0.75, rgba(255, 255, 255, 0.15)), color-stop(0.75, transparent), to(transparent));
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    }

    .progress-success .bar,
    .progress .bar-success {
        background-color: #5eb95e;
        background-image: -moz-linear-gradient(top, #62c462, #57a957);
        background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#62c462), to(#57a957));
        background-image: -webkit-linear-gradient(top, #62c462, #57a957);
        background-image: -o-linear-gradient(top, #62c462, #57a957);
        background-image: linear-gradient(to bottom, #62c462, #57a957);
        background-repeat: repeat-x;
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff62c462', endColorstr='#ff57a957', GradientType=0);
    }

    .progress-success.progress-striped .bar,
    .progress-striped .bar-success {
        background-color: #62c462;
        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.15)), color-stop(0.75, rgba(255, 255, 255, 0.15)), color-stop(0.75, transparent), to(transparent));
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    }

    .progress-info .bar,
    .progress .bar-info {
        background-color: #4bb1cf;
        background-image: -moz-linear-gradient(top, #5bc0de, #339bb9);
        background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#5bc0de), to(#339bb9));
        background-image: -webkit-linear-gradient(top, #5bc0de, #339bb9);
        background-image: -o-linear-gradient(top, #5bc0de, #339bb9);
        background-image: linear-gradient(to bottom, #5bc0de, #339bb9);
        background-repeat: repeat-x;
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de', endColorstr='#ff339bb9', GradientType=0);
    }

    .progress-info.progress-striped .bar,
    .progress-striped .bar-info {
        background-color: #5bc0de;
        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.15)), color-stop(0.75, rgba(255, 255, 255, 0.15)), color-stop(0.75, transparent), to(transparent));
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    }

    .progress-warning .bar,
    .progress .bar-warning {
        background-color: #faa732;
        background-image: -moz-linear-gradient(top, #fbb450, #f89406);
        background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#fbb450), to(#f89406));
        background-image: -webkit-linear-gradient(top, #fbb450, #f89406);
        background-image: -o-linear-gradient(top, #fbb450, #f89406);
        background-image: linear-gradient(to bottom, #fbb450, #f89406);
        background-repeat: repeat-x;
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450', endColorstr='#fff89406', GradientType=0);
    }

    .progress-warning.progress-striped .bar,
    .progress-striped .bar-warning {
        background-color: #fbb450;
        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.15)), color-stop(0.75, rgba(255, 255, 255, 0.15)), color-stop(0.75, transparent), to(transparent));
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
    }
    #access{
        width: 250px;
    }

    #nxt{
        background-color: #C1F4C1;
        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.15)), color-stop(0.75, rgba(255, 255, 255, 0.15)), color-stop(0.75, transparent), to(transparent));
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        -webkit-background-size: 40px 40px;
        -moz-background-size: 40px 40px;
        -o-background-size: 40px 40px;
        background-size: 40px 40px;
        display: none;
        border-bottom:1px solid #008000;
        color: #0C490C;font-family:'Courier New';padding:5px 10px;text-align: center;
    }

    #serr{
        display: none;margin-top: 5px;border:1px solid #800000;background: #FFEDED;color: #000;font-family:'Courier New';padding:5px 10px;text-align: left;
    }
    .action #nxt{
        width:100%;
        position: fixed;
        top:0px;left:0px;z-index:999999;
    }
    #nxt a{
        font-weight: bold;
        color:#0C490C;
    }

    .action-float{
        position:fixed;top:-33px;left:0px;width:100%;z-index:999999;text-align:right;
        background: rgba(0,0,0,0.9);
    }

    .action .inside,
    .action-float .inside{
        margin: 0px;
    }

    .action-float #serr{
        width:500px;
        float: left;
        margin: 4px;
        z-index:999999;
        margin-top:-50px;
        border:1px solid #800000;
    }
    .action-float #nxt{
        width:500px;
        float: left;
        margin: 4px;
        z-index:999999;
        margin-top:-40px;
        border:1px solid #008000;
    }

    .wpdm-accordion > div{
        padding:10px;
    }

    /*.wpdmlock {*/
    /*opacity:0;*/
    /*}*/
    /*.wpdmlock+label {*/

    /*width:16px;*/
    /*height:16px;*/
    /*vertical-align:middle;*/
    /*}*/

    .w3eden .panel{
        padding: 0 !important;
    }
    .w3eden .wpdmlock{
        margin: 0 5px  0 0 !important;
    }
    .wpdm-unchecked{
        display: inline-block;
        float: left;
        width: 21px;
        height: 21px;
        padding: 0px;
        margin: 0px;
        cursor: hand;
        padding: 3px;
        margin-top: -4px !important;
        background-image: url('<?php echo plugins_url('/download-manager/images/CheckBox.png'); ?>');
        background-position: -21px 0px;
    }
    .wpdm-checked{
        display: inline-block;
        float: left;
        width: 21px;
        height: 21px;
        padding: 0px;
        margin: 0px;
        cursor: hand;
        padding: 3px;
        margin-top: -4px !important;
        background-image: url('<?php echo plugins_url('/download-manager/images/CheckBox.png'); ?>');
        background-position: 0px 0px;
    }
    .cb-enable, .cb-disable, .cb-enable span, .cb-disable span { background: url(<?php echo plugins_url('/download-manager/images/switch.gif'); ?>) repeat-x; display: block; float: left; }
    .cb-enable span, .cb-disable span { line-height: 30px; display: block; background-repeat: no-repeat; font-weight: bold; }
    .cb-enable span { background-position: left -90px; padding: 0 10px; }
    .cb-disable span { background-position: right -180px;padding: 0 10px; }
    .cb-disable.selected { background-position: 0 -30px; }
    .cb-disable.selected span { background-position: right -210px; color: #fff; }
    .cb-enable.selected { background-position: 0 -60px; }
    .cb-enable.selected span { background-position: left -150px; color: #fff; }
    .switch label { cursor: pointer; }
    /*.switch input { display: none; }*/
    p.field.switch{
        margin:0px;display:block;float:left;
    }
    .wpdm-accordion.w3eden .panel-default{
        margin-bottom: -2px !important;
        border-radius: 0;
    }
    .wpdm-accordion.w3eden .panel-default .panel-heading{
        border-radius: 0;
    }
    .w3eden .chzn-choices{
        background-image: none !important;
        border-radius: 3px;
    }
    .w3eden .chzn-choices input{
        padding: 0;
        line-height: 10px;
    }
    .w3eden .chzn-container-multi .chzn-drop{
        margin-top: 3px;
        border: 1px solid #5897fb !important;
        overflow: hidden;
        border-radius: 3px;
        padding: 10px 5px 10px 10px !important;
    }
    .w3eden .chzn-container-multi .chzn-drop li{
        border-radius: 2px !important;
        margin-right: 10px !important;
    }
    .w3eden .info.fa{
        border-radius: 500px;
        border: 0.05em solid #5897fb;
        color: #5897fb;
        width: 20px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        font-size: 10px;
    }
    .w3eden .table td{
        vertical-align: middle !important;
    }
</style>