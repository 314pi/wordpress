<?php
/*
Plugin Name: WPDM - PDF Viewer
Description: PDF Viewer for Wordpress Download Manager Pro
Plugin URI: https://www.wpdownloadmanager.com/
Author: Shaon
Version: 1.2.6
Author URI: https://www.wpdownloadmanager.com/
Text Domain: wpdm-pdf-viewer
*/

namespace WPDM\AddOn;

class PDFViwer{
    private $viewer;
    function __construct()
    {
        add_filter("wp", array($this, 'viewer'));
        add_filter("wpdm_doc_preview", array($this, 'embedCode'), 999999, 4);
        add_filter("wdm_before_fetch_template", array($this, 'pdfGallery'), 10);
    }

    public static function viewerURL($pid, $file_id){
        return home_url("/?__wpdm_pdf_viewer={$pid}|{$file_id}");
    }

    function embedCode($html, $package, $url, $ext){
        $pid = $package['ID'];
        $up = parse_url($url);
        if(isset($up['host'], $_SERVER['HTTP_HOST']) && $up['host'] != $_SERVER['HTTP_HOST'] && !strstr($url, 'locked')) return $html;
        $files = \WPDM\Package::getFiles($pid);
        //wpdmdd($files);
        $file_id = -1;
        foreach ($files as $id => $file){
            $filetype = wp_check_filetype( $file );
            $ext = strtolower($filetype['ext']);
            if($ext == 'pdf') {
               $file_id = $id;
               break;
            }
        }
        //wpdmdd($file_id);
        if($file_id == -1) return $html;
        $this->viewer = self::viewerURL($pid, $file_id);
        //wpdmdd( $this->viewer);
        return "<iframe id='viewer-{$pid}' class='thumbnail' src='{$this->viewer}' style='width: 100%;height: 700px;margin-bottom: 15px'></iframe></iframe>";
    }

    function pdfGallery($package){
        $pid = $package['ID'];
        $files = \WPDM\Package::getFiles($pid);
        $file_info = get_post_meta($pid, '__wpdm_fileinfo', true);
        $file_info = maybe_unserialize($file_info);
        $apvws = get_post_meta($pid, '__wpdm_additional_previews', true);
        $apvws = maybe_unserialize($apvws);
        $gallery ="<div class='ttip' title='Select PDF to view'><select class='form-control wpdm-custom-select' style='margin-bottom: 15px' onchange=\"jQuery('#viewer-{$pid}') . attr('src', jQuery(this).val());return false;\">";
        $x = 0;
        foreach ($files as $id => $file){
            $filetype = wp_check_filetype( $file );
            $ext = strtolower($filetype['ext']);
            if($ext == 'pdf') {
                $durl = self::viewerURL($pid, $id); // home_url("/?wpdmdl={}&ind={}&open=1");
                $urls[] = $durl;
                $file_title = isset($file_info[$id], $file_info[$id]['title']) && $file_info[$id]['title'] != ''?$file_info[$id]['title']:$file;
                $gallery .= "<option value='{$durl}'>{$file_title}</option> ";
                $x++;
            }
        }
        $gallery .= "</select></div>";
        if(isset($urls))
            $gallery = $this->embedCode("", $package, $urls[0], "").$gallery;
        $package['pdf_gallery'] = $gallery;
        return $package;

    }

    function viewer(){

        if(wpdm_query_var('__wpdm_pdf_viewer') != ''){
            include wpdm_tpl_path("viewer.php", __DIR__.'/tpls');
            die();
        }
    }


}

if(defined('WPDM_Version'))
    new PDFViwer();