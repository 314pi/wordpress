<?php
/*
  Plugin Name: WPDM - Advanced Custom Fields
  Plugin URI: https://www.wpdownloadmanager.com/download/advanced-custom-fields/
  Description: Advanced Custom Fields Manager Add-on for WordPress Download Manager
  Author: Shaon
  Version: 1.9.4
  Author URI: https://www.wpdownloadmanager.com/
 */

define('DMCF_BASE_DIR', dirname(__FILE__) . '/');
 
class wpdm_acf
{

    function __construct()
    {
        add_shortcode('wpdm_quick_form', array($this, 'quick_form'));
        add_action('admin_menu', array($this, 'dmcf_custom_fields'));
        add_action('wp_enqueue_scripts', array($this, 'dmcf_enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'dmcf_admin_enqueue_scripts'));
        add_action('wp_ajax_save_dmcf_custom_field', array($this, 'dmcf_save_field'));
        add_action('add_meta_boxes', array($this, 'dmcf_add_metaboxes'));
        add_action('wpdm-package-form-left', array($this, 'dmcf_add_metaboxes_frontend'));
        add_action('save_post', array($this, 'dmcf_save_meta_box_data'));
        add_filter('wdm_before_fetch_template', array($this, 'wpdm_show_acf_groups'));
        add_filter('wpdm_render_custom_form_fields', array($this, 'wpdm_show_s2dcf'), 10, 2);
        add_action('wpdm_custom_form_field',  array($this,'custom_form_fields'));
        if(is_admin()){
            add_filter('add_wpdm_settings_tab',  array($this,'settings_tab'));
            add_filter('wpdm_export_custom_form_fields',  array($this,'s2dcf_export'));
        }

        add_action( 'register_form',        array( $this, 'userRegFields' ) );
        add_action( 'show_user_profile',        array( $this, 'userProfileFields' ) );
        add_action( 'edit_user_profile',        array( $this, 'userProfileFields' ) );
        add_action( 'wpdm_edit_profile_form',        array( $this, 'userProfileFields' ) );
        add_action( 'personal_options_update',  array( $this, 'updateUserProfile' ) );
        add_action( 'edit_user_profile_update', array( $this, 'updateUserProfile' ) );
        add_action( 'user_register',        array( $this, 'userRegCustomFields' ) );

        add_action( 'admin_init', array( $this, 'exportGroup' ) );
        add_action( 'wp_ajax_dmcf_import_group', array( $this, 'importGroup' ) );
    }

    function userProfileFields($user = null){
        global $current_user;
        if(!$user) $user = $current_user;
        $s2dcf_fields_label = get_option('s2dcf_field_label');
        ob_start();
        $s2dcf_userinf = get_option('s2dcf_userinf');
        //wpdmdd($s2dcf_userinf);
        $groups = array_keys($s2dcf_userinf);
        $s2dcf_group_names = get_option('s2dcf_group_names');
        echo "<div class='w3eden' style='width: 800px;max-width: 100%;'>";
        foreach ( $groups as $id) {
            $data = isset($s2dcf_fields_label[$id]) ? $s2dcf_fields_label[$id] : '';
            $data['group'] = $id;
            $label = esc_attr(stripslashes_deep($s2dcf_group_names[$id]));
            echo "<div class='panel  panel-default {$id}'><div class='panel-heading'>{$label}</div><div class='panel-body'>";
            $values = is_object($user) && isset($user->ID) ? maybe_unserialize(get_user_meta($user->ID, 'wpdm_cregf', true)) : array();
            $this->s2dcf_render(null, $data, array('class' => '', 'field_name' => "wpdm_cregf[$id]", 'values' => $values));
            echo "</div></div>";
        }
        echo "</div>";
        $html = ob_get_clean();
        echo $html;
    }

    function userRegFields(){
        $s2dcf_fields_label = get_option('s2dcf_field_label');
        ob_start();
        $s2dcf_userinf = get_option('s2dcf_userinf');
        //wpdmdd($s2dcf_userinf);
        $groups = is_array($s2dcf_userinf) ? array_keys($s2dcf_userinf) : array();
        $s2dcf_group_names = get_option('s2dcf_group_names');
        if(is_array($groups) && count($groups) > 0) {
            echo "<div class='w3eden' style='width: 800px;max-width: 100%;'>";
            foreach ($groups as $id) {
                $data = isset($s2dcf_fields_label[$id]) ? $s2dcf_fields_label[$id] : '';
                $data['group'] = $id;
                $label = esc_attr(stripslashes_deep($s2dcf_group_names[$id]));
                if (isset($s2dcf_userinf[$id], $s2dcf_userinf[$id]['regform']) && $s2dcf_userinf[$id]['regform'] == 1) {
                    echo "<div class='panel  panel-default {$id}'><div class='panel-heading'>{$label}</div><div class='panel-body'>";
                    $this->s2dcf_render(null, $data, array('class' => 'input-lg', 'field_name' => "wpdm_cregf[$id]", 'values' => array()));
                    echo "</div></div>";
                }
            }
            echo "</div>";
        }
        $html = ob_get_clean();
        echo $html;
    }

    function wpdm_acf_sanitize_array($array){

//        foreach ($array as $key => &$value){
//            if(is_array($value))
//                $this->wpdm_acf_sanitize_array($value);
//            else {
//                $value = strstr($value, "\n")?wp_kses($value, array('strong' => array(), 'b' => array(), 'br' => array(), 'p' => array(), 'hr' => array(), 'a' => array('href' => array(), 'title' => array()))):sanitize_text_field($value);
//            }
//            $array[$key] = &$value;
//        }
//        return $array;
        return wpdm_sanitize_array($array);
    }

    function updateUserProfile($user_id){
        if ( !current_user_can( 'edit_user', $user_id ) ) return false;
        if( get_current_user_id() !== $user_id && !current_user_can('manage_options')) return;
        if((int)$user_id < 1) return;
        $wpdm_cregf = $this->wpdm_acf_sanitize_array($_POST['wpdm_cregf']);
        update_user_meta($user_id, 'wpdm_cregf', serialize($wpdm_cregf));
    }

    function userRegCustomFields($user_id){
        if(user_can($user_id, 'manage_options')) return;
        $wpdm_cregf = $this->wpdm_acf_sanitize_array($_POST['wpdm_cregf']);
        update_user_meta($user_id, 'wpdm_cregf', serialize($wpdm_cregf));
    }

    function settings_tab($tabs){
        $tabs['s2dcf'] = wpdm_create_settings_tab('s2dcf', 'Quick Forms', array($this,'s2d_custom_fields'), 'fas fa-bars');
        return $tabs;
    }

    function custom_form_fields(){
        $s2dcf_group_names = get_option('s2dcf_group_names');
        $sel = get_post_meta(get_the_ID(), '__wpdm_s2dcf', true);
        echo "<fieldset><legend>Additional Fields:</legend><select name='file[s2dcf]' style='width: 250px;min-width: 250px' id='acffg' class='form-control'>";
        if(is_array($s2dcf_group_names)) {
            foreach ($s2dcf_group_names as $key => $name) {
                if ($sel == $key)
                    echo "<option value='$key' selected='selected'>$name</option>";
                else
                    echo "<option value='$key'>$name</option>";
            }
        }
        echo "</select><style>#acffg_chosen{ min-width: 300px; }</style></fieldset>";
    }

    public function quick_form($params = array()){
        global $post;
        if(is_array($params)) extract($params);
        if(!isset($id)) return '';
        if(!isset($button_label)) $button_label = 'Submit';
        $s2dcf_fields_label = get_option('s2dcf_field_label');
        ob_start();
        $data = isset($s2dcf_fields_label[$id])?$s2dcf_fields_label[$id]:'';
        $data['group'] = $id;
        $formid = 'form_'.uniqid();
        echo "<div class='w3eden'><form method='post' id='{$formid}'><input type='hidden' name='quick_form' value='{$id}'>";
        if(isset($email))
            echo "<input type='hidden' name='mail_to' value='{$email}'>";
        $this->s2dcf_render($post, $data);
        echo "<button class='btn btn-primary'>$button_label</button></form><div id='{$formid}_res'></div></div>";
        echo <<<AS
<script>
jQuery(function($){
$('#{$formid}').submit(function(e){
e.preventDefault();
    $(this).ajaxSubmit({
    success: function(res){
        $('#{$formid}_res').html(res);
    }
    });
    return false;
});
});
</script>
AS;

        $data = ob_get_clean();
        return $data;
    }

    public function wpdm_show_s2dcf($html, $id){
        global $post;
        $s2dcf_fields_label = get_option('s2dcf_field_label');
        $sel = get_post_meta($id, '__wpdm_s2dcf', true);
        ob_start();
        $data = isset($s2dcf_fields_label[$sel])?$s2dcf_fields_label[$sel]:'';
        $data['group'] = $sel;
        $this->s2dcf_render($post, $data);
        $data = ob_get_clean();
        return $html.$data;
    }

    public function s2dcf_export($fields){
        $s2dcf_group_names = get_option('s2dcf_group_names');
        $s2dcf_field_label = get_option('s2dcf_field_label');
        $s2dcf_field_name = get_option('s2dcf_field_name');
        $tfields = array();
        if(is_array($s2dcf_group_names)){
        foreach($s2dcf_group_names as $groupid => $gname){
            $tfields += array_combine($s2dcf_field_name[$groupid], $s2dcf_field_label[$groupid]);

        }}
        $keys = array_keys($tfields);
        foreach($keys as $key){
            $fields[] = $key;
        }
        return $fields;
    }

    public function s2d_custom_fields(){

        if(wpdm_query_var('section') == 's2dcf' && wpdm_query_var('task') == 'wdm_save_settings' ){
            $s2dcf_field_label = $_REQUEST['field-label'];
            $s2dcf_field_name = $_REQUEST['field-name'];
            $s2dcf_field_type = $_REQUEST['field-type'];
            $s2dcf_field_choice = $_REQUEST['field-choices'];
            $s2dcf_hidden_values = $_REQUEST['hidden-values'];
            $s2dcf_group_names = $_REQUEST['groupnames'];
            $s2dcf_userinf = $_REQUEST['userinf'];
            $s2dcf_field_required = $_REQUEST['field-required'];

            //wpdmprecho($s2dcf_field_required);

            //if (!empty($dmcf_field_name) || !empty($s2dcf_field_label) || !empty($s2dcf_field_type) || !empty($s2dcf_field_choice)) {
                update_option('s2dcf_field_label', $s2dcf_field_label);
                update_option('s2dcf_field_name', $s2dcf_field_name);
                update_option('s2dcf_field_type', $s2dcf_field_type);
                update_option('s2dcf_field_choice', $s2dcf_field_choice);
                update_option('s2dcf_hidden_values', $s2dcf_hidden_values);
                update_option('s2dcf_field_required', $s2dcf_field_required);
                update_option('s2dcf_group_names', $s2dcf_group_names);
                update_option('s2dcf_userinf', $s2dcf_userinf);
           // } else {
           //     die('Error: No field created yet');
           // }
            die('Settings Saved Successfully.');
        }

        require_once DMCF_BASE_DIR."tpls/s2dcf-create-field.php";


    }



    function dmcf_save_meta_box_data($post_id)
    {
        if (!isset($_POST['dmcf_meta_box_nonce'])) {
            return;
        }
        if (!wp_verify_nonce($_POST['dmcf_meta_box_nonce'], 'dmcf_meta_box')) {
            return;
        }
        if (!isset($_POST['wpdmproacf'])) {
            return;
        }
        $wpdmpro_data = $_POST['wpdmproacf'];
        update_post_meta($post_id, '__wpdmpro_custom_fields', $wpdmpro_data);
    }

    function wpdm_show_acf_groups($vars)
    {
        global $current_user;

        $dmcf_group_names = get_option('dmcf_group_names');
        $dmcf_field_name = get_option('dmcf_field_name');


        //$alldata = get_post_meta($vars['ID'], '__wpdmpro_custom_fields', true);

        if(is_array($dmcf_field_name)){
        foreach ($dmcf_field_name as $group => $fields) {

            $vars['acf_group_' . $group] = self::acf_group($vars['ID'], $group, $vars);

            $dmcf_groupviewers = get_option('dmcf_groupviewers', array());
            $dmcf_groupviewers = is_array($dmcf_groupviewers) && isset($dmcf_groupviewers[$group])?$dmcf_groupviewers[$group]: array();
            $current_user->roles[] = 'guest';
            $hasAccess = true;
            if(!is_array($dmcf_groupviewers) || count(array_intersect($dmcf_groupviewers, $current_user->roles)) == 0) $hasAccess = false;


            if (is_array($fields)) {
                foreach ($fields as $field) {
                    //if(!isset($vars["acf_{$group}_{$field}"]))
                        //$vars["acf_{$group}_{$field}"] = "";
                    $vars["acf_{$group}_{$field}"] = $hasAccess?get_post_meta($vars['ID'], "__wpdm_acf_{$group}_{$field}", true):"";
                    if(is_array($vars["acf_{$group}_{$field}"])) {
                        $vars["acf_{$group}_{$field}"] = $hasAccess?implode(", ", $vars["acf_{$group}_{$field}"]):'';
                    }
                }
            }

        }}

        return $vars;
    }

    public static function acf_group($ID, $groupid, $vars)
    {
        global $current_user;
        $dmcf_group_names = get_option('dmcf_group_names');
        $dmcf_field_label = get_option('dmcf_field_label');
        $dmcf_field_name = get_option('dmcf_field_name');
        $dmcf_groupviewers = get_option('dmcf_groupviewers', array());
        $dmcf_groupviewers = is_array($dmcf_groupviewers) && isset($dmcf_groupviewers[$groupid])?$dmcf_groupviewers[$groupid]: array();
        $current_user->roles[] = 'guest';
        if(!is_array($dmcf_groupviewers) || count(array_intersect($dmcf_groupviewers, $current_user->roles)) == 0) return "";
        if (!isset($dmcf_field_name[$groupid])) return '';
        $data = $dmcf_field_name[$groupid];
        $fields = array_combine($dmcf_field_name[$groupid], $dmcf_field_label[$groupid]);
        ob_start();
        ?>
        <div class="panel panel-default">
            <div class="panel-heading"><?php echo $dmcf_group_names[$groupid]; ?></div>
            <table class="table">
                <?php foreach ($data as $key):
                   $value = !isset($vars['acf_'.$groupid.'_'.$key])?"":$vars['acf_'.$groupid.'_'.$key];
                    ?>
                    <tr>
                        <td><?php echo $fields[$key]; ?></td>
                        <td><?php echo is_array($value)?implode(", ", $value):$value; ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php
        $datahtml = ob_get_clean();
        return $datahtml;
    }

    function dmcf_add_metaboxes()
    {
        global $current_user;
        $dmcf_field_label = get_option('dmcf_field_label');
        $dmcf_group_names = get_option('dmcf_group_names');
        $dmcf_groupmanagers = get_option('dmcf_groupmanagers', array());
        $total_groups = is_array($dmcf_group_names)?count($dmcf_group_names):0;
        $count = 0;
        if (!empty($dmcf_field_label)) {
            foreach ($dmcf_field_label as $key => $meta_data) {
                $meta_data['group'] = $key;
                $dmcf_groupmanager = isset($dmcf_groupmanagers[$key])?$dmcf_groupmanagers[$key]:array();
                if(is_array($dmcf_groupmanager) && count(array_intersect($dmcf_groupmanager, $current_user->roles)) > 0) {
                    add_meta_box(
                        $dmcf_group_names[$key], __($dmcf_group_names[$key], 'download-manager-custom-fields'), array($this, 'dmcf_create_metabox'), 'wpdmpro', 'advanced', 'default', array('my_data' => $meta_data)
                    );
                    $count++;
                }
            }
        }
    }

    function dmcf_add_metaboxes_frontend()
    {
        global $post, $current_user;
        $dmcf_field_label = get_option('dmcf_field_label');
        $dmcf_group_names = get_option('dmcf_group_names');
        $dmcf_groupmanagers = get_option('dmcf_groupmanagers', array());
        $total_groups = count($dmcf_group_names);
        $count = 0;
        if (!empty($dmcf_field_label)) {
            foreach ($dmcf_field_label as $key => $meta_data) {
                $meta_data['group'] = $key;
                $dmcf_groupmanager = isset($dmcf_groupmanagers[$key])?$dmcf_groupmanagers[$key]:array();
                if(is_array($dmcf_groupmanager) && count(array_intersect($dmcf_groupmanager, $current_user->roles)) > 0) {
                    ?>

                    <div class="panel panel-default" id="<?php echo $key; ?>">
                        <div class="panel-heading">
                            <b><?php _e($dmcf_group_names[$key], 'download-manager-custom-fields'); ?></b></div>
                        <div class="panel-body">
                            <?php
                            $this->dmcf_create_metabox($post, array('args' => array('my_data' => $meta_data)));
                            ?>
                        </div>
                    </div>

                    <?php

                    $count++;
                }
            }
        }
    }

    function dmcf_create_metabox($post, $meta_data)
    {


        wp_nonce_field('dmcf_meta_box', 'dmcf_meta_box_nonce');
        $wpdmpro_fields = get_post_meta($post->ID, '__wpdmpro_custom_fields', true);
        if(is_array($wpdmpro_fields)){
            foreach($wpdmpro_fields as $group => $fields){
                foreach($fields as $field => $value){
                    update_post_meta($post->ID, '__wpdm_acf_'.$group.'_'.$field, $value);
                }
            }
            delete_post_meta($post->ID, '__wpdmpro_custom_fields');
        }
        $dmcf_field_name = get_option('dmcf_field_name');
        $dmcf_field_name = get_option('dmcf_field_name');
        $dmcf_field_types = get_option('dmcf_field_type');
        $dmcf_field_choices = get_option('dmcf_field_choice');
        $dmcf_field_required = get_option('dmcf_field_required');

        $label_data = $meta_data['args']['my_data'];
        $group_name = $label_data['group'];
        unset($label_data['group']);
        echo "<div class='w3eden'>";
        foreach ($label_data as $key => $label) {
            $field_name = $dmcf_field_name[$group_name][$key];
            $field_type = $dmcf_field_types[$group_name][$key];
            $field_choices = $dmcf_field_choices[$group_name][$key];
            $field_choices_array = explode("\n", str_replace("\r", "", $field_choices));
            $meta_name = '__wpdm_acf_' . $group_name . '_' . $field_name;
            $meta_value = get_post_meta($post->ID,$meta_name, true);
            $required = '';
            if(isset($dmcf_field_required[$group_name]))
                $required = isset($dmcf_field_required[$group_name][$key]) && $dmcf_field_required[$group_name][$key] == 1? 'required=required' : '';
            $reqs = $required != ''?'<span class="text-danger">*</span>':'';
            $label = wpdm_escs(stripslashes_deep($label));
            $meta_value = wpdm_escs(stripslashes_deep($meta_value));

            ?>
            <div class="form-group">
            <?php
            if ($field_type == 'select') {
                ?>
                <label><?php echo $label; ?> <?php echo $reqs.$meta_value; ?></label>
                <select <?php echo $required; ?>  name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>" class="form-control">
                    <?php foreach ($field_choices_array as $key => $value) {
                        $value = explode("|", stripslashes_deep($value));
                        ?>
                        <option value="<?php echo $value[0] ?>" <?php
                        if ($meta_value == $value[0]) {
                            echo 'selected=selected';
                        } else {

                        }
                        ?>><?php echo isset($value[1]) ? $value[1] : $value[0]; ?></option>
                    <?php } ?>
                </select>
                <hr>
            <?php
            } else if ($field_type == 'radiobutton') {
                ?>
                <fieldset>
                    <legend><?php echo $label; ?> <?php echo $reqs; ?></legend>
                    <ul>
                        <?php
                        foreach ($field_choices_array as $key => $value) {
                            ?>
                            <li>
                                <label>
                                    <input type="radio"
                                           name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                                           value="<?php echo $value ?>" <?php
                                    if (!empty($meta_value) && $meta_value == $value) {
                                        echo 'checked=checked';
                                    } else {

                                    }
                                    ?>>
                                    <?php echo $value ?>
                                </label>
                            </li>
                        <?php
                        } ?>
                    </ul>
                </fieldset>
            <?php } else if ($field_type == 'checkbox') {
                if($label != ''){
                ?>
                <fieldset>
                    <legend><?php echo $label; ?> <?php echo $reqs; ?></legend>
                    <?php } ?>
                    <ul>
                        <?php
                        foreach ($field_choices_array as $key => $value) {
                            ?>
                            <li>
                                <label>
                                    <input
                                        name='<?php echo 'file[acf_' . $group_name . '_' . $field_name . '][' . $key . ']' ?>'
                                        value="<?php echo $value ?>" type="checkbox" <?php
                                    if (is_array($meta_value) && in_array($value, $meta_value)) {
                                        echo 'checked=checked';
                                    } else {

                                    }
                                    ?>> <?php echo $value ?>
                                </label>
                            </li>
                        <?php
                        } ?></ul>
                <?php if($label != ''){ ?></fieldset><?php } ?>
            <?php
            } else if ($field_type == 'text') {
                ?>
                <label><?php echo $label; ?> <?php echo $reqs; ?></label>
                <input <?php echo $required; ?> type="text" class="form-control" name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                       value="<?php echo $meta_value ?>"
                       />
            <?php
            } else if ($field_type == 'textarea') {
                ?>
                <fieldset>
                    <legend><?php echo $label; ?> <?php echo $reqs; ?></legend>
                    <textarea <?php echo $required; ?>  class="form-control" rows="5" cols="80"
                              name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                              ><?php echo $meta_value ?></textarea>
                </fieldset>
            <?php
            } else if ($field_type == 'number') {
                ?>
                <label><?php echo $label; ?> <?php echo $reqs; ?></label>
                <input <?php echo $required; ?>  type="number" class="form-control" name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                       value="<?php echo $meta_value ?>"
                       />
            <?php
            } else if ($field_type == 'email') {
                ?>
                <label><?php echo $label; ?> <?php echo $reqs; ?></label>
                <input <?php echo $required; ?>  type="email" class="form-control" name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                       value="<?php echo $meta_value ?>"
                       />
            <?php
            } else if ($field_type == 'url') {
                ?>
                <label><?php echo $label; ?> <?php echo $reqs; ?></label>
                <input <?php echo $required; ?>  type="url" class="form-control" name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                       value="<?php echo $meta_value ?>"
                       />
            <?php
            } else if ($field_type == 'date') {
                ?>
                <label><?php echo $label; ?> <?php echo $reqs; ?></label>
                <input <?php echo $required; ?>  type="date" class="form-control" name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                       value="<?php echo $meta_value ?>"
                       />
            <?php
            } else if ($field_type == 'hidden') {
                ?>
                <input type="hidden" name="<?php echo 'file[acf_' . $group_name . '_' . $field_name . ']' ?>"
                       value="<?php echo $meta_value ?>"
                       />
            <?php
            }
            echo '</div>';
        } ?>
        <style>
            .field-group {
                margin-bottom: 10px;
            }

            fieldset {
                border: 1px solid #eeeeee;
                padding: 10px;
            }

            legend {
                font-weight: bold;
            }
        </style>
        </div>
    <?php
    }

    function s2dcf_render($post, $meta_data, $extras = array())
    {

        wp_nonce_field('s2dcf_meta_box', 's2dcf_meta_box_nonce');
        //$wpdmpro_fields = get_post_meta($post->ID, '__wpdmpro_custom_fields', true);
        $dmcf_field_name = get_option('s2dcf_field_name');
        $dmcf_field_types = get_option('s2dcf_field_type');
        $dmcf_field_choices = get_option('s2dcf_field_choice');
        $s2dcf_hidden_values = get_option('s2dcf_hidden_values');
        $dmcf_field_required = get_option('s2dcf_field_required');
        $label_data = $meta_data;
        $name = isset($extras['field_name']) && $extras['field_name'] != ''?$extras['field_name']:'custom_form_field';
        $class = isset($extras['class']) && $extras['class'] != ''?$extras['class']:'';
        $values = isset($extras['values']) && $extras['values'] != ''?$extras['values']:array();
        $group_name = $label_data['group'];
        if(is_array($label_data)) {
            if(isset($label_data['group']))
                unset($label_data['group']);

            foreach ($label_data as $key => $value) {
                $field_name = $dmcf_field_name[$group_name][$key];
                $field_type = $dmcf_field_types[$group_name][$key];
                $field_choices = $dmcf_field_choices[$group_name][$key];
                $hidden_value = $s2dcf_hidden_values[$group_name][$key];
                $required = '';
                $_values = isset($values[$group_name])?$values[$group_name]:array();
                if (isset($dmcf_field_required[$group_name]))
                    $required = isset($dmcf_field_required[$group_name][$key]) && $dmcf_field_required[$group_name][$key] == 1 ? 'required=required' : '';
                $reqs = $required != '' ? '<span class="text-danger">*</span>' : '';
                $field_choices_array = explode("\n", str_replace("\r", "", $field_choices));

                $cvalue = isset($_values[$field_name])?$_values[$field_name]:'';
                $cvalue = esc_attr($cvalue);
                //[' . $group_name . ']
                ?>
                <div class="form-group">
                <?php
                if ($field_type == 'select') {
                    ?>
                    <label class="<?php echo $field_name; ?> regform-field-label"><?php echo wpdm_escs(stripslashes_deep($value)); ?><?php echo $reqs; ?></label>
                    <select <?php echo $required; ?> class="form-control wpdm-custom-select <?php echo $class; ?>"
                                                     name="<?php echo $name.'[' . $field_name . ']' ?>">
                        <?php foreach ($field_choices_array as $key => $value) {
                            $value = explode("|", stripslashes_deep($value));
                            $label = isset($value[1]) ? $value[1] : $value[0];
                            $value = $value[0];
                            $value = wpdm_escs(stripslashes_deep($value));
                            ?>
                            <option value="<?php echo $value ?>" <?php selected($value, $cvalue); ?> ><?php echo wpdm_escs(stripslashes_deep($label)) ?></option>
                        <?php } ?>
                    </select><br>
                    <?php
                } else if ($field_type == 'radiobutton') {
                    if(trim($value) != ''){
                    ?>
                    <fieldset>
                        <legend><?php echo wpdm_escs(stripslashes_deep($value)); ?><?php echo $reqs; ?></legend>
                    <?php } ?>
                        <ul style="padding: 0;margin: 0">
                            <?php
                            foreach ($field_choices_array as $key => $value) {
                                $value = explode("|", stripslashes_deep($value));
                                $label = isset($value[1]) ? $value[1] : $value[0];
                                $value = $value[0];
                                $value = wpdm_escs(stripslashes_deep($value));
                                ?>
                                <li <?php echo $required; ?> style="list-style: none;margin: 0;padding: 0">
                                    <label>
                                        <input class="wpdm-radio" type="radio"
                                               name="<?php echo $name.'[' . $field_name . ']' ?>"
                                               value="<?php echo esc_attr($value) ?>" <?php checked($value, $cvalue); ?>>
                                        <?php echo wpdm_escs(stripslashes_deep($label)) ?>
                                    </label>
                                </li>
                                <?php
                            } ?>
                        </ul>
                    <?php if(trim($value) != ''){ ?></fieldset><?php } ?>
                <?php } else if ($field_type == 'checkbox') {
                    if(trim($value) != ''){
                    ?>
                    <fieldset>
                        <legend style="font-size: inherit; color: inherit"><?php echo wpdm_escs(stripslashes_deep($value)); ?><?php echo $reqs; ?></legend>
                        <?php } ?>
                        <ul style="padding: 0;margin: 0">
                            <?php
                            foreach ($field_choices_array as $key => $value) {
                                $value = explode("|", stripslashes_deep($value));
                                $label = isset($value[1]) ? $value[1] : $value[0];
                                $value = $value[0];
                                $value = wpdm_escs(stripslashes_deep($value));
                                ?>
                                <li style="list-style: none;margin: 0;padding: 0">
                                    <label>
                                        <input <?php echo $required; ?> style="margin: -1px 5px 0 0 !important;vertical-align: middle" class="wpdm-checkbox" name='<?php echo $name.'[' . $field_name . '][' . $key . ']' ?>'
                                               value="<?php echo ($value) ?>" type="checkbox" <?php checked($value, $cvalue); ?>> <?php echo wpdm_escs(stripslashes_deep($label)) ?>
                                    </label>
                                </li>
                                <?php
                            } ?></ul>
                <?php if(trim($value) != ''){ ?></fieldset><?php } ?>
                    <?php
                } else if ($field_type == 'text') {
                    ?>
                    <label class="<?php echo $field_name; ?> regform-field-text regform-field-label"><?php echo $value; ?><?php echo $reqs; ?></label>
                    <input placeholder="<?php echo $value; ?>" class="form-control <?php echo $class; ?>" <?php echo $required; ?> type="text"
                           name="<?php echo $name.'[' . $field_name . ']' ?>" value="<?php echo $cvalue; ?>"/>
                    <?php
                } else if ($field_type == 'textarea') {
                    ?>

                    <label class="<?php echo $field_name; ?> regform-field-textarea regform-field-label"><?php echo $value; ?><?php echo $reqs; ?></label>
                    <textarea placeholder="<?php echo $value; ?>" class="form-control <?php echo $class; ?>"<?php echo $required; ?> rows="5" cols="80"
                              name="<?php echo $name.'[' . $field_name . ']' ?>"><?php echo $cvalue; ?></textarea>

                    <?php
                } else if ($field_type == 'number') {
                    ?>
                    <label class="<?php echo $field_name; ?> regform-field-number regform-field-label"><?php echo $value; ?><?php echo $reqs; ?></label>
                    <input placeholder="<?php echo $value; ?>" class="form-control <?php echo $class; ?>" type="number" <?php echo $required; ?>
                           name="<?php echo $name.'[' . $field_name . ']' ?>" value="<?php echo $cvalue; ?>"/>
                    <?php
                } else if ($field_type == 'email') {
                    ?>
                    <label class="<?php echo $field_name; ?> regform-field-email regform-field-label"><?php echo $value; ?><?php echo $reqs; ?></label>
                    <input placeholder="<?php echo $value; ?>" class="form-control <?php echo $class; ?>" type="email" <?php echo $required; ?>
                           name="<?php echo $name.'[' . $field_name . ']' ?>" value="<?php echo $cvalue; ?>"/>
                    <?php
                } else if ($field_type == 'url') {
                    ?>
                    <label class="<?php echo $field_name; ?> regform-field-url regform-field-label"><?php echo $value; ?><?php echo $reqs; ?></label>
                    <input placeholder="<?php echo $value; ?>" class="form-control <?php echo $class; ?>" type="url" <?php echo $required; ?>
                           name="<?php echo $name.'[' . $field_name . ']' ?>" value="<?php echo $cvalue; ?>"/>
                    <?php
                } else if ($field_type == 'date') {
                    ?>
                    <label class="<?php echo $field_name; ?> regform-field-date regform-field-label"><?php echo $value; ?><?php echo $reqs; ?></label>
                    <input class="form-control <?php echo $class; ?>" type="date" <?php echo $required; ?>
                           name="<?php echo $name.'[' . $field_name . ']' ?>" value="<?php echo $cvalue; ?>"/>
                    <?php
                } else if ($field_type == 'hidden') {
                    ?>
                    <input type="hidden" name="<?php echo $name.'[' . $field_name . ']' ?>"
                           value="<?php echo $hidden_value ?>"/>
                    <?php
                }
                echo '</div>';
            } ?>

            <?php
        }
    }


    function dmcf_custom_fields()
    {
        add_submenu_page("edit.php?post_type=wpdmpro", __('Custom Fields', 'download-manager-custom-field'), __('Custom Fields', 'download-manager-custom-field'), 'manage_options', 'wpdm-acf', array($this, 'dmcf_add_custom_fields'));
    }

    function dmcf_add_custom_fields()
    {
        include(DMCF_BASE_DIR . 'tpls/dmcf-create-field.php');
    }

    function dmcf_enqueue_scripts($hook){
        wp_enqueue_script('jquery-form');
    }
    function dmcf_admin_enqueue_scripts($hook)
    {

        if ($hook == 'wpdmpro_page_settings'){
            wp_enqueue_script('d2scf-admin-js', plugins_url('wpdm-advanced-custom-fields/js/wpdm-acf.js'));
        }
        if ($hook != 'wpdmpro_page_wpdm-acf') return;
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-form');
        //wp_enqueue_style('dmcf-admin-bootstrap-css', WPDM_BASE_URL . 'assets/bootstrap/css/bootstrap.css');
        //wp_enqueue_style('dmcf-admin-font-awesome-css', WPDM_BASE_URL . 'assets/fontawesome/css/all.css');
        //wp_enqueue_script('dmcf-admin-bootstrap-js', WPDM_BASE_URL . 'assets/bootstrap/js/bootstrap.min.js');
    }

    function dmcf_save_field()
    {
        $dmcf_field_label = array();
        $dmcf_field_required = array();
        $dmcf_field_name = array();
        $dmcf_field_type = array();
        $dmcf_field_choice = array();
        $dmcf_field_label = $_REQUEST['field-label'];
        $dmcf_field_required = $_REQUEST['field-required'];
        $dmcf_field_name = $_REQUEST['field-name'];
        $dmcf_field_type = $_REQUEST['field-type'];
        $dmcf_field_choice = $_REQUEST['field-choices'];
        $dmcf_group_names = $_REQUEST['groupnames'];
        $dmcf_groupmanagers = $_REQUEST['groupmanagers'];
        $dmcf_groupviewers = $_REQUEST['groupviewers'];
        //if (!empty($dmcf_field_name) || !empty($dmcf_field_label) || !empty($dmcf_field_type) || !empty($dmcf_field_choice)) {
            update_option('dmcf_field_label', $dmcf_field_label);
            update_option('dmcf_field_required', $dmcf_field_required);
            update_option('dmcf_field_name', $dmcf_field_name);
            update_option('dmcf_field_type', $dmcf_field_type);
            update_option('dmcf_field_choice', $dmcf_field_choice);
            update_option('dmcf_group_names', $dmcf_group_names);
            update_option('dmcf_groupmanagers', $dmcf_groupmanagers);
            update_option('dmcf_groupviewers', $dmcf_groupviewers);
            echo 'Saved successfully';
            die;
       // } else {
       //     die('Error: No field created yet');
       // }
    }

    function exportGroup(){

        if(wpdm_query_var('task') === 'dmcf_export_group' && current_user_can(WPDM_ADMIN_CAP)){
            $groupid = wpdm_query_var('groupid');
            $dmcf_fields_label = get_option('dmcf_field_label');
            $dmcf_fields_required = get_option('dmcf_field_required');
            $dmcf_fields_name = get_option('dmcf_field_name');
            $dmcf_fields_types = get_option('dmcf_field_type');
            $dmcf_fields_choice = get_option('dmcf_field_choice');
            $dmcf_group_names = get_option('dmcf_group_names');

            $export_data = array(
              'dmcf_group_name' => $dmcf_group_names[$groupid],
              'dmcf_field_choice' => $dmcf_fields_choice[$groupid],
              'dmcf_field_type' => $dmcf_fields_types[$groupid],
              'dmcf_field_name' => $dmcf_fields_name[$groupid],
              'dmcf_field_required' => $dmcf_fields_required[$groupid],
              'dmcf_field_label' => $dmcf_fields_label[$groupid],
              'group_id' => $groupid
            );

            $data = json_encode($export_data);

            \WPDM\libs\FileSystem::downloadData($groupid.".json", $data);
            die();
        }

    }

    function importGroup(){
        if(wp_verify_nonce(wpdm_query_var('_jsongif_nonce'), NONCE_KEY) && current_user_can(WPDM_ADMIN_CAP)){

            $source_file = $_FILES['jsongif']['tmp_name'];


            $dmcf_fields_label = get_option('dmcf_field_label');
            $dmcf_fields_required = get_option('dmcf_field_required');
            $dmcf_fields_name = get_option('dmcf_field_name');
            $dmcf_fields_types = get_option('dmcf_field_type');
            $dmcf_fields_choice = get_option('dmcf_field_choice');
            $dmcf_group_names = get_option('dmcf_group_names');

            $import_data = file_get_contents($source_file);
            $import_data = (array)json_decode($import_data);

            $groupid = $import_data['group_id'];

            if(isset($dmcf_group_names[$groupid])) $groupid = $groupid."New";

            $dmcf_group_names[$groupid] = $import_data['dmcf_group_name'];
            $dmcf_fields_choice[$groupid] = $import_data['dmcf_field_choice'];
            $dmcf_fields_types[$groupid] = $import_data['dmcf_field_type'];
            $dmcf_fields_name[$groupid] = $import_data['dmcf_field_name'];
            $dmcf_fields_required[$groupid] = $import_data['dmcf_field_required'];
            $dmcf_fields_label[$groupid] = $import_data['dmcf_field_label'];

            update_option('dmcf_group_names', $dmcf_group_names);
            update_option('dmcf_field_choice', $dmcf_fields_choice);
            update_option('dmcf_field_type', $dmcf_fields_types);
            update_option('dmcf_field_name', $dmcf_fields_name);
            update_option('dmcf_field_required', $dmcf_fields_required);
            update_option('dmcf_field_label', $dmcf_fields_label);

            die('ok');
        }
    }

}

function wpdm_import_field_group($file){
    $dmcf_fields_label = get_option('dmcf_field_label');
    $dmcf_fields_required = get_option('dmcf_field_required');
    $dmcf_fields_name = get_option('dmcf_field_name');
    $dmcf_fields_types = get_option('dmcf_field_type');
    $dmcf_fields_choice = get_option('dmcf_field_choice');
    $dmcf_group_names = get_option('dmcf_group_names');

    $import_data = file_get_contents($file);
    $import_data = (array)json_decode($import_data);

    $groupid = $import_data['group_id'];

    if(isset($dmcf_group_names[$groupid])) $groupid = $groupid."New";

    $dmcf_group_names[$groupid] = $import_data['dmcf_group_name'];
    $dmcf_fields_choice[$groupid] = $import_data['dmcf_field_choice'];
    $dmcf_fields_types[$groupid] = $import_data['dmcf_field_type'];
    $dmcf_fields_name[$groupid] = $import_data['dmcf_field_name'];
    $dmcf_fields_required[$groupid] = $import_data['dmcf_field_required'];
    $dmcf_fields_label[$groupid] = $import_data['dmcf_field_label'];

    update_option('dmcf_group_names', $dmcf_group_names);
    update_option('dmcf_field_choice', $dmcf_fields_choice);
    update_option('dmcf_field_type', $dmcf_fields_types);
    update_option('dmcf_field_name', $dmcf_fields_name);
    update_option('dmcf_field_required', $dmcf_fields_required);
    update_option('dmcf_field_label', $dmcf_fields_label);
}

function wpdm_acf($post_id, $name)
{
    $orgn_name = $name;
    $name = '__wpdm_acf_'.str_replace("/", "_", $name);
    return get_post_meta($post_id, $name, true);

}

if(defined('WPDM_Version'))
new wpdm_acf();
