<?php
//Settings Page
defined('ABSPATH') or die('?'); ?>
<style>
    .dmcf-inline-class{
        display: inline !important;
    }
    .panel-heading a,
    .panel-heading a:focus,
    .panel-heading a:hover{
        text-decoration: none !important;
        color: #336699;
        outline: none;
        padding-left: 24px;
        position: relative;
    }
    .panel-heading a:before{
        content: "\f07c";
        font-family: "Font Awesome 5 Free";
        padding-right: 5px;
        position: absolute;
        color: #4583ed;
        display: inline-block;
        left: 0;
        font-weight:900;
        top: 3px;
        font-size: 10pt;
    }
    .panel-heading a.collapsed{
        color: #222222;
    }
    .panel-heading a.collapsed:before{
        content: "\f07b";
        font-family: "Font Awesome 5 Free";
        position: absolute;
        padding-right: 5px;
        color: #555555;
    }
    .panel-footer{
        border-top: 1px solid #ddd !important;
    }
    label {
        color: #888;
    }
</style>
<div class="panel panel-default">
    <div class="panel-heading"><?php echo __("Quick Forms", "wpdmpro"); ?></div>
    <div id="dmcf-message-label"></div>
    <div class="panel-body">
        <div id="custom-field-body" class="panel-group">
            <?php
            $s2dcf_fields_label = get_option('s2dcf_field_label');
            $s2dcf_fields_name = get_option('s2dcf_field_name');
            $s2dcf_fields_types = get_option('s2dcf_field_type');
            $s2dcf_fields_choice = get_option('s2dcf_field_choice');
            $s2dcf_hidden_values = get_option('s2dcf_hidden_values');
            $s2dcf_group_names = get_option('s2dcf_group_names');
            $dmcf_fields_required = get_option('s2dcf_field_required');
            $s2dcf_userinf = get_option('s2dcf_userinf');

            //wpdmprecho($s2dcf_userinf);
            //delete_option('s2dcf_field_label');
            //delete_option('s2dcf_field_name');
            //delete_option('s2dcf_field_type');
            //delete_option('s2dcf_field_choice');
            //delete_option('s2dcf_group_names');

            $total_array = count($s2dcf_fields_label);
            $s2dcf_flag = 0;
            $count_group = 0;

            if (!empty($s2dcf_fields_label)) {
                foreach ($s2dcf_fields_label as $key => $group) {
                    $s2dcf_flag = $s2dcf_flag + 1;

                    //wpdmprecho($group);
                    ?>
                    <div id='dmcf-new-group-<?php echo $key; ?>' class='panel panel-default panel-acf-group' style="border-color: #eee;">
                        <div class='panel-heading'>
                            <h4 class='panel-title'>
                                <a data-toggle='collapse' data-parent='#custom-field-body' href='#dmcf-group<?php echo $s2dcf_flag; ?>' >
                                    <?php echo esc_attr($s2dcf_group_names[$key]); ?>
                                </a>
                                <span rel='<?php echo $key; ?>' type='button' style='margin:-4px -9px 0 5px;' class='dmcf-delete-group pull-right btn btn-danger btn-sm'><i class='fas fa-trash'></i> Delete Form</span>
                                <span data-group='<?php echo $key; ?>' rel='<?php echo $s2dcf_flag; ?>' style="margin-top: -4px" type='button' class='dmcf-add-field pull-right btn btn-secondary btn-sm'><i class='fas fa-plus-circle'></i> Add New Field</span>
                                <input type='hidden' name='groupnames[<?php echo $key ;?>]' value='<?php echo $s2dcf_group_names[$key]; ?>' />
                            </h4>
                        </div>
                        <div id='dmcf-group<?php echo $s2dcf_flag; ?>' class='panel-collapse collapse in'>
                            <div class='panel-body' style="border-color: #eee;">
                                <div id ='panel-group-<?php echo $s2dcf_flag; ?>' class='panel-group'>
                                    <?php
                                    foreach ($group as $field_key => $field_value) { $fid = uniqid();
                                        ?>
                                        <div id='dmcf-new-field-<?php echo $key . $field_key ?>' class='panel panel-default' style="border-color: #eee;">
                                            <div class='panel-heading'>
                                                <h4 class ='panel-title'>
                                                    <a class="collapsed" data-toggle = 'collapse' data-parent = '#panel-group-<?php echo $s2dcf_flag; ?>' href = '#<?php echo $key . $field_key; ?>' >
                                                        <?php echo esc_attr(stripslashes($field_value)); ?>
                                                    </a>
                                                    <span rel='<?php echo $key . $field_key ?>' type='button' class='dmcf-delete-field pull-right btn btn-danger btn-xs'><i class='fas fa-trash'></i></span>
                                                </h4>
                                            </div>
                                            <div id='<?php echo $key . $field_key ?>' class='panel-collapse collapse'>
                                                <div id = 'panel-<?php echo $key . $field_key; ?>' class='panel-body' style="border-color: #eee;">
                                                    <div class="form-group row">
                                                        <div class="col-md-6">
                                                            <label>Field Label</label>
                                                            <input type = 'text' name= 'field-label[<?php echo $key; ?>][]' value="<?php echo isset($field_value) ? esc_attr(stripslashes($field_value)) : '' ?>" class= 'form-control'  />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label>Field Name</label>
                                                            <input type = 'text' onkeyup="jQuery('#tt<?php echo $fid; ?>').val('[wpdm_acf-<?php echo $key; ?>-'+this.value+']');" name= 'field-name[<?php echo $key; ?>][]' value="<?php echo isset($s2dcf_fields_name[$key][$field_key]) ? esc_attr(stripslashes($s2dcf_fields_name[$key][$field_key])) : '' ?>" class= 'form-control'  />
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <div class="col-md-6">
                                                            <label>Field Type</label><br/>
                                                            <select data-identity="<?php echo $key . $field_key; ?>" id='field-state-<?php echo $key . $field_key; ?>' name= 'field-type[<?php echo $key; ?>][]' class = 's2dcf_field_select form-control wpdm-custom-select system-ui' >
                                                                <option value= 'text' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'text') ? 'selected=selected' : '' ?>>Text</option>
                                                                <option value= 'email' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'email') ? 'selected=selected' : '' ?>>Email</option>
                                                                <option value= 'textarea' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'textarea') ? 'selected=selected' : '' ?>>TextArea</option>
                                                                <option value= 'number' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'number') ? 'selected=selected' : '' ?>>Number</option>
                                                                <option value= 'select' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'select') ? 'selected=selected' : '' ?>>Select</option>
                                                                <option value= 'checkbox' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'checkbox') ? 'selected=selected' : '' ?>>Checkbox</option>
                                                                <option value= 'radiobutton' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'radiobutton') ? 'selected=selected' : '' ?>>Radiobutton</option>
                                                                <option value= 'hidden' <?php echo (isset($s2dcf_fields_types[$key][$field_key]) && $s2dcf_fields_types[$key][$field_key] == 'hidden') ? 'selected=selected' : '' ?>>Hidden</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label>Required Attribute</label><br/>
                                                            <select name= 'field-required[<?php echo $key; ?>][]' class = 's2dcf_field_select form-control wpdm-custom-select system-ui' >
                                                                <option value= '0' <?php echo (isset($dmcf_fields_required[$key][$field_key]) && $dmcf_fields_required[$key][$field_key] == '0') ? 'selected=selected' : '' ?>>Not Required</option>
                                                                <option value= '1' <?php echo (isset($dmcf_fields_required[$key][$field_key]) && $dmcf_fields_required[$key][$field_key] == '1') ? 'selected=selected' : '' ?>>Required</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <div id = 'field-choice-<?php echo $key . $field_key; ?>' class="<?php
                                                        if ($s2dcf_fields_types[$key][$field_key] == 'select' || $s2dcf_fields_types[$key][$field_key] == 'checkbox' || $s2dcf_fields_types[$key][$field_key] == 'radiobutton') {

                                                        } else {
                                                            echo 'hide';
                                                        }
                                                        ?>">
                                                            <label>Choices</label>
                                                            <textarea name = 'field-choices[<?php echo $key; ?>][]' rows = '6' placeholder = 'Enter one choice in every new line' class = 'form-control' ><?php echo esc_attr(stripslashes($s2dcf_fields_choice[$key][$field_key])); ?></textarea><br>
                                                        </div>
                                                        <div id = 'field-choice-<?php echo $key . $field_key; ?>-hidden' class="<?php
                                                        if ($s2dcf_fields_types[$key][$field_key] == 'hidden') {
                                                        } else {
                                                            echo 'hide';
                                                        }
                                                        ?>">
                                                            <label>Value</label>
                                                            <input type="text" name = 'hidden-values[<?php echo $key; ?>][]' class = 'form-control'  value="<?php echo esc_attr(stripslashes($s2dcf_hidden_values[$key][$field_key])); ?>" /><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                            </div>
                            <div class="panel-footer">
                                <label style="margin-right: 15px"><input type="hidden" name="userinf[<?php echo $key ;?>][profile]" value="0"/><input type="checkbox" <?php checked(1, isset($s2dcf_userinf[$key], $s2dcf_userinf[$key]['profile'])?$s2dcf_userinf[$key]['profile']:0) ?> name="userinf[<?php echo $key ;?>][profile]" value="1"/> User profile fields</label>
                                <label><input type="hidden" name="userinf[<?php echo $key ;?>][regform]" value="0"/> <input type="checkbox" <?php checked(1, isset($s2dcf_userinf[$key], $s2dcf_userinf[$key]['regform'])?$s2dcf_userinf[$key]['regform']:0) ?> name="userinf[<?php echo $key ;?>][regform]" value="1"/> Show in user registration form</label>
                            </div>
                            <div class="panel-footer">
                                <div class="input-group">
                                    <span class="input-group-addon">Short-code:</span>
                                    <input onfocus="this.select()" type="text" class="form-control input-sm" readonly value="[wpdm_quick_form id='<?php echo $key; ?>' email='<?php echo get_option('admin_email');?>']" style="background: #ffffff;font-family: monospace;">
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    $count_group++;
                }
            }
            ?>
        </div>
    </div>
    <div  class="panel-footer">
        <input id="dmcf-group-input" type="text" name="group-name" placeholder="Enter Form Name" class="dmcf-inline-class form-control" style="width: 250px" />
        <input id="dmcf-add-group" type="button" style="margin-bottom: 3px" class="dmcf-inline-class btn btn-primary" value="Create Form" />
        <span id="dmcf-loading-custom-field" class="hide" style="margin-left: 20px;"><i class="fa fa-spinner fa-spin"></i> Please wait.....</span>
    </div>
</div>