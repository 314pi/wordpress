<?php defined('ABSPATH') or die('?');
//Menu Page
?>
<style>
    .dmcf-inline-class{
        display: inline !important;
    }
    .panel-heading a,
    .panel-heading a:focus,
    .panel-heading a:hover{
        text-decoration: none !important;
        color: #336699;
        outline: none;
    }
    .panel-heading a:before{
        content: "\f056";
        font-family: "Font Awesome 5 Free";
        padding-right: 5px;
        color: #336699;
        font-weight: 900;
        display: inline-block;
    }
    .panel-heading a.collapsed{
        color: #222222;
    }
    .panel-heading a.collapsed:before{
        content: "\f055";
        font-family: "Font Awesome 5 Free";
        padding-right: 5px;
        color: #222222;
    }
    .btn.dmcf-add-field{
        margin: 0 !important;
    }

    .panel-footer.panel-footer-display-settings{
        border-top: 1px solid #dddddd !important;
        border-bottom: 1px solid #dddddd;
        border-radius: 0 !important;
    }


</style>
<div class="wrap w3eden">
    <div id="wpdm-wrapper-panel" class="panel panel-default">
        <div class="panel-heading">
            <button type="button" id="submit__dmcf" class="btn btn-primary pull-right"><i class="sinc far fa-hdd"></i> &nbsp;Save All Changes</button>
            <b style="font-size: 12pt;line-height:28px"><i class="fa fa-code"></i> &nbsp; <?php echo __("Advanced Custom Fields", "wpdmpro"); ?></b>

            <div style="clear: both"></div>
        </div>
        <div class="panel-body" style="padding: 60px 10px 0 10px;">


            <div id="dmcf-message-label">

            </div>
            <form id="save-custom-field" class="form" method="post">
                <div class="panel-body">
                <input type="hidden" name="action" value="save_dmcf_custom_field" />
                <!--<div class="form-control">-->
                <div id="custom-field-body" class="panel-group">
                    <?php
                    $dmcf_fields_label = get_option('dmcf_field_label');

                    $dmcf_fields_required = get_option('dmcf_field_required');
                    $dmcf_fields_name = get_option('dmcf_field_name');
                    $dmcf_fields_types = get_option('dmcf_field_type');
                    $dmcf_fields_choice = get_option('dmcf_field_choice');
                    $dmcf_group_names = get_option('dmcf_group_names');
//                    delete_option('dmcf_field_label');
//                    delete_option('dmcf_field_name');
//                    delete_option('dmcf_field_type');
//                    delete_option('dmcf_field_choice');
//                    delete_option('dmcf_group_names');
                    $total_array = is_array($dmcf_fields_label)?count($dmcf_fields_label):0;
                    $dmcf_flag = 0;
                    $count_group = 0;
                    if (!empty($dmcf_fields_label)) {
                        foreach ($dmcf_fields_label as $key => $group) {
                            $dmcf_flag = $dmcf_flag + 1;
                            ?>
                            <div id='dmcf-new-group-<?php echo $key; ?>' class='panel panel-default panel-acf-group'>
                                <div class='panel-heading'>
                                    <h4 class ='panel-title'>
                                        <a data-toggle = 'collapse' data-parent = '#custom-field-body' href = '#dmcf-group<?php echo $dmcf_flag; ?>' >
                                            <?php echo esc_attr(stripslashes($dmcf_group_names[$key])) ?>
                                        </a>
                                        <span rel='<?php echo $key; ?>' type='button' style='margin-left:5px;' class='dmcf-delete-group pull-right btn btn-danger btn-xs'><i class='fa fa-trash-o'></i> Delete Group</span>
                                        <span  rel='<?php echo $key; ?>' style='margin-left:5px;' class='dmcf-export-group pull-right btn btn-info btn-xs'><i class='fas fa-file-export'></i> Export Group</span>
                                        <span data-group='<?php echo $key; ?>' rel='<?php echo $dmcf_flag; ?>' type='button' class='dmcf-add-field pull-right btn btn-primary btn-xs'><i class='fa fa-plus'></i> Add New Field</span>
                                        <input type='hidden' name='groupnames[<?php echo $key ;?>]' value='<?php echo $dmcf_group_names[$key]; ?>' />
                                    </h4>
                                </div>

                                <div id='dmcf-group<?php echo $dmcf_flag; ?>' class='panel-collapse collapse in'>
                                    <div class='panel-body'>
                                        <div id ='panel-group-<?php echo $dmcf_flag; ?>' class='panel-group'>
                                            <?php
                                            foreach ($group as $field_key => $field_value) { $fid = uniqid();
                                                ?>
                                                <div id='dmcf-new-field-<?php echo $key . $field_key ?>' class='panel panel-default'>
                                                    <div class='panel-heading'>
                                                        <h4 class ='panel-title'>
                                                            <a class="collapsed" data-toggle = 'collapse' data-parent = '#panel-group-<?php echo $dmcf_flag; ?>' href = '#<?php echo $key . $field_key; ?>' >
                                                                <?php echo esc_attr(stripslashes($field_value)); ?>
                                                            </a>
                                                            <span rel='<?php echo $key . $field_key ?>' type='button' class='dmcf-delete-field pull-right btn btn-danger btn-xs'><i class='fa fa-trash-o'></i> Delete Field</span>
                                                        </h4>
                                                    </div>
                                                    <div id='<?php echo $key . $field_key ?>' class='panel-collapse collapse'>
                                                        <div id = 'panel-<?php echo $key . $field_key; ?>' class='panel-body'>
                                                            <label>Field Label</label>
                                                            <input type = 'text' name= 'field-label[<?php echo $key; ?>][]' value="<?php echo isset($field_value) ? esc_attr(stripslashes($field_value)) : '' ?>" class= 'form-control' style = 'width: 400px;' /><br>
                                                            <label>Field Name</label>
                                                            <input type = 'text' onkeyup="jQuery('#tt<?php echo $fid; ?>').val('[acf_<?php echo $key; ?>_'+this.value+']');" name= 'field-name[<?php echo $key; ?>][]' value="<?php echo isset($dmcf_fields_name[$key][$field_key]) ? esc_attr(stripslashes($dmcf_fields_name[$key][$field_key])) : '' ?>" class= 'form-control' style = 'width: 400px;' /><br>
                                                            <label>Field Type</label>
                                                            <select data-identity="<?php echo $key . $field_key; ?>" id='field-state-<?php echo $key . $field_key; ?>' name= 'field-type[<?php echo $key; ?>][]' class = 'dmcf_field_select form-control' style = 'width: 400px;'>
                                                                <option value= 'text' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'text') ? 'selected=selected' : '' ?>>Text</option>
                                                                <option value= 'textarea' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'textarea') ? 'selected=selected' : '' ?>>TextArea</option>
                                                                <option value= 'number' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'number') ? 'selected=selected' : '' ?>>Number</option>
                                                                <option value= 'email' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'email') ? 'selected=selected' : '' ?>>Email</option>
                                                                <option value= 'url' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'url') ? 'selected=selected' : '' ?>>URL</option>
                                                                <option value= 'date' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'date') ? 'selected=selected' : '' ?>>Date</option>
                                                                <option value= 'select' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'select') ? 'selected=selected' : '' ?>>Select</option>
                                                                <option value= 'checkbox' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'checkbox') ? 'selected=selected' : '' ?>>Checkbox</option>
                                                                <option value= 'radiobutton' <?php echo (isset($dmcf_fields_types[$key][$field_key]) && $dmcf_fields_types[$key][$field_key] == 'radiobutton') ? 'selected=selected' : '' ?>>Radiobutton</option>
                                                            </select><br>
                                                            <div id = 'field-choice-<?php echo $key . $field_key; ?>' class="<?php
                                                            if ($dmcf_fields_types[$key][$field_key] == 'select' || $dmcf_fields_types[$key][$field_key] == 'checkbox' || $dmcf_fields_types[$key][$field_key] == 'radiobutton') {

                                                            } else {
                                                                echo 'hide';
                                                            }
                                                            ?>">
                                                                <label>Choices</label>
                                                                <textarea name = 'field-choices[<?php echo $key; ?>][]' rows = '6' placeholder = 'Enter one choice in every new line' class = 'form-control' style = 'width: 400px;'><?php echo esc_attr(stripslashes($dmcf_fields_choice[$key][$field_key])); ?></textarea><br>
                                                            </div>
                                                            <label>User Input Requirement:</label>
                                                            <select class="form-control"  style = 'width: 400px;' name= 'field-required[<?php echo $key; ?>][]'><option value='0' <?php selected($dmcf_fields_required[$key][$field_key], 0); ?>>Optional Field</option><option value='1' <?php selected($dmcf_fields_required[$key][$field_key], 1); ?>>Required Field</option></select>
                                                            <br>
                                                        </div>

                                                    </div>
                                                    <div class="panel-footer">
                                                        Template Tag: <input onfocus="this.select()" id="tt<?php echo $fid;?>" class="ttp" title="Use this tag in link or page template to show field data" data-toggle="tooltip" style="border: 0;color: #3173AD;width: 300px;text-align: center;font-family: 'Courier New'"  type="text" value="[acf_<?php echo $key; ?>_<?php echo isset($dmcf_fields_name[$key][$field_key]) ? $dmcf_fields_name[$key][$field_key] : '' ?>]" />
                                                        <div class="pull-right">&nbsp;PHP Code: <input onfocus="this.select()" class="ttp" data-toggle="tooltip" style="border: 0;width: 500px;text-align: center;font-family: 'Courier New';color: #3173AD" type="text" value="<?php echo '&lt;?php echo wpdm_acf([ID],\''.$key.'/'.$dmcf_fields_name[$key][$field_key].'\'); ?&gt;'; ?>" /></div>

                                                    </div>

                                                </div>
                                            <?php }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer" style="border-top: 1px solid #dddddd !important;background: #fff6f1 !important">
                                    <div class="panel panel-default" style="margin: 0;border-radius: 2px;box-shadow: none">
                                        <div class="panel-heading" style="background-image: none;background: #f5f5f5;border-bottom: 1px solid #dddddd !important;">Who Can Manage:</div>
                                        <div class="panel-body">
                                            <?php

                                            $dmcf_groupmanagers = get_option('dmcf_groupmanagers', array());
                                            $selz = '';
                                            $dmcf_groupmanagers = is_array($dmcf_groupmanagers) && isset($dmcf_groupmanagers[$key])?$dmcf_groupmanagers[$key]: array();
                                            ?>

                                            <?php
                                            global $wp_roles;
                                            $roles = array_reverse($wp_roles->role_names);
                                            foreach( $roles as $role => $name ) {



                                                if(  is_array($dmcf_groupmanagers) ) $sel = (in_array($role,$dmcf_groupmanagers))?'checked=checked':'';
                                                else $sel = '';



                                                ?>
                                                <label><input name="groupmanagers[<?php echo $key; ?>][]" type="checkbox" value="<?php echo $role; ?>" <?php echo $sel  ?>> <?php echo $name; ?></label>
                                            <?php } ?>
                                        </div>

                                    </div>
                                    <div class="panel panel-default" style="margin: 5px 0 0;border-radius: 2px;box-shadow: none">
                                        <div class="panel-heading" style="background-image: none;background: #f5f5f5;border-bottom: 1px solid #dddddd !important;">Who Can View:</div>
                                        <div class="panel-body">
                                        <?php

                                        $dmcf_groupviewers = get_option('dmcf_groupviewers', array());
                                        $dmcf_groupviewers = is_array($dmcf_groupviewers) && isset($dmcf_groupviewers[$key])?$dmcf_groupviewers[$key]: array();
                                        $selz = '';
                                        if(  is_array($dmcf_groupviewers) ) $selz = (in_array('guest',$dmcf_groupviewers))?'checked=checked':'';
                                        if(!isset($_GET['post']) && !$dmcf_groupviewers) $selz = 'checked=checked';
                                        ?>

                                        <label><input type="checkbox" name="groupviewers[<?php echo $key; ?>][]" value="guest" <?php echo $selz  ?>> <?php echo __( "All Visitors" , "download-manager" ); ?></label>
                                        <?php
                                        global $wp_roles;
                                        $roles = array_reverse($wp_roles->role_names);
                                        foreach( $roles as $role => $name ) {



                                            if(  is_array($dmcf_groupviewers) ) $sel = (in_array($role,$dmcf_groupviewers))?'checked=checked':'';
                                            else $sel = '';



                                            ?>
                                            <label><input name="groupviewers[<?php echo $key; ?>][]" type="checkbox" value="<?php echo $role; ?>" <?php echo $sel  ?>> <?php echo $name; ?></label>
                                        <?php } ?>
                                        </div>

                                    </div>
                                </div>

                                <div class="panel-footer" style="border-top: 1px solid #dddddd !important;">
                                    Template Tag: <input onfocus="this.select()" class="ttp" title="Use this tag in link or page template to show group data" data-toggle="tooltip" style="border: 0;color: #3173AD;width: 300px;text-align: center;font-family: 'Courier New'" type="text" value="[acf_group_<?php echo $key; ?>]" />
                                    <div class="pull-right">&nbsp;PHP Code: <input onfocus="this.select()" class="ttp" data-toggle="tooltip" style="border: 0;width: 500px;text-align: center;font-family: 'Courier New';color: #3173AD" type="text" value="<?php echo '&lt;?php echo wpdm_acf::acf_group([ID],\''.$key.'\'); ?&gt;'; ?>" /></div>

                                </div>
                            </div>
                            <?php
                            $count_group++;
                        }
                    }
                    ?>
                </div>
                </div>

                <div  class="panel-footer">
                    <div class="pull-left">
                        <input id="dmcf-group-input" type="text" name="group-name" placeholder="Enter a Group Name" class="dmcf-inline-class form-control" style="width: 250px" />
                        <input id="dmcf-add-group" type="button" style="margin-bottom: 3px" class="dmcf-inline-class btn btn-primary" value="Add Group" />
                    </div>
                    <div style="display: inline-block;float: left;margin-left: 10px">
                        <div id="wpdm-upload-ui" class="text-center image-selector-panel">
                            <div id="wpdm-drag-drop-area">

                                <button id="wpdm-jsongif-button" type="button" class="btn btn-info"><i class="fas fa-file-import"></i> <?php _e("Import Group", "download-manager");  ?></button>
                                <div class="progress" id="wmprogressbar" style="height: 43px !important;border-radius: 3px !important;margin: 0;position: relative;background: #0d406799;display: none;box-shadow: none">
                                    <div id="wmprogress" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;line-height: 43px;background-color: #007bff"></div>
                                    <div class="fetfont" style="font-size:9px;position: absolute;line-height: 43px;height: 43px;width: 100%;z-index: 999;text-align: center;color: #ffffff;font-weight: 800;letter-spacing: 1px">UPLOADING... <span id="wmloaded">0</span>%</div>
                                </div>



                                <?php

                                $plupload_init = array(
                                    'runtimes'            => 'html5,silverlight,flash,html4',
                                    'browse_button'       => 'wpdm-jsongif-button',
                                    'container'           => 'wpdm-upload-ui',
                                    'drop_element'        => 'wpdm-drag-drop-area',
                                    'file_data_name'      => 'jsongif',
                                    'multiple_queues'     => false,
                                    'url'                 => admin_url('admin-ajax.php'),
                                    'flash_swf_url'       => includes_url('js/plupload/plupload.flash.swf'),
                                    'silverlight_xap_url' => includes_url('js/plupload/plupload.silverlight.xap'),
                                    'filters'             => array(array('title' => __('Allowed Files'), 'extensions' => 'json')),
                                    'multipart'           => true,
                                    'urlstream_upload'    => true,

                                    // additional post data to send to our ajax hook
                                    'multipart_params'    => array(
                                        '_jsongif_nonce' => wp_create_nonce(NONCE_KEY),
                                        'action'      => 'dmcf_import_group',            // the ajax action name
                                    ),
                                );

                                $plupload_init['max_file_size'] = wp_max_upload_size().'b';

                                // we should probably not apply this filter, plugins may expect wp's media uploader...
                                $plupload_init = apply_filters('plupload_init', $plupload_init); ?>

                                <script type="text/javascript">


                                    jQuery(function($){

                                        var olbl = $('#wpdm-jsongif-button').html();
                                        var uploader = new plupload.Uploader(<?php echo json_encode($plupload_init); ?>);

                                        uploader.bind('Init', function(up){
                                            var uploaddiv = $('#wpdm-upload-ui');

                                            if(up.features.dragdrop){
                                                uploaddiv.addClass('drag-drop');
                                                $('#drag-drop-area')
                                                    .bind('dragover.wp-uploader', function(){ uploaddiv.addClass('drag-over'); })
                                                    .bind('dragleave.wp-uploader, drop.wp-uploader', function(){ uploaddiv.removeClass('drag-over'); });

                                            }else{
                                                uploaddiv.removeClass('drag-drop');
                                                $('#drag-drop-area').unbind('.wp-uploader');
                                            }
                                        });

                                        uploader.init();

                                        uploader.bind('Error', function(uploader, error){
                                            WPDM.bootAlert('Error', error.message, 400);
                                        });


                                        uploader.bind('FilesAdded', function(up, files){

                                            plupload.each(files, function(file){
                                                $('#wpdm-jsongif-button').html("Uploading..." + file.percent+'%');
                                            });

                                            up.refresh();
                                            up.start();
                                        });

                                        uploader.bind('UploadProgress', function(up, file) {
                                            $('#wpdm-jsongif-button').html("Uploading..." + file.percent+'%');
                                        });


                                        uploader.bind('FileUploaded', function(up, file, data) {
                                            $('#wpdm-jsongif-button').html("Uploaded..." + file.percent+'%');
                                            location.reload();

                                        });


                                    });


                                </script>

                                <div class="clear"></div>

                            </div>
                        </div>
                    </div>
                    <span id="dmcf-loading-custom-field" class="hide" style="margin-left: 20px;"><i class="fa fa-spinner fa-spin"></i> Please wait.....</span>
                    <input type="submit" class="btn btn-success pull-right" value="Save All Changes" />
                </div>
            </form>
        </div>

    </div>

    <div class="alert alert-info" style="margin: 30px">
        To print field value use tag <code>[acf_<b>GroupName</b>_<b>FieldName</b>]</code> in link or page template
    </div>
</div>
<script>
    jQuery(document).ready(function($) {
        $('#submit__dmcf').on('click', function () {
            $('#save-custom-field').submit();
        });
        $('#save-custom-field').submit(function() {
            $('#dmcf-message-label').text('');
            $('#dmcf-message-label').removeClass('alert alert-success alert-danger')
            $('#dmcf-loading-custom-field').removeClass('hide');
            $(this).ajaxSubmit({
                url: ajaxurl,
                success: function(res) {
                    $('#dmcf-loading-custom-field').addClass('hide');
                    WPDM.pushNotify(res);
                    /*
                    if (res != 'Error: No field created yet') {
                        $('#dmcf-message-label').addClass('alert alert-success');
                        $('#dmcf-message-label').append(res);
                        WPDM.pushNotify(res);
                    }
                    else {
                        $('#dmcf-message-label').addClass('alert alert-danger');
                        $('#dmcf-message-label').append(res);
                        WPDM.pushNotify(res);
                    }
                    */
                }
            });
            return false;
        });



        $('body').on('click', '.dmcf-export-group', function(event) {
            var id = $(this).attr('rel');
            location.href = "<?php echo admin_url("?task=dmcf_export_group&groupid="); ?>"+id;
            return false;
        });

        $('body').on('click', '.dmcf-delete-group', function(event) {
            var id = $(this).attr('rel');
            $('#dmcf-new-group-' + id).remove();
            return false;
        });

        $('body').on('click', '.dmcf-delete-field', function(event) {
            var id = $(this).attr('rel');
            $('#dmcf-new-field-' + id).remove();
            return false;
        });

        $('.dmcf_field_select').on('click', function(event) {
            var id = $(this).data('identity');
            $('#field-state-' + id).on('change', function(e) {
                if ($(this).val() == "select" || $(this).val() == "checkbox" || $(this).val() == "radiobutton") {
                    $('#field-choice-' + id).removeClass("hide");
                }
                else {
                    $('#field-choice-' + id).addClass("hide");
                }
                return false;
            });
            return false;
        });
        $('#dmcf-add-group').on('click', function(event) {
            var fieldID; // = new Date().getTime();
            var groupName = $('#dmcf-group-input').val();
            fieldID = groupName.replace(/[^a-z0-9]+|\s+/gmi, "");
            if (groupName != '') {
                $("<div id='dmcf-new-group-" + fieldID + "' class='panel panel-default'>" +
                        "<div class='panel-heading'>" +
                        "<h4 class ='panel-title'>" +
                        "<a data-toggle = 'collapse' data-parent = '#custom-field-body' href = '#dmcf-group" + fieldID + "' >" +
                        groupName +
                        "</a>" +
                        "<span type='button' rel='" + fieldID + "' style='margin-left:5px;' class='dmcf-delete-group pull-right btn btn-danger btn-xs'><i class='fa fa-trash-o'></i> Delete Group</span>" +
                        "<span data-group='" + groupName + "' rel='" + fieldID + "' type='button' class='dmcf-add-field pull-right btn btn-primary btn-xs'><i class='fa fa-plus'></i> Add New Field</span>" +
                        "<input type='hidden' name='groupnames["+fieldID+"]' value='" + groupName + "' /></h4>" +
                        "</div>" +
                        "<div id='dmcf-group" + fieldID + "' class='panel-collapse collapse in'>" +
                        "<div class='panel-body'>" +
                        "<div id ='panel-group-" + fieldID + "' class='panel-group'>" +
                        "</div>" +
                        "</div>" +
                        "<div class='panel-footer' style='background: #fafafa'>" +
                        "Template Tag: <input onfocus='this.select()' class='ttp' title='Use this tag in link or page template to show group data'  style='border: 0;width: 200px;text-align: center' type='text' value='[acf_"+fieldID+"]' />" +
                        "</div>" +
                        "</div>" +
                        "</div>").appendTo('#custom-field-body');
            } else {
                $('#dmcf-message-label').text('');
                $('#dmcf-message-label').addClass('alert alert-danger');
                $('#dmcf-message-label').append('Error: insert group name');
            }


            return false;
        });
        $('body').on('click', '.dmcf-add-field', function(event) {
            event.preventDefault();
            var groupID = $(this).attr('rel');
            var groupName = $(this).attr('data-group');
            groupName = groupName.replace(/[^a-z0-9]+|\s+/gmi, "");
            var fieldID = new Date().getTime();
//            $('#dmcf-group'+groupID).toggle();
            $("<div id='dmcf-new-field-" + fieldID + "' class='panel panel-default'>" +
                    "<div class='panel-heading'>" +
                    "<h4 class ='panel-title'>" +
                    "<a data-toggle ='collapse' data-parent = '#panel-group-" + groupID + "' href = '#dmcf-field" + fieldID + "' >" +
                    "New Custom Field" +
                    "</a>" +
                    "<span type='button' rel='" + fieldID + "' class='dmcf-delete-field pull-right btn btn-danger btn-xs'><i class='fa fa-trash-o'></i> Delete Field</span>" +
                    "</h4>" +
                    "</div>" +
                    "<div id='dmcf-field" + fieldID + "' class='panel-collapse collapse in'>" +
                    "<div id = 'panel-" + fieldID + "' class='panel-body'>" +
                    "<label>Field Label</label>" +
                    "<input type = 'text' name= 'field-label[" + groupName + "][]' class= 'form-control' style = 'width: 400px;' /><br>" +
                    "<label>Field Name</label>" +
                    "<input type = 'text' name= 'field-name[" + groupName + "][]' class= 'form-control' style = 'width: 400px;' /><br>" +
                    "<label>Field Type</label>" +
                    "<select id='field-state-" + fieldID + "' name= 'field-type[" + groupName + "][]' class = 'form-control' style = 'width: 400px;'>" +
                    "<option value= 'text'>Text</option>" +
                    "<option value= 'textarea'>TextArea</option>" +
                    "<option value= 'number'>Number</option>" +
                    "<option value= 'email'>Email</option>" +
                    "<option value= 'url'>URL</option>" +
                    "<option value= 'date'>Date</option>" +
                    "<option value= 'select'>Select</option>" +
                    "<option value= 'checkbox'>Checkbox</option>" +
                    "<option value= 'radiobutton'>Radiobutton</option>" +
                    "</select><br>" +
                    "<div id = 'field-choice-" + fieldID + "' class = 'hide'>" +
                    "<label>Choices</label>" +
                    "<textarea name = 'field-choices[" + groupName + "][]' rows='6' placeholder = 'Enter one choice in every new line' class = 'form-control' style = 'width: 400px;'></textarea><br>" +
                    "</div>" +
                    "<label>User Input Requirement:</label><select class = 'form-control' style = 'width: 400px;' name= 'field-required[" + groupName + "][]'><option value='0'>Optional Field</option><option value='1'>Required Field</option></select><br>" +
                    "</div>" +
                    "</div>" +
                    "</div>").appendTo('#panel-group-' + groupID);
            $('#field-state-' + fieldID).on('change', function(e) {
                e.preventDefault();
                if ($(this).val() == "select" || $(this).val() == "checkbox" || $(this).val() == "radiobutton") {
                    $('#field-choice-' + fieldID).removeClass("hide");
                }
                else {
                    $('#field-choice-' + fieldID).addClass("hide");
                }
                return false;
            });
            return false;
        });

        $('.ttp').tooltip();

    });
</script>
