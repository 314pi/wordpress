jQuery(function($) {

    $('body').on('submit','#save-custom-field', function() {
        $('#dmcf-message-label').text('');
        $('#dmcf-message-label').removeClass('alert alert-success alert-danger');
        $('#dmcf-loading-custom-field').removeClass('hide');
        $(this).ajaxSubmit({
            url: ajaxurl,
            success: function(res) {
                $('#dmcf-loading-custom-field').addClass('hide');
                if (res != 'Error: No field created yet') {
                    $('#dmcf-message-label').addClass('alert alert-success');
                    $('#dmcf-message-label').append(res);
                }
                else {
                    $('#dmcf-message-label').addClass('alert alert-danger');
                    $('#dmcf-message-label').append(res);
                }
            }
        });
        return false;
    });

    $('body').on('click', '.dmcf-delete-group', function(event) {
        var id = $(this).attr('rel');
        $('#dmcf-new-group-' + id).remove();
        return false;
    });

    $('body').on('click', '.dmcf-delete-field', function(event) {
        var id = $(this).attr('rel');
        $('#dmcf-new-field-' + id).remove();
        return false;
    });

    $('body').on('change', '.s2dcf_field_select', function(event) {
        var id = $(this).data('identity');
        $('#field-state-' + id).on('change', function(e) {
            if ($(this).val() == "select" || $(this).val() == "checkbox" || $(this).val() == "radiobutton") {
                $('#field-choice-' + id).removeClass("hide");
                $('#field-choice-' + id+"-hidden").addClass("hide");
            }
            else if($(this).val() == "hidden"){
                $('#field-choice-' + id).addClass("hide");
                $('#field-choice-' + id+"-hidden").removeClass("hide");
            } else {
                $('#field-choice-' + id).addClass("hide");
                $('#field-choice-' + id+"-hidden").addClass("hide");
            }
            return false;
        });
        return false;
    });
    $('body').on('click', '#dmcf-add-group', function(event) {
        var fieldID; // = new Date().getTime();
        var groupName = $('#dmcf-group-input').val();
        fieldID = groupName.replace(/[^a-z0-9]+|\s+/gmi, "");
        if (groupName != '') {
            $("<div id='dmcf-new-group-" + fieldID + "' class='panel panel-default'>" +
                "<div class='panel-heading'>" +
                "<h4 class ='panel-title'>" +
                "<a data-toggle = 'collapse' data-parent = '#custom-field-body' href = '#dmcf-group" + fieldID + "' >" +
                groupName +
                "</a>" +
                "<span type='button' rel='" + fieldID + "' style='margin:-6px -9px 0 5px;' class='dmcf-delete-group pull-right btn btn-danger btn-sm'><i class='fas fa-trash'></i> Delete Form</span>" +
                "<span data-group='" + groupName + "' rel='" + fieldID + "' style='margin-top: -6px' type='button' class='dmcf-add-field pull-right btn btn-success btn-sm'><i class='fa fa-plus'></i> Add New Field</span>" +
                "<input type='hidden' name='groupnames["+fieldID+"]' value='" + groupName + "' /></h4>" +
                "</div>" +
                "<div id='dmcf-group" + fieldID + "' class='panel-collapse collapse in'>" +
                "<div class='panel-body'>" +
                "<div id ='panel-group-" + fieldID + "' class='panel-group'>" +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div>").appendTo('#custom-field-body');
        } else {
            $('#dmcf-message-label').text('');
            $('#dmcf-message-label').addClass('alert alert-danger');
            $('#dmcf-message-label').append('Error: insert group name');
        }

        /*
         $('body').on('click', '.dmcf-add-field', function(event) {
         event.preventDefault();
         var groupID = $(this).attr('rel');
         var groupName = $(this).attr('data-group');
         groupName = groupName.replace(/^[a-zA-Z]/,"");                
         var fieldID = new Date().getTime();
         $("<div class='panel panel-default'>" +
         "<div class='panel-heading'>" +
         "<h4 class ='panel-title'>" +
         "<a data-toggle ='collapse' data-parent = '#panel-group-" + groupID + "' href = '#dmcf-field" + fieldID + "' >" +
         "New Custom Field" +
         "</a>" +
         "<span type='button' class='dmcf-delete-field pull-right btn btn-danger btn-xs'><i class='fa fa-trash-o'></i></span>" +
         "</h4>" +
         "</div>" +
         "<div id='dmcf-field" + fieldID + "' class='panel-collapse collapse in'>" +
         "<div id = 'panel-" + fieldID + "' class='panel-body'>" +
         "<label>Field Label</label>" +
         "<input type = 'text' name= 'field-label[" + groupName + "][]' class= 'form-control' /><br>" +
         "<label>Field Name</label>" +
         "<input type = 'text' name= 'field-name[" + groupName + "][]' class= 'form-control' /><br>" +
         "<label>Field Type</label>" +
         "<select id='field-state-" + fieldID + "' name= 'field-type[" + groupName + "][]' class = 'form-control'>" +
         "<option value= 'text'>Text</option>" +
         "<option value= 'textarea'>TextArea</option>" +
         "<option value= 'number'>Number</option>" +
         "<option value= 'select'>Select</option>" +
         "<option value= 'checkbox'>Checkbox</option>" +
         "<option value= 'radiobutton'>Radiobutton</option>" +
         "</select><br>" +
         "<div id = 'field-choice-" + fieldID + "' class = 'hide'>" +
         "<label>Choices</label>" +
         "<textarea name = 'field-choices[" + groupName + "][]' rows = '6' placeholder = 'Enter one choice in every new line' class = 'form-control'></textarea><br>" +
         "</div>" +
         "</div>" +
         "</div>" +
         "</div>").appendTo('#panel-group-' + groupID);
         $('#field-state-' + fieldID).on('change', function(e) {
         e.preventDefault();
         if ($(this).val() == "select" || $(this).val() == "checkbox" || $(this).val() == "radiobutton") {
         $('#field-choice-' + fieldID).removeClass("hide");
         }
         else {
         $('#field-choice-' + fieldID).addClass("hide");
         }
         return false;
         });
         return false;
         });
         */
        return false;
    });
    //$('.dmcf-add-field').unbind('click');
    $('body').on('click', '.dmcf-add-field', function(event) {
        event.preventDefault();
        var groupID = $(this).attr('rel');
        var groupName = $(this).attr('data-group');
        groupName = groupName.replace(/[^a-z0-9]+|\s+/gmi, "");
        var fieldID = new Date().getTime();
//            $('#dmcf-group'+groupID).toggle();
        $("<div id='dmcf-new-field-" + fieldID + "' class='panel panel-default'>" +
            "<div class='panel-heading'>" +
            "<h4 class ='panel-title'>" +
            "<a data-toggle ='collapse' data-parent = '#panel-group-" + groupID + "' href = '#dmcf-field" + fieldID + "' >" +
            "New Custom Field" +
            "</a>" +
            "<span type='button' rel='" + fieldID + "' class='dmcf-delete-field pull-right btn btn-danger btn-xs'><i class='fas fa-trash'></i></span>" +
            "</h4>" +
            "</div>" +
            "<div id='dmcf-field" + fieldID + "' class='panel-collapse collapse in'>" +
            "<div id = 'panel-" + fieldID + "' class='panel-body'>" +
            "<div class='form-group row'>" +
            "<div class='col-md-6'>" +
            "<label>Field Label</label>" +
            "<input type = 'text' name= 'field-label[" + groupName + "][]' class= 'form-control' />" +
            "</div><div class='col-md-6'>" +
            "<label>Field Name</label>" +
            "<input type = 'text' name= 'field-name[" + groupName + "][]' class= 'form-control' />" +
            "</div></div>" +
            "<div class='form-group row'>" +
            "<div class='col-md-6'>" +
            "<label>Field Type</label>" +
            "<select id='field-state-" + fieldID + "' data-identity='" + fieldID + "' name= 'field-type[" + groupName + "][]' class = 'wpdm-custom-select form-control s2dcf_field_select'>" +
            "<option value= 'text'>Text</option>" +
            "<option value= 'email'>Email</option>" +
            "<option value= 'textarea'>TextArea</option>" +
            "<option value= 'number'>Number</option>" +
            "<option value= 'select'>Select</option>" +
            "<option value= 'checkbox'>Checkbox</option>" +
            "<option value= 'radiobutton'>Radiobutton</option>" +
            "<option value= 'hidden'>Hidden</option>" +
            "</select>" +
            "</div><div class='col-md-6'>" +
            "<label>Required Attribute</label>" +
            "<select id='field-state-" + fieldID + "' data-identity='" + fieldID + "' name= 'field-required[" + groupName + "][]' class = 'wpdm-custom-select form-control s2dcf_field_select'>" +
            "<option value= '0'>Not Required</option>" +
            "<option value= '1'>Required</option>" +
            "</select>" +
            "</div></div>" +
            "<div id = 'field-choice-" + fieldID + "' class = 'hide'>" +
            "<label>Choices</label>" +
            "<textarea name = 'field-choices[" + groupName + "][]' rows = '6' placeholder = 'Enter one choice in every new line' class = 'form-control'></textarea>" +
            "</div>" +
            "<div id = 'field-choice-" + fieldID + "-hidden' class = 'hide'>" +
            "<label>Value</label>" +
            "<input name = 'hidden-values[" + groupName + "][]' rows = '6' placeholder = 'Enter one choice in every new line' class = 'form-control' />" +
            "</div>" +
            "</div>" +
            "</div>" +
            "</div>").appendTo('#panel-group-' + groupID);

        return false;
    });

    $('.ttp').tooltip();
});