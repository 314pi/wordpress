<?php
/**
 * Plugin Name:  WPDM - Category Manager
 * Plugin URI: https://www.wpdownloadmanager.com/download/wpdm-Category-manager/
 * Description: Allows to manage categories from frontend
 * Author: W3 Eden, Inc.
 * Version: 1.2.1
 * Author URI: https://www.wpdownloadmanager.com/
 */


namespace WPDM\AddOn;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


class CatMan {

    function __construct() {
        add_action('wp_ajax_wpdm_list_categories', array($this, 'categoryManager'));
        add_action('wp_ajax_wpdm_cdd', array($this, 'categoryDropDown'));
        add_filter('wpdm_frontend', array($this, 'categoryMenu'));
        add_filter('wpdm_settings_frontend', array($this, 'settings'));
        add_shortcode('wpdm_category_manager', array($this, 'catManShortcode'));
    }

    function categoryMenu($menus){
        if(!get_option('__wpdm_enable_category_manager', 0)) return $menus;
        $menus = array("categories" => array('label'=>'Categories','callback'=>array($this, 'manageCategories'))) + $menus;
        return $menus;
    }

    function manageCategories(){
        if(get_option('__wpdm_enable_category_manager', 0))
            include(wpdm_tpl_path('manage-categories.php', __DIR__.'/tpls'));

    }

    function catManShortcode(){
        ob_start();
        $this->manageCategories();
        return ob_get_clean();
    }

    function categoryManager(){
        global $current_user, $wp_query;

        if(!get_option('__wpdm_enable_category_manager', 0)){
            \WPDM_Messages::Error(__("Category manager is not active","wpdmpro"), 1);
        }

        if(!is_user_logged_in()){
            include(wpdm_tpl_path('wpdm-be-member.php'));
            die();
        }

        //$this->DeleteFolder();
        //$this->DeleteFile();

        $user_home = get_user_meta($current_user->ID, '__wpdmfb_root_cat', true);


        $limit = 20;
        $parent = isset($_POST['catg']) && $_POST['catg'] > 0 ?(int)$_POST['catg']:0;

        if(wpdm_query_var('dcat') > 0){
            wp_delete_term(wpdm_query_var('dcat'), 'wpdmcategory');
            die("OK");
        }

        if(wpdm_query_var('_wpdmtask') == 'createCategory') {
            $slug = sanitize_title($_POST['cname']);
            if (term_exists($_POST['cname'], 'wpdmcategory'))
                $slug = $slug . "-" . uniqid();
            $term = $this->createCategory($_POST['cname'], $parent, $slug);
        }

        if(wpdm_query_var('_wpdmtask') == 'updateCategory') {
            $slug = sanitize_title($_POST['cname']);
            $_parent = $_POST['parent'] > 0?$_POST['parent'] :0;
            wp_update_term((int)$_POST['id'], 'wpdmcategory', array(
                'name' => $_POST['cname'],
                'slug' => $slug,
                'parent' => $_parent
            ));
        }


        $cats = get_terms('wpdmcategory', array('hide_empty' => false, 'parent' => $parent));

        $cond[] = "uid='{$current_user->ID}'";
        $Q = wpdm_query_var('q','txt');
        $paged = $wp_query->query_vars['paged']?$wp_query->query_vars['paged']:1;

        $start = $paged?(($paged-1)*$limit):0;
        $field = wpdm_query_var('sfield')?wpdm_query_var('sfield'):'publish_date';
        $ord = wpdm_query_var('sorder')?wpdm_query_var('sorder'):'desc';

        $author = $current_user->ID;
        $params = array('post_status'=>array('publish','pending','draft'), 'post_type'=>'wpdmpro', 'author'=> $author, 'offset'=>$start);
        $params['orderby'] = $field;
        $params['order'] = $ord;

        $params['tax_query'] = array(
            array(
                'taxonomy' => 'wpdmcategory',
                'field'    => 'id',
                'terms'    => $parent,
                'include_children' => false
            )
        );

        if($field=='download_count'){
            $params['orderby'] = 'meta_value_num';
            $params['meta_key'] = '__wpdm_download_count';
            $params['order'] = $ord;
        }


        include(wpdm_tpl_path("list-categories.php", __DIR__.'/tpls'));

        die();
    }

    public function createCategory($name, $parent, $slug = ''){
        $slug = $slug?$slug:$name;
        if($term = term_exists($slug, 'wpdmcategory', $parent)) return $term;
        $ret =  wp_insert_term(
            $name,
            'wpdmcategory',
            array(
                'parent'=> $parent,
                'slug' => $slug
            )
        );

        if(is_array($ret) && isset($ret['term_id'])) {
            add_user_meta(get_current_user_id(), '__wpdm_mycats', $ret['term_id']);
            return $ret;
        }
        return false;
    }

    function categoryDropDown(){
        wp_dropdown_categories( array('show_option_none' => __( 'Select Parent','wpdmpro' ), 'hide_empty' => 0, 'class' => 'form-control', 'taxonomy' => 'wpdmcategory', 'name' => 'uparent', 'hierarchical' => 1, 'depth' => 10) );
        die();
    }

    function settings(){
        include __DIR__.'/tpls/catman-settings.php';
    }



}

new CatMan();