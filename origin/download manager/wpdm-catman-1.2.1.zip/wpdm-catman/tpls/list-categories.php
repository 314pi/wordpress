<div class="breadcrumb">
    <div id="indc"><i class="fa fa-spinner fa-spin"></i> Loading...</div> <?php \WPDM\libs\CategoryHandler::CategoryBreadcrumb($_POST['catg'], 0); ?>
</div>
<?php
    $mycats = get_user_meta(get_current_user_id(),'__wpdm_mycats');

?>
<div class="list-group cat-table">


    <?php foreach($cats as $cat):  $icon = \WPDM\libs\CategoryHandler::icon($cat->term_id); ?>
        <div class="list-group-item" id="cat-<?php echo $cat->term_id; ?>">
            <div class="row">
                <div class="col-xs-10">
                <?php if(wpdm_cat_has_child($cat->term_id)) { ?><a href='#' class="catlink" data-cat="<?php echo $cat->term_id; ?>"><?php } ?>
                    <div class="media">
                        <div class="pull-left"><?php if($icon != ''): ?><img src="<?php echo $icon; ?>" width="24px" height="24px" /><?php endif; ?></div>
                        <div class="media-body"><?php echo $cat->name; ?></div>
                    </div>
                    <?php if(wpdm_cat_has_child($cat->term_id)) { ?></a><?php } ?>
                </div>
                <div class="col-xs-2 text-right">
                    <?php if(in_array($cat->term_id, $mycats)){ ?>
                        <a href="#" data-toggle="modal" data-target="#updateFolder" data-name="<?php echo htmlspecialchars($cat->name); ?>" data-parent="<?php echo $cat->parent; ?>" data-edit="<?php echo $cat->term_id; ?>" rel="<?php echo $cat->term_id; ?>" class="btn btn-info btn-xs edit-folder"><i class="fa fa-pencil"></i></a>
                        <a href="#" rel="<?php echo $cat->term_id; ?>" class="btn btn-danger btn-xs del-folder"><i class="fa fa-times"></i></a>
                    <?php } ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>



</div>



<style>
    .w3eden .breadcrumb{
        position: relative;
    }
    .cat-table .media-body{
        line-height: 24px;
        font-size: 10pt;
    }
    .cat-table img{
        border: 0; box-shadow: none;
    }
    #indc{
        position: absolute;
        right: 10px;
        color: #e24b31;
        font-family: monospace;
        display: none;
    }
    #wpdm-file-browser a{
        font-weight: 900;
    }
    #wpdm-file-browser td{
        line-height: 16px;
    }
    #wpdm-file-browser img{
        box-shadow: none;
    }
    #wpdm-file-browser .breadcrumb{
        position: relative;
    }
    #wpdm-file-browser #indc{
        margin-top: 1px;font-size: 11px;right: 12px;position: absolute; display: none;
    }
    .w3eden #sharePack .nav-tabs {
        background: #f5f5f5; padding: 10px 0 0 10px !important;
    }
    .w3eden #sharePack .tab-content{
        padding: 20px !important;
        border: 0 !important;
    }
    .modal-title{
        font-weight: 900 !important;
    }
    .w3eden #sharePack .nav-tabs > li > a{
        padding: 6px 15px;
        font-size: 9pt;
        font-weight: 900;
    }
</style>
<?php wp_reset_query(); ?>