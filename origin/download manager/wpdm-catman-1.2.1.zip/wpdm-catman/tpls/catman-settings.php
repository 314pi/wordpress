<?php
/**
 * User: shahnuralam
 * Date: 4/5/17
 * Time: 8:51 PM
 */
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="panel panel-default">
    <div class="panel-heading"><?php _e("Frontend Category Manager", "wpdm-catman"); ?></div>
    <div class="panel-body">
        <div class="form-group">
            <input type="hidden" value="0" name="__wpdm_enable_category_manager" />
            <label><input style="margin: 0 10px 0 0" type="checkbox" name="__wpdm_enable_category_manager" value="1" <?php checked(1, get_option('__wpdm_enable_category_manager')); ?>><?php echo __('Activate category management from frontend','wpdm-catman'); ?></label><br/>
            <em><?php echo __('Check if you want to enabled frontend users to edit/delete categories','wpdm-catman'); ?></em>
        </div>
        <div class="form-group">
            <input type="hidden" value="0" name="__wpdm_enable_user_root_cat" />
            <label><input style="margin: 0 10px 0 0" type="checkbox" name="__wpdm_enable_user_root_cat" value="1" <?php checked(1, get_option('__wpdm_enable_user_root_cat')); ?>><?php echo __('Enable User Specific Categories','wpdm-catman'); ?></label><br/>
            <em><?php echo __('Check if you want to disable global category management form front-end, each user will have their own root category and they will be able to access their own categories only','wpdm-catman'); ?></em>
        </div>
        <?php do_action("wpdm_category_manager_settings"); ?>
    </div>
</div>
