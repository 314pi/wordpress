<div class="w3eden">
    <div class="well text-right">
        <a href="#" data-toggle="modal" data-target="#createFolder" class="btn btn-primary btn-xs"><i class="fa fa-plus-circle"></i>&nbsp; <?php _e('New Category','wpdmpro'); ?></a> &nbsp;
        <strong class="pull-left"><?php _e('Manage Categories','wpdmpro'); ?></strong>
    </div>


    <div class="modal fade" id="createFolder" tabindex="-1" role="dialog" aria-labelledby="createFolderLabel" aria-hidden="true">
        <div class="modal-dialog" style="width: 400px">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php _e('Create Category','wpdmpro'); ?></h4>
                </div>
                <div class="modal-body">
                    <div  id="ccn">

                    </div>
                    <div class="form-group">
                    <input type="text" id="folder-name" placeholder="<?php _e('Category Name','wpdmpro'); ?>" class="form-control input-lg">
                    </div>
                    <div class="form-group cpdd">
                        <?php wp_dropdown_categories( array('show_option_none' => __( 'Select Parent','wpdmpro' ), 'hide_empty' => 0, 'class' => 'form-control', 'taxonomy' => 'wpdmcategory', 'name' => 'uparent', 'hierarchical' => 1, 'depth' => 10) ); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                    <button class="btn btn-sm btn-success" id="createFolderAction" style="width: 150px" data-value="<?php _e('Create Category','wpdmpro'); ?>"><?php _e('Create Category','wpdmpro'); ?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    
    
    <div class="modal fade" id="updateFolder" tabindex="-1" role="dialog" aria-labelledby="updateFolderLabel" aria-hidden="true">
        <div class="modal-dialog" style="width: 400px">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php _e('Update Category','wpdmpro'); ?></h4>
                </div>
                <div class="modal-body">
                    <div  id="ccn">

                    </div>
                    <div class="form-group">
                    <input type="text" id="edit-folder-name" placeholder="<?php _e('Category Name','wpdmpro'); ?>" class="form-control input-lg">
                    </div>
                    <div class="form-group">
                      <?php echo __( 'Select Parent','wpdmpro' ); ?>
                      <div class="cpdd">
                       <?php wp_dropdown_categories( array('show_option_none' => __( 'Select Parent','wpdmpro' ), 'hide_empty' => 0, 'class' => 'form-control', 'taxonomy' => 'wpdmcategory', 'name' => 'uparent', 'hierarchical' => 1, 'depth' => 10) ); ?>
                      </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                    <button class="btn btn-sm btn-success" id="updateFolderAction" style="width: 150px" data-value="<?php _e('Update Category','wpdmpro'); ?>"><?php _e('Update Category','wpdmpro'); ?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


    <div class="panel panel-default hide">
        <div class="panel-body">
            <input type="text" id="folder-name" placeholder="<?php _e('Category Name','wpdmpro'); ?>" class="form-control">
        </div>
        <div class="panel-footer text-right">
            <button class="btn btn-sm btn-success"><?php _e('Create Category','wpdmpro'); ?></button>
        </div>
    </div>


</div>
<div id="wpdm-category-manager" class="w3eden">
</div>
<script>
    var ncparent = 0;
    var editc = 0;
    jQuery(function($){
        var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
        $('#wpdm-category-manager').load(ajaxurl+'?action=wpdm_list_categories', { catg: 0 });        
        $('body').on('click','#createFolderAction',function(){
            $(this).html('<i class="fa fa-spin fa-refresh"></i>');
            var name = $('#folder-name').val();
            $('#wpdm-category-manager #indc').fadeIn();
            $('#wpdm-category-manager').load(ajaxurl+'?action=wpdm_list_categories', { catg: $('#uparent').val(), _wpdmtask: 'createCategory', cname: name }, function(){
                $('#folder-name').val('');
                $('#ccn').html("<div class='alert alert-success fca'><?php _e('Category Created','wpdmpro'); ?></div>");
                $('#createFolderAction').html($('#createFolderAction').data('value'));
                $('.cpdd').load(ajaxurl+'?action=wpdm_cdd');
            });

        });
        
        $('body').on('click','#updateFolderAction',function(){
            $(this).html('<i class="fa fa-spin fa-refresh"></i>');
            var name = $('#edit-folder-name').val();
            $('#wpdm-category-manager #indc').fadeIn();
            $('#wpdm-category-manager').load(ajaxurl+'?action=wpdm_list_categories', { id: editc, parent: $('#uparent').val(), _wpdmtask: 'updateCategory', cname: name }, function(){
                $('#folder-name').val('');
                $('#ccn').html("<div class='alert alert-success fca'><?php _e('Category Updated','wpdmpro'); ?></div>");
                $('#updateFolderAction').html($('#updateFolderAction').data('value'));
            });

        });

        $('body').on('click','.catlink, .folder',function(){
            var cat = $(this).data('cat');
             
            $('#pcat').val(ncparent);
            $('#wpdm-category-manager #indc').fadeIn();
            $('#wpdm-category-manager').load(ajaxurl+'?action=wpdm_list_categories', { catg: cat });
            return false;
        });

        $('body').on('click','.del-folder',function(e){
            e.preventDefault();
            if(!confirm('Are you sure?')) return false;
            var ct = this.rel;
            $(this).html('<i class="fa fa-spinner fa-spin"></i>');
            $.post(ajaxurl+'?action=wpdm_list_categories', { dcat: ct }, function(){
                $('#cat-'+ct).slideUp();
            })

        });
        
        $('body').on('click','.edit-folder',function(e){
            e.preventDefault();
            $('#edit-folder-name').val($(this).data('name'));
            var  p = $(this).data('parent');
            p = p == 0?'-1':p;
            $('#uparent option[value='+p+']').prop('selected', true)
            editc = $(this).data('edit');

        });


    });
</script>
 