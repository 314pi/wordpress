<?php
/**
 * Plugin Name: WPDM - Remote FTP browser
 * Plugin URI: https://www.wpdownloadmanager.com/download/wpdm-remote-ftp-add-on/
 * Description: Remote FTP browser add-on for wpdm pro
 * Author: Shaon
 * Version: 2.2.8
 * Author URI: https://www.wpdownloadmanager.com/
 **/

if (!defined('CRLF'))
    define('CRLF', "\r\n");

/**
 * Sets whatever to autodetect ASCII mode.
 *
 * This can be redefined.
 *
 * @since 2.5
 * @var int
 */
if (!defined("FTP_AUTOASCII"))
    define("FTP_AUTOASCII", -1);

/**
 *
 * This can be redefined.
 * @since 2.5
 * @var int
 */
if (!defined("FTP_BINARY"))
    define("FTP_BINARY", 1);

/**
 *
 * This can be redefined.
 * @since 2.5
 * @var int
 */
if (!defined("FTP_ASCII"))
    define("FTP_ASCII", 0);

/**
 * Whether to force FTP.
 *
 * This can be redefined.
 *
 * @since 2.5
 * @var bool
 */
if (!defined('FTP_FORCE'))
    define('FTP_FORCE', true);

/**
 * @since 2.5
 * @var string
 */
define('FTP_OS_Unix', 'u');

/**
 * @since 2.5
 * @var string
 */
define('FTP_OS_Windows', 'w');

/**
 * @since 2.5
 * @var string
 */
define('FTP_OS_Mac', 'm');

class Ftp {
    /*     * #@+ FTP constant alias */

    const ASCII = FTP_ASCII;
    const TEXT = FTP_TEXT;
    const BINARY = FTP_BINARY;
    const IMAGE = FTP_IMAGE;
    const TIMEOUT_SEC = FTP_TIMEOUT_SEC;
    const AUTOSEEK = FTP_AUTOSEEK;
    const AUTORESUME = FTP_AUTORESUME;
    const FAILED = FTP_FAILED;
    const FINISHED = FTP_FINISHED;
    const MOREDATA = FTP_MOREDATA;

    /*     * #@- */

    /* Public variables */

    var $LocalEcho;
    var $Verbose;
    var $OS_local;
    var $OS_remote;

    /* Private variables */
    var $_lastaction;
    var $_errors;
    var $_type;
    var $_umask;
    var $_timeout;
    var $_passive;
    var $_host;
    var $_fullhost;
    var $_port;
    var $_datahost;
    var $_dataport;
    var $_ftp_control_sock;
    var $_ftp_data_sock;
    var $_ftp_temp_sock;
    var $_ftp_buff_size;
    var $_login;
    var $_password;
    var $_connected;
    var $_ready;
    var $_code;
    var $_message;
    var $_can_restore;
    var $_port_available;
    var $_curtype;
    var $_features;
    var $_error_array;
    var $AuthorizedTransferMode;
    var $OS_FullName;
    var $_eol_code;
    var $AutoAsciiExt;
    private static $aliases = array(
        'sslconnect' => 'ssl_connect',
        'getoption' => 'get_option',
        'setoption' => 'set_option',
        'nbcontinue' => 'nb_continue',
        'nbfget' => 'nb_fget',
        'nbfput' => 'nb_fput',
        'nbget' => 'nb_get',
        'nbput' => 'nb_put',
    );

    /** @var resource */
    private $resource;

    /** @var array */
    private $state;

    /** @var string */
    private $errorMsg;

    /**
     * @param  string  URL ftp://...
     */
    public function __construct($url = NULL) {
        if (!extension_loaded('ftp')) {
            throw new /* \ */Exception("PHP extension FTP is not loaded.");
        }
        if ($url) {
            $parts = parse_url($url);
            $this->connect($parts['host'], empty($parts['port']) ? NULL : (int) $parts['port']);
            $this->login($parts['user'], $parts['pass']);
            $this->pasv(TRUE);
            if (isset($parts['path'])) {
                $this->chdir($parts['path']);
            }
        }
    }

    public function is_connected() {
        return $this->resource ? true : false;
    }

    /**
     * Magic method (do not call directly).
     * @param  string  method name
     * @param  array   arguments
     * @return mixed
     * @throws Exception
     * @throws FtpException
     */
    public function __call($name, $args) {
        $name = strtolower($name);
        $silent = strncmp($name, 'try', 3) === 0;
        $func = $silent ? substr($name, 3) : $name;
        $func = 'ftp_' . (isset(self::$aliases[$func]) ? self::$aliases[$func] : $func);
        if (!function_exists($func)) {
            echo $func;
            die();
            throw new Exception("Call to undefined method Ftp::$name().");
        }

        $this->errorMsg = NULL;
        set_error_handler(array($this, '_errorHandler'));

        if ($func === 'ftp_connect' || $func === 'ftp_ssl_connect') {
            $this->state = array($name => $args);
            $this->resource = call_user_func_array($func, $args);
            $res = NULL;
        } elseif (!is_resource($this->resource)) {
            restore_error_handler();
            throw new FtpException("Incorrect Login Info");
        } else {
            if ($func === 'ftp_login' || $func === 'ftp_pasv') {
                $this->state[$name] = $args;
            }

            array_unshift($args, $this->resource);
            $res = call_user_func_array($func, $args);

            if ($func === 'ftp_chdir' || $func === 'ftp_cdup') {
                $this->state['chdir'] = array(ftp_pwd($this->resource));
            }
        }

        restore_error_handler();
        if (!$silent && $this->errorMsg !== NULL) {
            if (ini_get('html_errors')) {
                $this->errorMsg = html_entity_decode(strip_tags($this->errorMsg));
            }

            if (($a = strpos($this->errorMsg, ': ')) !== FALSE) {
                $this->errorMsg = substr($this->errorMsg, $a + 2);
            }

            throw new FtpException($this->errorMsg);
        }

        return $res;
    }

    /**
     * Internal error handler. Do not call directly.
     */
    public function _errorHandler($code, $message) {
        $this->errorMsg = $message;
    }

    /**
     * Reconnects to FTP server.
     * @return void
     */
    public function reconnect() {
        @ftp_close($this->resource); // intentionally @
        foreach ($this->state as $name => $args) {
            call_user_func_array(array($this, $name), $args);
        }
    }

    /**
     * Checks if file or directory exists.
     * @param  string
     * @return bool
     */
    public function fileExists($file) {
        return is_array($this->nlist($file));
    }

    /**
     * Checks if directory exists.
     * @param  string
     * @return bool
     */
    public function isDir($dir) {
        $current = $this->pwd();
        try {
            $this->chdir($dir);
        } catch (FtpException $e) {

        }
        $this->chdir($current);
        return empty($e);
    }

    /**
     * Recursive creates directories.
     * @param  string
     * @return void
     */
    public function mkDirRecursive($dir) {
        $parts = explode('/', $dir);
        $path = '';
        while (!empty($parts)) {
            $path .= array_shift($parts);
            try {
                if ($path !== '')
                    $this->mkdir($path);
            } catch (FtpException $e) {
                if (!$this->isDir($path)) {
                    throw new FtpException("Cannot create directory '$path'.");
                }
            }
            $path .= '/';
        }
    }

    /**
     * Recursive deletes path.
     * @param  string
     * @return void
     */
    public function deleteRecursive($path) {
        if (!$this->tryDelete($path)) {
            foreach ((array) $this->nlist($path) as $file) {
                if ($file !== '.' && $file !== '..') {
                    $this->deleteRecursive(strpos($file, '/') === FALSE ? "$path/$file" : $file);
                }
            }
            $this->rmdir($path);
        }
    }

    function parselisting($line) {
        $is_windows = '';
        ($this->OS_remote == FTP_OS_Windows);
        if ($is_windows && preg_match("/([0-9]{2})-([0-9]{2})-([0-9]{2}) +([0-9]{2}):([0-9]{2})(AM|PM) +([0-9]+|<DIR>) +(.+)/", $line, $lucifer)) {
            $b = array();
            if ($lucifer[3] < 70) {
                $lucifer[3]+=2000;
            } else {
                $lucifer[3]+=1900;
            } // 4digit year fix
            $b['isdir'] = ($lucifer[7] == "<DIR>");
            if ($b['isdir'])
                $b['type'] = 'd';
            else
                $b['type'] = 'f';
            $b['size'] = $lucifer[7];
            $b['month'] = $lucifer[1];
            $b['day'] = $lucifer[2];
            $b['year'] = $lucifer[3];
            $b['hour'] = $lucifer[4];
            $b['minute'] = $lucifer[5];
            $b['time'] = @mktime($lucifer[4] + (strcasecmp($lucifer[6], "PM") == 0 ? 12 : 0), $lucifer[5], 0, $lucifer[1], $lucifer[2], $lucifer[3]);
            $b['am/pm'] = $lucifer[6];
            $b['name'] = $lucifer[8];
        } else if (!$is_windows && $lucifer = preg_split("/[ ]/", $line, 9, PREG_SPLIT_NO_EMPTY)) {
            //echo $line."\n";
            $lcount = count($lucifer);
            if ($lcount < 8)
                return '';
            $b = array();
            $b['isdir'] = $lucifer[0]{0} === "d";
            $b['islink'] = $lucifer[0]{0} === "l";
            if ($b['isdir'])
                $b['type'] = 'd';
            elseif ($b['islink'])
                $b['type'] = 'l';
            else
                $b['type'] = 'f';
            $b['perms'] = $lucifer[0];
            $b['number'] = $lucifer[1];
            $b['owner'] = $lucifer[2];
            $b['group'] = $lucifer[3];
            $b['size'] = $lucifer[4];
            if ($lcount == 8) {
                sscanf($lucifer[5], "%d-%d-%d", $b['year'], $b['month'], $b['day']);
                sscanf($lucifer[6], "%d:%d", $b['hour'], $b['minute']);
                $b['time'] = @mktime($b['hour'], $b['minute'], 0, $b['month'], $b['day'], $b['year']);
                $b['name'] = $lucifer[7];
            } else {
                $b['month'] = $lucifer[5];
                $b['day'] = $lucifer[6];
                if (preg_match("/([0-9]{2}):([0-9]{2})/", $lucifer[7], $l2)) {
                    $b['year'] = date("Y");
                    $b['hour'] = $l2[1];
                    $b['minute'] = $l2[2];
                } else {
                    $b['year'] = $lucifer[7];
                    $b['hour'] = 0;
                    $b['minute'] = 0;
                }
                $b['time'] = strtotime(sprintf("%d %s %d %02d:%02d", $b['day'], $b['month'], $b['year'], $b['hour'], $b['minute']));
                $b['name'] = $lucifer[8];
            }
        }

        return $b;
    }

}

class FtpException extends Exception {

}

function wpdm_ftpdir_tree() {
    $root = '';
    if (!isset($_GET['task']) || $_GET['task'] != 'wpdm_ftpdir_tree' || !isset($_GET['id']))
        return;
    $pid = intval($_GET['id']);
    //$_POST['dir'] = urldecode($_POST['dir']);
    $ftpserver = '';
    $ftpuser = '';
    $ftppass = '';
    if (isset($_REQUEST['ftp'])) {
        $ftpserver = $_REQUEST['ftp']['server'] ? $_REQUEST['ftp']['server'] : get_post_meta($pid, 'ftp_server', true);
        $ftpuser = $_REQUEST['ftp']['user'] ? $_REQUEST['ftp']['user'] : get_post_meta($pid, 'ftp_user', true);
        $ftppass = $_REQUEST['ftp']['pass'] ? $_REQUEST['ftp']['pass'] : get_post_meta($pid, 'ftp_pass', true);
    }
    if ($ftpserver == '') {
        $ftpserver = get_option('_wpdm_ftp_server');
        $ftpuser = get_option('_wpdm_ftp_user');
        $ftppass = get_option('_wpdm_ftp_pass');
    }
    try {
        if ($ftpserver == '')
            throw new FtpException('Please provide valid FTP server info');
        $ftp = new Ftp;
        $ftp->connect(trim($ftpserver));
        if (!$ftp->is_connected()) {
            if ($pid > 0 && isset($_REQUEST['ftp'])) {
                update_post_meta($pid, 'ftp_server', $_REQUEST['ftp']['server']);
                update_post_meta($pid, 'ftp_user', $_REQUEST['ftp']['user']);
                update_post_meta($pid, 'ftp_pass', $_REQUEST['ftp']['pass']);
            } else {
                update_option('_wpdm_ftp_server', $ftpserver);
                update_option('_wpdm_ftp_user', $ftpuser);
                update_option('_wpdm_ftp_pass', $ftppass);
            }
        }
        $ftp->login(trim($ftpuser), trim($ftppass));
        $list = $ftp->rawlist($_POST['dir']);

        $tmplist = array();
        $flist = array();
        foreach ($list as $l) {
            $tmplist = $ftp->parselisting($l);
            if (isset($tmplist['isdir']) && $tmplist['isdir'] == 1)
                $flist['dir'][] = $tmplist['name'];
            else
                $flist['file'][] = $tmplist['name'];
        }

        $list = $flist;
        if ($list) {

            ob_start();

            echo "<ul class='jqueryFileTree' style='display: none;'>";
            // All dirs
            if (is_array($list['dir'])) {
                foreach ($list['dir'] as $file) {
                    if ($file != '.' && $file != '..' && !@is_dir($root . $_POST['dir'] . $file)) {
                        echo "<li class='directory collapsed'><a id='" . uniqid() . "' href='#' rel='" . htmlentities($_POST['dir'] . trim($file)) . "/'>" . htmlentities($file) . "</a></li>";
                    }
                }
            }
            // All files
            if (isset($list['file']) && is_array($list['file'])) {
                foreach ($list['file'] as $file) {
                    if ($file != '.' && $file != '..' && !is_dir($root . $_POST['dir'] . $file)) {
                        $ext = preg_replace('/^.*\./', '', $file);
                        echo "<li class='file ext_$ext'><a id='" . uniqid() . "' href='#' rel='ftp:" . htmlentities($_POST['dir'] . trim($file)) . "'>" . htmlentities($file) . "</a></li>";
                    }
                }
            }
            echo "</ul>";

            die( ob_get_clean() );
        }
    } catch (FtpException $e) {

        echo "<div class='w3eden'><div class='alert alert-danger'>" . $e->getMessage() . "</div>";
        ?>
        <div class="form">
        <div class="form-group">
        FTP Server:<br/>
        <input type="text" class="form-control" id="ftp_server">
        </div>
        <div class="form-group">
            FTP User:<br/>
            <input type="text" id="ftp_user" class="form-control">
        </div>
        <div class="form-group">
            FTP Password:<br/>
            <input type="password" id="ftp_pass"  class="form-control">
        </div>
        <div class="form-group">
            <input type="button" class="btn btn-primary" id='ftpconnect' value="Connect">
        </div>

        </div>
        </div>
        <script language="JavaScript">
            jQuery(function () {
                jQuery('#ftpconnect').click(function () {
                    jQuery('#ftptree').fileTree({
                        root: '/',
                        script: 'admin.php?task=wpdm_ftpdir_tree&id=<?php echo intval($_GET['id']); ?>&ftp[server]=' + jQuery('#ftp_server').val() + '&ftp[user]=' + encodeURIComponent(jQuery('#ftp_user').val()) + '&ftp[pass]=' + encodeURIComponent(jQuery('#ftp_pass').val()),
                        expandSpeed: 1000,
                        collapseSpeed: 1000,
                        multiFolder: false
                    }, function (file, id) {
                        var sfilename = file.split('/');
                        var filename = sfilename[sfilename.length - 1];
                        if (confirm('Add this file?')) {
                            var ID = id;
                            <?php

                    global $post;

                    $files = maybe_unserialize(get_post_meta($post->ID, '__wpdm_files', true));

                    if (!is_array($files)) $files = array();

                    if(count($files) < 15){
                    ?>
                            var html = jQuery('#wpdm-file-entry').html();
                            var ext = file.split('.');
                            ext = ext[ext.length-1];
                            var icon = "<?php echo WPDM_BASE_URL; ?>file-type-icons/"+ext+".png";
                            html = html.replace(/##filepath##/g, file);
                            html = html.replace(/##fileindex##/g, ID);
                            html = html.replace(/##preview##/g, icon);
                            jQuery('#currentfiles').prepend(html);
                            <?php } else { ?>
                            jQuery('#wpdm-files').dataTable().fnAddData( [
                                "<input type='hidden' id='in_"+ID+"' name='file[files][]' value='"+file+"' /><img id='del_"+ID+"' src='<?php echo plugins_url(); ?>/download-manager/images/minus.png' rel='del' align=left />",
                                file,
                                "<input style='width:99%' type='text' name='file[fileinfo]["+file+"][title]' value='"+filename+"' onclick='this.select()'>",
                                "<input size='10' type='text' id='indpass_"+ID+"' name='file[fileinfo]["+file+"][password]' value=''> <img style='cursor: pointer;float: right;margin-top: -3px' class='genpass' onclick=\"return generatepass('indpass_"+ID+"')\" title='Generate Password' src=\"<?php echo plugins_url('download-manager/images/generate-pass.png'); ?>\" />"
                            ] );
                            jQuery('#wpdm-files tbody tr:last-child').attr('id',ID).addClass('cfile');

                            jQuery("#wpdm-files tbody").sortable();

                            jQuery('#'+ID).fadeIn();
                            jQuery('#del_'+ID).click(function(){
                                if(jQuery(this).attr('rel')=='del'){
                                    jQuery('#'+ID).removeClass('cfile').addClass('dfile');
                                    jQuery('#in_'+ID).attr('name','del[]');
                                    jQuery(this).attr('rel','undo').attr('src','<?php echo plugins_url(); ?>/download-manager/images/add.png').attr('title','Undo Delete');
                                } else if(jQuery(this).attr('rel')=='undo'){
                                    jQuery('#'+ID).removeClass('dfile').addClass('cfile');
                                    jQuery('#in_'+ID).attr('name','file[files][]');
                                    jQuery(this).attr('rel','del').attr('src','<?php echo plugins_url(); ?>/download-manager/images/minus.png').attr('title','Delete File');
                                }
                            });
                            <?php } ?>
                        }
                    });
                });
            });
        </script>
    <?php
    }
}

function wpdm_process_rawlist($contents) {
    $items = array();

    $a = 0;

    if (count($contents) > 2) {
        foreach ($contents as $_)
            preg_replace(
                '`^(.{10}+)(\s*)(\d{1})(\s*)(\d*|\w*)' .
                '(\s*)(\d*|\w*)(\s*)(\d*)\s' .
                '([a-zA-Z]{3}+)(\s*)([0-9]{1,2}+)' .
                '(\s*)([0-9]{2}+):([0-9]{2}+)(\s*)(.*)$`U', '$items[print_r((preg_match("/^d/","$1"))?"dir":"file",1)][]=array(
                "rights"=>"$1",
                "number"=>"$3",
                "owner"=>"$5", "group"=>"$7",
                "file_size"=>"$9",
                "mod_time"=>"$10 $12 $14:$15",
                "file"=>"$17",
                "type"=>print_r((preg_match("/^d/","$1"))?"dir":"file",1));', $_);
    }
    return $items;
}

function wpdm_ftp_browser() {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $ftpserver = get_option('_wpdm_ftp_server');
    ?>
    <div id="ftptree"></div>
    <script language="JavaScript">
        jQuery(function () {
            jQuery('#ftptree').fileTree({
                root: '/',
                script: 'admin.php?task=wpdm_ftpdir_tree&id=<?php echo $id; ?>',
                expandSpeed: 1000,
                collapseSpeed: 1000,
                multiFolder: false
            }, function (file, id) {
                var sfilename = file.split('/');
                var filename = sfilename[sfilename.length - 1];
                if (confirm('Add this file?')) {
                    var ID = id;
                    <?php
                    $files = maybe_unserialize( get_post_meta( $id, '__wpdm_files', true ) );
                    if ( ! is_array( $files ) ) $files = array();

                    if(version_compare(WPDM_Version, '4.0.0', '>')){
                    if (count($files) > 15) { ?>

                    jQuery('#currentfiles table.widefat').append("<tr id='" + ID + "' class='cfile'><td><input type='hidden' id='in_" + ID + "' name='file[files][]' value='" + file + "' /><img id='del_" + ID + "' src='<?php echo plugins_url(); ?>/download-manager/images/minus.png' rel='del' align=left /></td><td>" + file + "</td><td width='40%'><input style='width:99%' type='text' name='file[fileinfo][" + file + "][title]' value='" + filename + "' onclick='this.select()'></td><td><input size='10' type='text' id='indpass_" + ID + "' name='file[fileinfo][" + file + "][password]' value=''> <img style='cursor: pointer;float: right;margin-top: -3px' class='genpass' onclick=\"return generatepass('indpass_" + ID + "')\" title='Generate Password' src=\"<?php echo plugins_url('download-manager/images/generate-pass.png'); ?>\" /></td></tr>");
                    jQuery('#' + ID).fadeIn();
                    jQuery('#del_' + ID).click(function () {
                        if (jQuery(this).attr('rel') == 'del') {
                            jQuery('#' + ID).removeClass('cfile').addClass('dfile');
                            jQuery('#in_' + ID).attr('name', 'del[]');
                            jQuery(this).attr('rel', 'undo').attr('src', '<?php echo plugins_url(); ?>/download-manager/images/add.png').attr('title', 'Undo Delete');
                        } else if (jQuery(this).attr('rel') == 'undo') {
                            jQuery('#' + ID).removeClass('dfile').addClass('cfile');
                            jQuery('#in_' + ID).attr('name', 'files[]');
                            jQuery(this).attr('rel', 'del').attr('src', '<?php echo plugins_url(); ?>/download-manager/images/minus.png').attr('title', 'Delete File');
                        }
                    });
                    <?php } else { ?>
                    var html = jQuery('#wpdm-file-entry').html();
                    var ext = file.split('.');
                    ext = ext[ext.length - 1];
                    var icon = "<?php echo WPDM_BASE_URL; ?>file-type-icons/48x48/" + ext + ".png";
                    var title = filename;
                    title = title.replace(/\.([\w]+)$/, '');
                    title = title.replace(/[_|\-]/g, ' ');

                    html = html.replace(/##filepath##/g, file);
                    html = html.replace(/##filetitle##/g, title);
                    html = html.replace(/##fileindex##/g, ID);
                    html = html.replace(/##preview##/g, icon);
                    jQuery('#currentfiles').prepend(html);

                    <?php }
                    } else { ?>
                    jQuery('#wpdmfile').val(file+"#"+file);
                    jQuery('#cfl').html('<div><strong>'+file+'</strong>').slideDown();
                    <?php } ?>
                }
            });
        });
    </script>
    <?php
    // die();
}

function wpmp_ftp_browser_metabox() {
    ?>
    <div class="inside" style="height: 250px;overflow: auto;">
        <?php wpdm_ftp_browser(); ?>
        <ul id="ftpfiles"></ul>
        <div class="clear"></div>
    </div>
<?php
}

function wpdm_ftp_metabox($boxes) {
    $boxes['remote-ftp'] = array('title' => __('Remote FTP', "wpdmpro"), 'callback' => 'wpmp_ftp_browser_metabox', 'position' => 'normal', 'priority' => 'core');
    return $boxes;
}

function wpdm_ftp_download_file($package) {
    global $current_user;
    $files = maybe_unserialize($package['files']);
    if (!isset($_GET['ind']) && count($files) > 1)
        return 0;
    $tfiles = $files;
    if(isset($_GET['ind']))
        $rfile = isset( $files[esc_attr( $_GET['ind'] )] ) ? $files[esc_attr( $_GET['ind'] )] : \WPDM\libs\Crypt::Decrypt( esc_attr($_GET['ind']) );
    else
        $rfile = array_shift($tfiles);
    if (!strpos("#" . $rfile, 'ftp:'))
        return $package;
    $ftpfile = str_replace("ftp:", "", $rfile);
    $localfile = WPDM_CACHE_DIR . uniqid() . '_' . end($tmp = explode("/", $ftpfile));

    $ftpserver = get_option('_wpdm_ftp_server');
    $ftpuser = get_option('_wpdm_ftp_user');
    $ftppass = get_option('_wpdm_ftp_pass');


    try {
        if ($ftpserver == '')
            throw new FtpException('Please provide valid FTP server info');
        $ftp = new Ftp;
        $ftp->connect(trim($ftpserver));
        $ftp->login(trim($ftpuser), trim($ftppass));
        $ftp->get($localfile, $ftpfile, FTP_BINARY);
        $speed = 1024; //in KB - default 1 MB
        $speed = apply_filters('wpdm_download_speed', $speed);
        $filename = end($tmp = explode("/", $ftpfile));
        $log = new \WPDM\libs\DownloadStats();
        $log->NewStat($package['ID'], $current_user->ID, 0);
        wpdm_download_file($localfile, $filename, $speed);
        @unlink($localfile);
        die();
    } catch (FtpException $e) {
        wpdm_download_data('download-error.txt', $e->getMessage());
    }

    die();
}

function wpdm_ftp_file_get_contents($ftpfile) {
    global $current_user;

    $tmp = explode("/", $ftpfile);
    $localfile = WPDM_CACHE_DIR . uniqid() . '_' . end($tmp);

    $ftpserver = get_option('_wpdm_ftp_server');
    $ftpuser = get_option('_wpdm_ftp_user');
    $ftppass = get_option('_wpdm_ftp_pass');


    try {
        if ($ftpserver == '')
            throw new FtpException('Please provide valid FTP server info');
        $ftp = new Ftp;
        $ftp->connect(trim($ftpserver));
        $ftp->login(trim($ftpuser), trim($ftppass));
        $ftp->get($localfile, $ftpfile, FTP_BINARY);
        $speed = 1024; //in KB - default 1 MB
        $speed = apply_filters('wpdm_download_speed', $speed);
        $filename = end($tmp = explode("/", $ftpfile));
        $data = file_get_contents($localfile);
        @unlink($localfile);
        return $data;
    } catch (FtpException $e) {
        return false;
    }

    return false;
}


function wpdm_ftpdir_csv_import_process($ftpserver, $ftpuser, $ftppass, $ftp_directory) {
    $root = '';

    try {
        if ($ftpserver == '')
            throw new FtpException('Please provide valid FTP server info');
        $ftp = new Ftp;
        $ftp->connect(trim($ftpserver));
        if ($ftp->is_connected()) {
            $ftp->login(trim($ftpuser), trim($ftppass));
            $list = $ftp->rawlist($ftp_directory);

            $tmplist = array();
            $flist = array();
            foreach ($list as $l) {
                $tmplist = $ftp->parselisting($l);
                if (isset($tmplist['isdir']) && $tmplist['isdir'] == 1)
                    $flist['dir'][] = $tmplist['name'];
                else
                    $flist['file'][] = $tmplist['name'];
            }

            $list = $flist;
            if ($list) {

                if (is_array($list['file'])) {
                    foreach ($list['file'] as $file) {
                        if ($file != '.' && $file != '..' && !is_dir($root . $ftp_directory . $file)) {
                            $ext = preg_replace('/^.*\./', '', $file);

                            if ($ext == 'csv') {
                                wpdm_import_ftp_dir($ftp_directory . '/' . $file, $ftp_directory);
                                break;
                            }
                        }
                    }
                }
            }
        }
    } catch (FtpException $e) {

    }
}

function wpdm_ftp_auto_import() {
    if ( isset($_REQUEST['importcsv']) && $_REQUEST['importcsv'] == '1' ) {
        $ftp_server = get_option('_wpdm_ftp_server');
        $ftp_user = get_option('_wpdm_ftp_user');
        $ftp_pass = get_option('_wpdm_ftp_pass');
        $ftp_directory = get_option('_wpdm_ftp_xml_directory');

        if ( isset( $ftp_directory ) ) {
            wpdm_ftpdir_csv_import_process($ftp_server, $ftp_user, $ftp_pass, $ftp_directory);
        }
        die('Successfully Imaported CSV file.');
    }
}

function wpdm_ftp_settings_tab($tabs){
    $tabs['ftp'] = wpdm_create_settings_tab('ftp', 'FTP', 'wpdm_ftp_settings', $icon = 'fas fa-file-export');
    return $tabs;
}

function wpdm_ftp_settings() {
    if (isset($_POST['task']) && $_POST['task'] == 'wdm_save_settings') {
        update_option('_wpdm_ftp_server', $_POST['_wpdm_ftp_server']);
        update_option('_wpdm_ftp_user', $_POST['_wpdm_ftp_user']);
        update_option('_wpdm_ftp_pass', $_POST['_wpdm_ftp_pass']);
        update_option('_wpdm_ftp_xml_directory', $_POST['_wpdm_ftp_xml_directory']);

        $ftp_server = $_POST['_wpdm_ftp_server'];
        $ftp_user = $_POST['_wpdm_ftp_user'];
        $ftp_pass = $_POST['_wpdm_ftp_pass'];
        $ftp_directory = $_POST['_wpdm_ftp_xml_directory'];

        if (isset($ftp_directory)) {
            wpdm_ftpdir_csv_import_process($ftp_server, $ftp_user, $ftp_pass, $ftp_directory);
        }

        die('Settings Saved Successfully');
    }
    ?>
    <div class="panel panel-default">
        <div class="panel-heading">FTP Settings</div>
        <table class="table">
            <tr><td>Remote FTP Server:
                    <br><input type="text" class="form-control" name="_wpdm_ftp_server" value="<?php echo get_option('_wpdm_ftp_server'); ?>" /></td></tr>
            <tr><td>Remote FTP User:
                    <br><input type="text" class="form-control" name="_wpdm_ftp_user" value="<?php echo get_option('_wpdm_ftp_user'); ?>" /></td></tr>
            <tr><td>Remote FTP Password:
                    <br><input type="password" class="form-control" name="_wpdm_ftp_pass" value="<?php echo get_option('_wpdm_ftp_pass'); ?>" /></td></tr>
        </table>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">FTP Auto-Import Directory</div>
        <table class="table">
            <tr><td><input type="text" placeholder="Enter a ftp dir path" class="form-control" name="_wpdm_ftp_xml_directory" value="<?php echo get_option('_wpdm_ftp_xml_directory'); ?>" /></td>
            </tr>
        </table>
    </div>
    <?php
}

function wpdm_import_ftp_dir($ftpfile, $ftp_directory) {
    global $user_ID, $wpdb;
    $max_line_length = 10000;

    $alldata = wpdm_ftp_file_get_contents($ftpfile);
    $alldata = str_getcsv(str_replace("\r", "", $alldata), "\n");
    if (is_array($alldata)) {

        foreach ($alldata as &$data) {
            $data = str_getcsv($data, ",");
        }

        $columns = array_shift($alldata);

        foreach ($alldata as $idx => $adata) {

            $adata[0] = trim($adata[0]);
            while (count($adata) < count($columns))
                array_push($adata, NULL);
            $values = quote_all_array($adata);
            $drow = array_combine($columns, $adata);

            if (isset($drow['url_key']))
                unset($drow['url_key']);
            $drow['files'] = explode(',', $drow['files']);
            $drow['category'] = explode(',', $drow['category']);
            $drow['create_date'] = isset($drow['create_date']) ? date("Y-m-d H:i:s", strtotime($drow['create_date'])) : date("Y-m-d H:i:s", time());
            $drow['update_date'] = isset($drow['update_date']) ? strtotime($drow['update_date']) : time();
            $access = explode(",", $drow['access']);
            $drow['access'] = isset($drow['access']) && $drow['access'] != '' ? $access : array('guest');

            $query = $wpdb->prepare('SELECT ID FROM ' . $wpdb->posts . ' WHERE post_title = %s AND post_type = \'wpdmpro\'', $drow['title'] );
            $wpdb->query($query);

            if ($wpdb->num_rows) {
                $post_id = $wpdb->get_var($query);
                $postdata = array(
                    'ID' => $post_id,
                    'post_title' => $drow['title'],
                    'post_content' => $drow['description'],
                    'post_date' => $drow['create_date'],
                    'post_type' => 'wpdmpro',
                    'post_status' => 'publish'
                );
                wp_update_post($postdata);
                $ret = wp_set_post_terms($post_id, $drow['category'], 'wpdmcategory');
            } else if (!isset($drow['ID'])) {
                $postdata = array(
                    'post_title' => $drow['title'],
                    'post_content' => $drow['description'],
                    'post_date' => $drow['create_date'],
                    'post_type' => 'wpdmpro',
                    'post_status' => 'publish'
                );

                $post_id = wp_insert_post($postdata);
                $ret = wp_set_post_terms($post_id, $drow['category'], 'wpdmcategory');
            } else {
                $post_id = $drow['ID'];
                $postdata = array(
                    'ID' => $post_id,
                    'post_title' => $drow['title'],
                    'post_content' => $drow['description'],
                    'post_date' => $drow['create_date'],
                    'post_type' => 'wpdmpro',
                    'post_status' => 'publish'
                );
                wp_update_post($postdata);
                $ret = wp_set_post_terms($post_id, $drow['category'], 'wpdmcategory');
            }
            if (isset($drow['title']))
                unset($drow['title']);
            if (isset($drow['description']))
                unset($drow['description']);
            if (isset($drow['create_date']))
                unset($drow['create_date']);

            foreach ($drow['files'] as $key => $file) {
                $drow['files'][$key] = 'ftp:' . $ftp_directory . '/' . $file;
            }


            // Preparing file meta
            $file_titles = isset($drow['file_titles'])?explode(",", $drow['file_titles']):$drow['files'];
            $file_passwords = isset($drow['file_passwords'])?explode(",", $drow['file_passwords']):array_fill(0, count($file_titles) - 1, '');
            $file_prices = isset($drow['file_prices'])?explode(",", $drow['file_prices']):array_fill(0, count($file_titles) - 1, '');
            foreach ($file_titles as $index => $file_title){
                $drow['fileinfo'][$index] = array('title' => $file_title, 'password' => $file_passwords[$index], 'price' => $file_prices[$index]);
            }

            foreach ($drow as $meta_key => $value) {
                update_post_meta($post_id, "__wpdm_" . $meta_key, $value);
            }
            update_post_meta($post_id, "__wpdm_template", "link-template-panel.php");
            update_post_meta($post_id, "__wpdm_page_template", "page-template-default.php");

            do_action('after_add_package', $post_id, $drow);
        }
    }
    //@unlink($source_file);
    echo 'Successfully Imaported CSV file';
    die();
}

if ( is_admin() ) {
    //add_action('wp_ajax_wpdm_ftpdir_tree', 'wpdm_ftpdir_tree');
    add_action('init', 'wpdm_ftpdir_tree');
    add_filter('add_wpdm_settings_tab', 'wpdm_ftp_settings_tab');
    add_filter('wpdm_meta_box', 'wpdm_ftp_metabox');
} else {
    add_action('wpdm_onstart_download', 'wpdm_ftp_download_file');
    add_action('init', 'wpdm_ftp_auto_import');
}