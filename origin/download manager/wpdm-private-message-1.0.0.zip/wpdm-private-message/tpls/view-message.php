<?php
global $current_user;
$cmsg = get_post($my_post_id);

/* Find Threaded message reciever for current reply */
$receiver = $cmsg->post_author;

if($receiver == $current_user->ID)
    $receiver = get_post_meta($my_post_id, '__receiver', true);

$user_data = get_userdata( $receiver );
$msgid = $cmsg->post_parent ? $cmsg->post_parent : $cmsg->ID;

$initmsg = get_post($msgid);

/*Mark as read*/
$msg_sts = get_post_meta($msgid, '__msg_status',true);
$msg_rcbr = get_post_meta($msgid, '__receiver', true);
if($current_user->ID == $msg_rcbr && $msg_sts == 'new') {
    update_post_meta($msgid, '__msg_status', 'old');
}
    
?>
<div class="panel-group" id="accordion">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h4 class="panel-title">
              <a data-toggle="collapse" data-parent="#accordion" href="#<?php echo $initmsg->ID; ?>">
              <?php echo $initmsg->post_title; ?>
            </a>
            </h4>
        </div>
            <div id="<?php echo $initmsg->ID; ?>" class="panel-collapse collapse in">
            <div class="panel-body">
                <?php echo wpautop($initmsg->post_content);?>
            </div>
        </div>
   </div>
   <?php   
  
    global $current_user;
    $args = array(
	'post_type' => 'message',
        'post_parent' => $msgid,
        'orderby' => 'date', 
        'order' => 'ASC'
	 
    );
    $show_message = new WP_Query( $args);
    while($show_message->have_posts()){
        $show_message->the_post();

        $msg_sts = get_post_meta(get_the_ID(), '__msg_status',true);
        $msg_rcbr = get_post_meta(get_the_ID(), '__receiver', true);
        if($current_user->ID == $msg_rcbr && $msg_sts == 'new') {
            update_post_meta(get_the_ID(), '__msg_status', 'old');
        }

        $dv = (get_the_author_meta('ID') == $current_user->ID) ? '__deleted_by_sender' : '__deleted_by_receiver';
        if(get_post_meta(get_the_ID(), $dv, true)==0){
       
    ?>  
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">
              <a data-toggle="collapse" href="#<?php the_ID(); ?>">
                  Replied By <?php echo get_the_author(); ?> <span class="pull-right text-success hidden-sm hidden-xs"><?php echo get_the_date(); ?></span>
                  <span class="label label-success hidden-lg hidden-md"><?php echo get_the_date(); ?></span>
            </a>
          </h4>
        </div>
          <div id="<?php the_ID();?>" class="panel-collapse collapse">
          <div class="panel-body">
            <?php the_content();?>
          </div>
        </div>
      </div>
    <?php }}?>
    
</div>

 
   
   
<form class="form" role="form" method="post" id="replymessageform">
    <input type="hidden" name="childmessage" value="1" />
    <input type="hidden" name="parentmessage" value="<?php echo $initmsg->ID; ?>" />
    <input type="hidden" name="email" value="<?php echo $user_data->user_email;?>" />
    <input type="hidden" name="subject" value="reply of: <?php echo $my_post_id;?>" />
    <input type="hidden" name="sent_to" value="<?php echo $receiver?>" />
    <div class="form-group">
        <textarea rows="6" name="private_message[message]" class="form-control" required></textarea>                        
    </div>
    <div class="form-group">
        <div class="pull-left hide" id="replyloading"><i class="fa fa-spinner fa-spin"></i> Sending Message...</div>
        <button type="submit" class="btn btn-primary btn-embossed pull-right">Reply</button>
    </div>
</form>

<script>
jQuery(document).ready(function($){
    jQuery('#replymessageform').submit(function(){
        jQuery('#replyloading').removeClass('hide');
        jQuery(this).ajaxSubmit({           
            success: function(res){
                jQuery('#accordion').append(res);
                
                jQuery('#accordion').append('<div class="alert alert-success pms" style="margin-top:12px;">Message Sent Successfully</div>');
                
                jQuery('.form-control').each(function(){
                    jQuery(this).val('');
                    });
                jQuery('.pms').fadeOut(3000,function(){
                        jQuery(this).remove();
                    });
                    
                jQuery('#replyloading').addClass('hide');
           }        
    });        
    return false;    
});
});
</script>