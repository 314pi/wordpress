<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="panel panel-default">
    <div class="panel-body">
        <h3 class="sechead fetfont"><i class="fas fa-paper-plane title-icon color-blue"></i> Sent</h3>

        <table class="table table-striped manage-q"  id="sent-table">
            <tr v-for="message in messages" v-bind:id="[ 'delete_received_message_row_' + message.ID ]">
                <td width="100px"><nobr><span class="text-muted">To:</span> {{ message.to_name }}</nobr></td>
                <td>
                    <a href="#viewmessage" data-toggle="tab" href="#" v-bind:rel="message.ID"  v-bind:class="['wpdmpm-open wpdmpm-status-' + message.status]"><strong><span v-if="message.last_reply">[ RE#{{ message.last_reply }} ]</span> {{ message.post_title }}</strong></a>
                </td>
                <td class="text-right">
                    <a href="#" v-bind:rel="message.ID" class="ttip btn-modify remove_received_message" title="Delete message"><i class="fas fa-trash text-muted"></i></a>
                </td>
            </tr>

        </table>

    </div>
</div>

<script>
    jQuery(document).ready(function ($) {

        $('.remove_sent_message').click(function (event) {
            event.preventDefault();
            if (!confirm('Are you sure?')) return false;
            $(this).find('i').removeClass('fa-trash').addClass('fa-sun fa-spin color-red');
            var pid = $(this).attr('rel');
            $.ajax({
                type: 'POST',
                url: "index.php?pmtask=delete&pid=" + pid,
                dataType: 'json',
                success: function (result) {
                    $('#delete_sent_message_row_' + result.id).remove();

                }
            });
            return false;
        });

        $('.open-msg-thread').click(function (event) {
            event.preventDefault();
            var pid = $(this).attr('rel');
            $('#msgtab').removeClass('hide');
            $('#msgtab a').tab('show');
            $('#msgpane').load("<?php echo home_url('/'); ?>?mid=" + pid + "&pmtask=showmessage");

        });

    });
</script>