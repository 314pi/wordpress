

<form class="form" role="form" method="post" id="messageform">
    <div class="panel panel-default">

        <div class="panel-body">
            <h3 class="sechead fetfont"><i class="fas fa-pen-square title-icon color-purple"></i> <?php echo __("Compose", "wpdm-private-message"); ?></h3>

    <input type="hidden" name="message" value="1" />

    <?php
    if (!isset($pms['member'])) {
        echo '<input type="hidden" name="admin" value="1" />';
    }
    ?>


    <div class="form-group">
        <?php if (isset($pms['member'])) { ?>
            <div class="input-group">
                <div class="input-group input-group-lg">
                    <div class="input-group-addon input-group-prepend">
                <span class="input-group-text" style="display: block;width: 80px">
                    <?php echo __("To", "wpdm-private-message") ?>:
                </span>
                    </div>
                    <input id="email-request" type="text" name="send_to" class="form-control input-lg no-radius" placeholder="<?php echo __("Start typing to see suggestions...", "wpdm-private-message") ?>" required />
                    <div id="wpdmpm-sugestions" class="list-group" style="display: none;position: absolute;margin-top: 48px;z-index: 999">
                        <a  v-for="user in suggestions" href="#"  v-bind:rel="user.email" class="list-group-item">
                            <div class="media">
                                <div class="align-self-center pull-left">
                                <img v-bind:src="user.picture" alt="Profile Pic">
                                </div>
                                <div class="media-body">
                                    <strong>{{ user.name }}</strong>
                                    <div>{{ user.email }}</div>
                                </div>
                            </div>

                        </a>
                    </div>
                </div>
                <?php if (isset($pms['admin'])) { ?>
                <label class="input-group-addon input-group-append" style="border-right-width: 1px !important;border-radius: 0 3px 3px 0 !important;background: #fafafa">
                    <span class="input-group-text">
                            <input  type="checkbox" id="sendtoadmin" class="wpdm-checkbox s-light" <?php if (!isset($pms['member'])) echo "checked=checked required"; ?> value="1" name="admin"> Send to Site Admin
                    </span>
                </label>
                <?php } ?>
            </div>
        <?php }
        if (!isset($pms['member']) && isset($pms['admin'])) { ?>
                <input type="hidden" value="1" name="admin">
        <?php } ?>
    </div>


    <div class="form-group">

        <div class="input-group input-group-lg">
            <div class="input-group-addon input-group-prepend">
                <span class="input-group-text"  style="display: block;width: 80px">
                    <?php echo __("Subject", "wpdm-private-message") ?>:
                </span>
            </div>
            <input type="text" name="subject" class="form-control" required />
        </div>
    </div> 
    <div class="form-group">
        <div class="panel panel-default panel-dashboard">
            <div class="panel-heading"><?php echo __("Message", "wpdm-private-message"); ?></div>
            <div style="margin-top: -36px">
                <?php

                $settings = array( 'media_buttons' => false, 'name' => 'message', 'teeny' => true );

                wp_editor( '', 'message', $settings );

                ?>
            </div>
        </div>

    </div>

        </div>
        <div class="panel-footer text-right">
            <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-paper-plane"></i> <?php echo __("Send Message", "wpdm-private-message"); ?></button>
        </div>
    </div>
</form>


<script>


jQuery(document).ready(function($){

    $('#sendtoadmin').on('change',function(){
        if(this.checked){
            $('#email-request').attr('disabled','disabled');
        } else {
            $('#email-request').removeAttr('disabled');
        }
    });



    $('#messageform').submit(function(){
        $('#messageform').addClass('blockui');

        try {
            var editor = tinymce.get('message');
            editor.save();
        }catch(e){}

        $(this).ajaxSubmit({
            url: wpdmpmAPI.send_message,
            beforeSubmit: function ( arr, $form, options ) {
                options.headers = {'X-WP-Nonce': wpdmpmAPI.nonce}
            },
            success: function(res){
                if(res.error === true)
                    WPDM.notify("<b>Error!</b> "+res.message, "error");
                else{
                    WPDM.notify("<b>Success!</b> Message Sent", "success");
                    $('.form-control').each(function(){
                        $(this).val('');
                    });
                    editor.setContent('');
                    $('#alertdiv').fadeOut(3000,function(){
                        $(this).html('');
                        $(this).attr('style','');
                    });
                }
                $('#messageform').removeClass('blockui');
            }
        
    });
    return false;
    });

    /*
   $('#email-request').autocomplete({
        source: "",
        minLength: 2,
        select: function( event, ui ) {
        
        }
    });
    */
});
</script>

<style>
    .input-group-lg .input-group-prepend + .form-control{
        border-radius: 0 3px 3px 0;
    }
    .input-group-lg .input-group-addon{
        background: #ffffff;
    }
    .input-group-lg .input-group-addon.input-group-append{
        border-radius: 0 3px 3px 0 !important;
    }
    .input-group-lg .input-group-addon.input-group-prepend{
        border-radius: 3px 0 0 3px !important;
        text-align: left;
    }
    .form-control:disabled{
        background: #ffffff;
    }
    .wp-editor-container{
        border: 0 !important;
    }
    .mce-top-part::before{
        display: none;
    }
    .wp-editor-tabs{
        margin-right: 10px;
    }
    #wpdmpm-sugestions{
        max-height: 400px;
        overflow: auto;
    }
    #wpdmpm-sugestions .media img{
        width: 48px;
        border-radius: 500px;
    }
    #wpdmpm-sugestions .media{
        line-height: normal;
    }
    #email-request:disabled{
        background: #ffffff;
        color: #cccccc;
    }
</style>