<?php
/**
 * User: shahnuralam
 * Date: 12/12/18
 * Time: 1:12 AM
 */
if (!defined('ABSPATH')) die();
?>
<div  id="msg-cont">
    <div class="panel panel-default panel-message">
        <div class="panel-body">
            <h3 class="sechead fetfont"><i class="fas fa-envelope-open-text"></i> Message</h3>
            <h3 class="sechead fetfont" style="font-size: 10pt;font-weight: 600">
                {{ message.post_title }}
            </h3>

            <span v-html="message.post_content"></span>




        </div>
        <div class="panel-footer text-muted">
            <i class="far fa-user-circle"></i> {{ message.author_name }} &nbsp;
            <i class="far fa-calendar-check"></i> {{ message.post_date }} &nbsp;
        </div>
    </div>
    <div class="panel panel-default panel-reply" v-for="comment in message.comments">
        <div class="panel-body">
            <span v-html="comment.comment_content"></span>
        </div>
        <div class="panel-footer text-muted">
            <div class="pull-right float-right">RE#{{ comment.comment_ID }}</div>
            <i class="far fa-user-circle"></i> {{ comment.author_name }} &nbsp;
            <i class="far fa-calendar-check"></i> {{ comment.comment_date }} &nbsp;
        </div>
    </div>

    <form method="post" id="post_reply">
    <div class="panel panel-default">
            <input id="message_id" type="hidden" name="message_id"  v-bind:value="message.ID">
            <textarea id="reply" name="reply" placeholder="Write your reply..." class="form-control" style="max-width: 100%;min-width: 100%;border: 0;min-height: 80px"></textarea>

        <div class="panel-footer text-right">
            <button type="submit" class="btn btn-primary">Reply</button>
        </div>
    </div>
    </form>

</div>
