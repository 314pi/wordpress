<?php
global $current_user;
$pms = maybe_unserialize(get_option('pm_settings'));

$mlimit = !@empty($pms['max_msg'][$current_user->roles[0]])?$pms['max_msg'][$current_user->roles[0]]:0;

/*Count messages sent by current user*/
$authorid = get_current_user_id();
$user_msg_count = 0;
$user_msg_count = count_user_posts( $authorid , 'message' );

$percent = $mlimit > 0 ? $user_msg_count*100/$mlimit : 0;
 
?>
<div class="w3eden">
<div class="main-content pm-content">

    <!-- Widget Stats -->
    <div class="row">

        <?php if(!isset($params['menu']) || $params['menu'] === 'left'){ ?>
        <div class="col-md-3">

            <a class="btn btn-primary btn-lg btn-block" style="margin-bottom: 15px" href="#compose" data-toggle="tab" aria-expanded="true"><i class="fas fa-pen-square"></i> Compose</a>

            <div class="list-group">
                <a class="list-group-item" href="#inbox" data-toggle="tab" aria-expanded="false"><i class="fas fa-inbox color-purple"></i> Inbox</a>
                <a class="list-group-item" href="#sent" data-toggle="tab"><i class="fas fa-paper-plane color-blue"></i> Sent</a>
            </div>

            <br/>

                <div id="mlimit" data-toggle="tooltip" class="progress" style="margin: 0" title="Sending Limit ( <?php echo $user_msg_count; ?> / <?php echo $mlimit; ?> )">
                    <div class="progress-bar " style="width: <?php echo $percent; ?>%;"></div>
                </div>

        </div>
        <?php } ?>

        <?php if(isset($params['menu']) && $params['menu'] === 'top'){ ?>
        <div class="col-md-12">

            <div class="pull-right float-right">
                <div id="mlimit" data-toggle="tooltip" class="progress" style="margin: 0" title="Sending Limit ( <?php echo $user_msg_count; ?> / <?php echo $mlimit; ?> )">
                    <div style="font-size: 9px;position: absolute;width: 100%;line-height: 37px;text-align: center;z-index: 999999;color: rgba(0,0,0,0.5)">Sending Limit ( <?php echo $user_msg_count; ?> / <?php echo $mlimit; ?> )</div>
                    <div class="progress-bar " style="width: <?php echo $percent; ?>%;"></div>
                </div>
            </div>

            <a class="btn btn-primary" href="#compose" style="margin-right: 15px;border-width: 1px" data-toggle="tab" aria-expanded="true"><i class="fas fa-pen-square"></i> Compose</a>

                <div class="btn-group">
                    <a class="btn btn-default btn-simple" href="#inbox" data-toggle="tab" aria-expanded="false"><i class="fas fa-inbox color-purple"></i> Inbox</a>
                    <a class="btn btn-default btn-simple" href="#sent" data-toggle="tab"><i class="fas fa-paper-plane color-blue"></i> Sent</a>
                </div>





            <br/>
            <br/>
        </div>
        <?php } ?>
        <div  class="col-md-<?php echo (!isset($params['menu']) || $params['menu'] === 'left')?9:12; ?>">

                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="inbox">

                            <!-- Inbox Tab -->

                                <?php
                                include('received-message.php');
                                ?>

                            <!--/ Inbox Tab -->

                        </div>
                        <div class="tab-pane fade" id="compose">

                            <!-- Compose Tab -->

                                <?php
                                include('message-form.php');
                                ?>

                            <!--/ Compose Tab -->
                        </div>
                        <div class="tab-pane fade" id="sent">

                                <?php
                                include('sent-message.php');
                                ?>

                        </div>

                        <div class="tab-pane fade" id="viewmessage">

                                <?php
                                include('open-message.php');
                                ?>

                        </div>

                    </div>

        </div>




</div>
</div>
</div>
<style>

    .sechead{
        margin: 0 0 15px 0 !important;font-size: 14pt;line-height: normal;font-weight: bold;border-bottom: 1px solid #eeeeee;padding-bottom: 10px;

    }
    .title-icon{
        margin-top: 2px;
        margin-right: 5px;
    }
    .table td{
        border-color: #eeeeee !important;
    }
    .table{
        margin: 0 !important;
    }
    .list-group a .fas{
        margin-right: 5px !important;
    }
    #mlimit{
        position: relative;
    }
    .pull-right #mlimit{
        margin: 0;width: 200px;height: 37px;border-radius: 3px !important;
    }
    #mlimit .progress-bar{
        background-color: #8f6fd5;
    }
    label.input-group-addon{
        cursor: pointer;
    }
    .panel-body p{
        margin-bottom: 10px;
    }
    .panel-body p:last-child{
        margin-bottom: 0;
    }

    .w3eden a.wpdmpm-open,
    .w3eden a.wpdmpm-status-read{
        color: #90979c;
    }

    .w3eden a.wpdmpm-status-new{
        color: #4280de;
    }

    .w3eden .tab-content{
        padding: 0;
        border: 0;
    }
    .tab-content .fade.in{
        background: transparent !important;
    }

</style>
<?php 
    /* Restore original Post Data */
    wp_reset_postdata();
?>
<script src="https://cdn.jsdelivr.net/npm/vue"></script>
<script>


    var $ = jQuery;

    var inbox = new Vue({
        el: '#inbox-table',
        data: {
            messages: []
        }
    });

    var sent = new Vue({
        el: '#sent-table',
        data: {
            messages: []
        }
    });

    var message = new Vue({
        el: '#msg-cont',
        data: {
            message: []
        }
    });

    var searchusers = new Vue({
        el: '#wpdmpm-sugestions',
        data: {
            suggestions: [{name: 'Start Typing', email: 'to see the sugestions...'}]
        }
    });

    WPDM.audio = "<?php echo plugins_url("sounds/filling-your-inbox.mp3", dirname(__FILE__)); ?>";

    class WPDMPM {

        static refreshInbox() {
            $.ajax(wpdmpmAPI.get_messages,{
                method: 'GET',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', wpdmpmAPI.nonce );
                }
            }).done(function (data) {
                inbox.messages = data
            });
        }

        static refreshSent() {
            $.ajax(wpdmpmAPI.get_messages,{
                method: 'GET',
                data: { folder: "sent" },
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', wpdmpmAPI.nonce );
                }
            }).done(function (data) {
                sent.messages = data
            });
        }

        static checkNewMessage(){

            $.ajax(wpdmpmAPI.check_new_message,{
                method: 'GET',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', wpdmpmAPI.nonce );
                }
            }).done(function (data) {
                if(data.new_message){
                    //WPDM.notify("<b>"+data.new_message+"</b> new message(s) in your inbox!")
                    WPDM.pushNotify("New Message", "You have "+data.new_message+" new message!", "https://cdn2.iconfinder.com/data/icons/black-friday-shopping-3/228/Asset_1120-512.png", "https://cdn1.iconfinder.com/data/icons/hawcons/32/699318-icon-47-note-important-128.png", location.href);
                    WPDM.beep();
                    WPDMPM.refreshInbox();
                }
            });

            setTimeout("WPDMPM.checkNewMessage()", <?php echo isset($pms['reload']) && $pms['reload'] > 0 ? $pms['reload']*1000:2000; ?>);
        }
    }

    jQuery(function($){

        $('#mlimit').tooltip();

        WPDMPM.refreshInbox();

        WPDMPM.refreshSent();

        WPDMPM.checkNewMessage();

        $('body').on('keyup', '#email-request', function(event){

            var search = $(this).val();

            if(search.length < 2) return;

            $.ajax(wpdmpmAPI.users,{
                method: 'GET',
                data: {keyword: search},
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', wpdmpmAPI.nonce );
                }
            }).done(function (data) {
                if(data.length > 0)
                    $('#wpdmpm-sugestions').fadeIn();
                else
                    $('#wpdmpm-sugestions').fadeOut();
                searchusers.suggestions = data;
            });
        });

        $(document).mouseup(function(e) {
            var container = $('#wpdmpm-sugestions');
            if (!container.is(e.target) && container.has(e.target).length === 0) container.hide();
        });

        $('body').on('click', '#wpdmpm-sugestions a',  function (e) {
            e.preventDefault();
            $('#email-request').val(this.rel);
            $('#wpdmpm-sugestions').fadeOut();
        });

        $('body').on('click', '.remove_received_message', function(event){
            event.preventDefault();
            if(!confirm('Are you sure?')) return false;
            var pid = $(this).attr('rel');

            $(this).find('.fas').removeClass('fa-trash text-muted').addClass('fa-sun fa-spin color-red');

            $.ajax(wpdmpmAPI.delete_message,{
                method: 'POST',
                data: {id: pid},
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', wpdmpmAPI.nonce );
                }
            }).done(function (data) {
                $('#delete_received_message_row_'+pid).remove();
            });
        });

        $('body').on('click', '.wpdmpm-open', function(event){
            event.preventDefault();
            var id = $(this).attr('rel');

            if($(this).hasClass('wpdmpm-status-new'))
                $(this).removeClass('wpdmpm-status-new').addClass('wpdmpm-status-read');

            //$('#viewmessage').tab('show');
            $('#msg-cont').css('min-height', '400px').addClass('blockui');
            $.ajax(wpdmpmAPI.get_message,{
                method: 'GET',
                data: {id: id},
                beforeSend: function (xhr) {
                    xhr.setRequestHeader( 'X-WP-Nonce', wpdmpmAPI.nonce );
                }
            }).done(function (data) {
                message.message = data;
                console.log(message.message);
                $('#msg-cont').removeClass('blockui');
            });


        });

        $('body').on('submit', '#post_reply', function(e){
            e.preventDefault();
            $('#post_reply').addClass('blockui');
            var msgid = $('#message_id').val();
            $(this).ajaxSubmit({
                url: wpdmpmAPI.create_reply,
                beforeSubmit: function ( arr, $form, options ) {
                    options.headers = {'X-WP-Nonce': wpdmpmAPI.nonce}
                },
                success: function(res){
                    if(res.error === true)
                        WPDM.notify("<b>Error!</b> "+res.message, "error");
                    else{
                        WPDM.notify("<b>Success!</b> Reply Sent", "success");
                        $('.form-control').each(function(){
                            $(this).val('');
                        });
                        WPDMPM.refreshSent();

                    }
                    $('#post_reply').removeClass('blockui');
                    $('#msg-cont').addClass('blockui');
                    $.ajax(wpdmpmAPI.get_message,{
                        method: 'GET',
                        data: {id: msgid, skip_status: 1},
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader( 'X-WP-Nonce', wpdmpmAPI.nonce );
                        }
                    }).done(function (data) {
                        message.message = data;
                        console.log(message.message);
                        $('#msg-cont').removeClass('blockui');
                    });

                }
            });
            return false;
        });

        var pushids = <?php echo json_encode(get_user_meta(get_current_user_id(), '__wpdm_onesignal_player_id')); ?>;

        if(typeof OneSignal !== "undefined") {
            try {
                OneSignal.getUserId(function (id) {
                    if (!JSON.stringify(pushids).indexOf(id)) {
                        $.post(wpdm_ajax_url, {
                            action: 'wpdm_onesignal_player_id',
                            __wpdm_onesignal_player_id: id
                        }, function (res) {

                        });
                    }
                });
            } catch (e) {
                console.log(e);
            }
        }

    });







</script>