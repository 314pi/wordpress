<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="panel panel-default">
    <div class="panel-body">
        <h3 class="sechead fetfont"><i class="fas fa-inbox title-icon color-purple"></i> Inbox</h3>


        <table class="table table-striped manage-q"  id="inbox-table">
            <tr v-for="message in messages" v-bind:id="[ 'delete_received_message_row_' + message.ID ]">
                <td width="100px"><nobr><span class="text-muted">From:</span> {{ message.from_name }}</nobr></td>
                <td>
                    <a href="#viewmessage" data-toggle="tab" v-bind:rel="message.ID" v-bind:class="['wpdmpm-open wpdmpm-status-' + message.status]"><strong><span v-if="message.last_message">[ RE#{{ message.last_message }} ]</span> {{ message.post_title }}</strong></a>
                </td>
                <td class="text-right">
                    <a href="#" v-bind:rel="message.ID" class="ttip btn-modify remove_received_message" title="Delete message"><i class="fas fa-trash text-muted"></i></a>
                </td>
            </tr>

        </table>



    </div>
</div>

<script>
jQuery(document).ready(function($){


        
        $("#mydiv").load(location.href + " #mydiv");
    
});
</script>