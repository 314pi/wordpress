<?php
$pms = maybe_unserialize(get_option('pm_settings'));

if(!isset($pms['admin']))
    $pms['admin'] = '';
if(!isset($pms['member']))
    $pms['member'] = '';

global $wp_roles;
$roles = $wp_roles->get_names();
?>


<div class="w3eden">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading"><b>Private Message Settings</b></div>
                    <div class="panel-body">

                    <div class="form-group">
                        <label>
                                <input type="checkbox" <?php checked($pms['admin'],1); ?> value="1" name="__wpdm_pm[admin]" />
                              Allow members to send message to site admin</label><br/>

                    </div>

                    <div class="form-group">
                        <label>

                            <input type="checkbox" <?php checked($pms['member'],1); ?> value="1" name="__wpdm_pm[member]" data-toggle="switch" />
                            &nbsp; Allow members to send message to other site members
                        </label><br/>
                    </div>

                    <div class="form-group">
                        <label>Admin Email to Receive Private Message</label>
                        <input placeholder="Enter a valid email address" type="text" class="form-control" value="<?php echo isset($pms['admin_email'])?$pms['admin_email']:""; ?>" name="__wpdm_pm[admin_email]" />

                    </div>

                    <div class="form-group">
                        <label><?php echo __("New Message Check Interval", "wpdm-private-message") ?></label>
                        <div class="input-group">
                            <input type="number" min="5" class="form-control" value="<?php echo isset($pms['reload'])?$pms['reload']:"10"; ?>" name="__wpdm_pm[reload]" />
                            <div class="input-group-addon">Seconds</div>
                        </div>
                    </div>






            </div>
                    <div class="panel-heading" style="border-top: 1px solid #dddddd">Message Limits</div>

                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>User Role</th>
                                <th style="width: 100px">Limit</th>
                            </tr>
                            </thead>
                            <?php foreach($roles as $id=>$name){ ?>
                                    <tr><td><?php echo $name; ?></td><td><input type="number" class="form-control" value="<?php echo !@empty($pms['max_msg'][$id])?$pms['max_msg'][$id]:20; ?>" name="__wpdm_pm[max_msg][<?php echo $id; ?>]" /></td></tr>
                            <?php } ?>
                        </table>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    jQuery(document).ready(function($){
        jQuery('#crform').submit(function(){
            //jQuery('#load-data').button('loading');
            jQuery('#load-data').text('Saving...');
            jQuery(this).ajaxSubmit({
                url: ajaxurl,
                success: function(res){
                    //jQuery('#load-data').button('reset');
                    jQuery('#load-data').text('Save Settings');
                }
            });
            return false;
        });
    });
</script>

<style>
    .w3eden .list-group-item.active, .w3eden .list-group-item.active:focus, .w3eden .list-group-item.active:hover {

        z-index: 2;
        color: #555555;
        background-color: #f7f7f7;
        border-color: #dddddd;
        font-weight: 800 !important;

    }
</style>