<?php
/**
 * User: shahnuralam
 * Date: 9/12/18
 * Time: 3:03 PM
 */

namespace WPDM\AddOn\libs;


use WPDM\Email;
use WPDM\libs\MailUI;

class PMAPI
{

    function __construct()
    {

        $pms = maybe_unserialize(get_option('pm_settings'));
        foreach ($pms as $key => $value){
            $this->$key = $value;
        }

        add_action("wp_enqueue_scripts", array($this, 'scripts'), 999999);

        add_action( 'rest_api_init', array($this, 'apiInit'));
    }

    function scripts(){
        //wp_enqueue_script("jquery");
        if(is_user_logged_in() || 1) {
            wp_localize_script('jquery', 'wpdmpmAPI', array(
                'root' => esc_url_raw(rest_url()),
                'send_message' => esc_url_raw(rest_url('wpdmpm/v1/send-message')),
                'create_reply' => esc_url_raw(rest_url('wpdmpm/v1/create-reply')),
                'get_messages' => esc_url_raw(rest_url('wpdmpm/v1/get-messages')),
                'get_message' => esc_url_raw(rest_url('wpdmpm/v1/get-message')),
                'delete_message' => esc_url_raw(rest_url('wpdmpm/v1/delete-message')),
                'check_new_message' => esc_url_raw(rest_url('wpdmpm/v1/check-new-message')),
                'users' => esc_url_raw(rest_url('wpdmpm/v1/users')),
                'nonce' => wp_create_nonce('wp_rest')
            ));
        }
    }


    function apiInit(){


        register_rest_route( 'wpdmpm/v1', '/send-message', array(
            'methods' => 'POST',
            'callback' => array($this, 'sendMessage'),
        ) );

        register_rest_route( 'wpdmpm/v1', '/create-reply', array(
            'methods' => 'POST',
            'callback' => array($this, 'createReply'),
        ) );


        register_rest_route( 'wpdmpm/v1', '/get-messages', array(
            'methods' => 'GET',
            'callback' => array($this, 'getMessages'),
        ) );


        register_rest_route( 'wpdmpm/v1', '/get-message', array(
            'methods' => 'GET',
            'callback' => array($this, 'getMessage'),
        ) );

        register_rest_route( 'wpdmpm/v1', '/delete-message', array(
            'methods' => 'POST',
            'callback' => array($this, 'deleteMessage'),
        ) );

        register_rest_route( 'wpdmpm/v1', '/check-new-message', array(
            'methods' => 'GET',
            'callback' => array($this, 'checkNewMessage'),
        ) );

        register_rest_route( 'wpdmpm/v1', '/users', array(
            'methods' => 'GET',
            'callback' => array($this, 'searchUsers'),
        ) );
    }

    function checkNewMessage(){
        global $current_user;
        $wpdmpm_settings = maybe_unserialize(get_option('pm_settings'));
        if(!is_user_logged_in()) wp_send_json(array('error' => true, 'message' => 'Authorization Failed!'));
        $args = array(
            'post_type' => 'message',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '__wpdmpm_inbox_'.$current_user->ID,
                    'value' => 1
                ),
                array(
                    'key' => '__msg_status_'.$current_user->ID,
                    'value' => 'new'
                ),
                array(
                    'key' => '__deleted_by_receiver',
                    'value' => 0
                )
            )
        );

        $messages = new \WP_Query($args);
        $new_messages = $messages->post_count;
        $oldcount = get_user_meta($current_user->ID, "__wpdmpm_inbox_message_count", true);
        if($new_messages != $oldcount){
            update_user_meta($current_user->ID, "__wpdmpm_inbox_message_count", $new_messages);
            if($new_messages > $oldcount)
                wp_send_json(array('new_message' => $new_messages - $oldcount));
        }

        wp_send_json(array('new_message' => 0));
    }

    function getMessages(){
        global $current_user;
        $wpdmpm_settings = maybe_unserialize(get_option('pm_settings'));
        if(!is_user_logged_in()) wp_send_json(array('error' => true, 'message' => 'Authorization Failed!'));
        $folder = wpdm_query_var('folder');

        if($folder === 'sent'){

            $args = array(

                'post_type' => 'message',
                'posts_per_page' => -1,
                'orderby' => 'modified',
                'order' => 'DESC',
                'meta_query' => array(
                    array(
                        'key' => '__wpdmpm_sentbox_'.$current_user->ID,
                        'value' => 1,
                        'compare' => '='
                    ),
                    array(
                        'key' => '__deleted_by_sender',
                        'value' => 1,
                        'compare' => '<'
                    )
                )
            );
            $messages = new \WP_Query($args);
            $messages = $messages->get_posts();


        } else {


            $args = array(
                'post_type' => 'message',
                'posts_per_page' => -1,
                'orderby' => 'modified',
                'order' => 'DESC',
                'meta_query' => array(
                    array(
                        'key' => '__wpdmpm_inbox_'.$current_user->ID,
                        'value' => 1,
                        'compare' => '='
                    ),
                    array(
                        'key' => '__deleted_by_receiver',
                        'value' => 1,
                        'compare' => '<'
                    )
                )
            );

            $messages = new \WP_Query($args);
            $messages = $messages->get_posts();


        }


        foreach ($messages as &$message){
            $message->status = get_post_meta($message->ID, '__msg_status_'.$current_user->ID, true);
            $message->last_reply = (int)get_post_meta($message->ID, '__wpdmpm_last_reply_'.$current_user->ID, true);
            if($message->last_reply > 0)
                $message->last_reply_from = get_comment($message->last_reply)->comment_author;
            else
                $message->last_reply_from = false;
            $message->last_message = (int)get_post_meta($message->ID, '__wpdmpm_last_message_'.$current_user->ID, true);
            if($message->last_message > 0)
                $message->last_message_from = get_comment($message->last_message)->comment_author;
            else
                $message->last_message_from = false;
            $message->receiver = get_user_by('id', get_post_meta($message->ID, '__receiver', true))->data;
            unset($message->receiver->user_pass);
            $message->sender = get_user_by('id', $message->post_author)->data;
            unset($message->sender->user_pass);

            if($folder === 'sent') {
                if($message->post_author == $current_user->ID)
                    $message->to_name = $message->receiver->display_name;
                else
                    $message->to_name = $message->sender->display_name;
            } else {
                if($message->post_author == $current_user->ID)
                    $message->from_name = $message->receiver->display_name;
                else
                    $message->from_name = $message->sender->display_name;
            }

        }
        wp_send_json($messages);


    }

    function getMessage(){
        global $current_user;
        $wpdmpm_settings = maybe_unserialize(get_option('pm_settings'));
        if(!is_user_logged_in()) wp_send_json(array('error' => true, 'message' => 'Authorization Failed!'));
        $folder = wpdm_query_var('folder');

        $id = wpdm_query_var('id');

        $receiver = get_post_meta($id, '__receiver', true);

        $message = get_post($id);
        $message->author_name = get_userdata( $message->post_author )->display_name;
        $message->post_date = date(get_option('date_format')." ".get_option('time_format'), strtotime($message->post_date));

        //if($receiver->ID !== $current_user->ID && $message->post_author !== $current_user->ID ) wp_send_json(array('error' => true, 'message' => 'Invalid message ID!'));

        $message->receiver = get_user_by('id', $receiver)->data;
        unset($message->receiver->user_pass);
        $message->sender = get_user_by('id', $message->post_author)->data;
        unset($message->sender->user_pass);

        $message->comments = get_comments(array('post_id' => $id, 'order' => 'ASC',  'orderby' => 'comment_date'));

        foreach ($message->comments as &$comment){
            $comment->comment_date = date(get_option('date_format')." ".get_option('time_format'), strtotime($comment->comment_date));
            $comment->author_name = get_userdata( $comment->user_id )->display_name;
        }

        $last_comment = end($message->comments);
        $last_commenter = $last_comment && $last_comment->user_id?$last_comment->user_id:null;

        if($last_commenter != $current_user->ID && !isset($_GET['skip_status']))
            update_post_meta($id, '__msg_status_'.$current_user->ID, 'read');

        wp_send_json($message);


    }

    function sendMessage(){

        global $current_user, $wpdb;
        $wpdmpm_settings = maybe_unserialize(get_option('pm_settings'));


        $sender = $current_user;

        if(!$sender->ID) wp_send_json(array('error' => true, 'message' => 'Only valid users can send a reply!'));

        if(!isset($_POST['subject'], $_POST['message'])) wp_send_json(array('error' => true, 'message' => 'Missing a required data field!'));



        /* User to Admin message ON, Sending to Only Admin */
        /* U2U and U2A both OFF, Default action send to site Admin */
        if( ( isset($wpdmpm_settings['admin']) && isset($_POST['admin'])) || (!isset($wpdmpm_settings['member']) && isset($wpdmpm_settings['admin'])) || !isset($wpdmpm_settings['admin']) && !isset($wpdmpm_settings['member']) ){
            $admins = get_users(array('role__in' => ('administrator')));
            $user = $admins[0];
            $admin_email = isset($wpdmpm_settings['adminemail']) && $wpdmpm_settings['adminemail']!='' ? $wpdmpm_settings['adminemail'] : $user->user_email;
            $pm_message['email'] = $admin_email;
        }

        /* User to User message ON, not sending to site Admin */
        if( isset($wpdmpm_settings['member']) && is_email(wpdm_query_var('send_to', 'txt')) && !isset($_POST['admin'])) {
            $user = get_user_by( 'email', wpdm_query_var('send_to', 'txt'));
            if(!$user) wp_send_json(array('error' => true, 'message' => 'User email not found!'));
            $pm_message['email'] = $user->user_email;
        }

        if(!isset($user) || !is_object($user) || $user->ID == 0) wp_send_json(array('error' => true, 'message' => 'Missing a required data field!'));

        $mlimit= !@empty($wpdmpm_settings['max_msg'][$current_user->roles[0]])?$wpdmpm_settings['max_msg'][$current_user->roles[0]]:0;
        /*Count messages sent by current user*/
        $authorid = get_current_user_id();
        $user_msg_count = 0;
        $user_msg_count = count_user_posts( $authorid , 'message' );

        if($mlimit > $user_msg_count || $mlimit == 0){

            $message = array(
                'post_title'    => $_POST['subject'],
                'post_content'  => $_POST['message'],
                'post_status'   => 'publish',
                'post_author'   => $sender->ID,
                'post_type'     => 'message'
            );

            $msgID = wp_insert_post($message);

            unset($user->user_pass);
            update_post_meta($msgID, '__receiver', $user->ID);
            $message['receiver'][] = $user->data;



            update_post_meta($msgID, '__deleted_by_receiver', 0);
            update_post_meta($msgID, '__deleted_by_sender', 0);

            update_post_meta($msgID, '__msg_status_'.$user->ID, 'new');
            update_post_meta($msgID, '__wpdmpm_sentbox_'.$sender->ID, 1);
            update_post_meta($msgID, '__wpdmpm_inbox_'.$user->ID, 1);






            $message['sender'] = $sender->data;

            $url = isset($this->pm_base_url) && $this->pm_base_url != ''?$this->pm_base_url:wpdm_user_dashboard_url(array('udb_page' => 'messages'));
            $params = array(
                'from'          => $sender->user_email,
                'from_name'     => $sender->display_name,
                'to_email'      => $pm_message['email'],
                'subject'       => $_POST['subject'],
                'message'       => MailUI::panel($_POST['subject'], array( $_POST['message'] . "<hr style='height: 1px;border: 0;border-top: 1px solid #dddddd;' /><a style='margin: 0 !important;display: block' class='button green' href='{$url}'>View Message</a>"))
            );
            Email::send("default", $params);

            wp_send_json($message);


        } else
            wp_send_json(array('error' => true, 'error_code' => 'reached_limit', 'message' => 'You have reached your max sending limit!'));

    }

    function createReply()
    {
        global $current_user;

        $sender = $current_user;

        if(!$sender->ID) wp_send_json(array('error' => true, 'message' => 'Only valid users can send a reply!'));

        $msgID  = $_POST['message_id'];

        $msg_receiver = get_post_meta($msgID, '__receiver', true);

        $msg = get_post($msgID);

        if((int)$sender->ID !== (int)$msg_receiver && (int)$sender->ID !== (int)$msg->post_author)  wp_send_json(array('error' => true, 'message' => 'You are not authorized!'));

        $reply = strip_tags($_REQUEST['reply'], "<b><strong><p><br><a><img><ul><ol><li>");

        $time = current_time('mysql');

        $data = array(
            'comment_post_ID' => $msgID,
            'comment_author' => $sender->display_name,
            'comment_author_email' => $sender->user_email,
            'comment_content' => wpautop($reply),
            'comment_parent' => 0,
            'user_id' => $sender->ID,
            'comment_author_IP' => wpdm_get_client_ip(),
            'comment_agent' => $_SERVER['HTTP_USER_AGENT'],
            'comment_date' => $time,
            'comment_approved' => 1,
        );

        $replyID = wp_insert_comment($data);


        update_comment_meta($replyID, '__deleted_by_receiver', 0);
        update_comment_meta($replyID, '__deleted_by_sender', 0);

        update_post_meta($msgID, '__wpdmpm_sentbox_'.$sender->ID, 1);
        update_post_meta($msgID, '__wpdmpm_inbox_'.$msg->post_author, 1);

        update_post_meta($msgID, '__wpdmpm_last_reply_'.$sender->ID, $replyID);

        $last_reply_receiver = $current_user->ID == $msg->post_author ? $msg_receiver : $current_user->ID;
        update_post_meta($msgID, '__wpdmpm_last_message_'.$last_reply_receiver, $replyID);

        update_post_meta($msgID, '__wpdmpm_last_reply_receiver', $last_reply_receiver);



        $new_status = $sender->ID == $msg->post_author ? $msg_receiver : $msg->post_author;
        //if($msg_receiver === $sender->ID) {
            update_post_meta($msgID, '__msg_status_'.$new_status, 'new');
            $_post = array(
                'ID' => $msgID,
                'post_excerpt' => time(),
            );
            wp_update_post( $_post );
        //}

        /*
        $sender = $sender->data;
        unset($sender->user_pass);
        $data['sender'] = $sender;
        $receiver = get_user_by('id', get_post_field('post_author', $msgID))->data;
        unset($receiver->user_pass);
        $data['receiver'] = $receiver;
        */
        $mail_receiver = get_userdata($new_status);
        $to_email = (user_can($mail_receiver, 'manage_options'))?$this->admin_email:$mail_receiver->user_email;
        $url = isset($this->pm_base_url) && $this->pm_base_url != ''?$this->pm_base_url:wpdm_user_dashboard_url(array('udb_page' => 'messages'));
        $params = array(
            'from'          => $sender->user_email,
            'from_name'     => $sender->display_name,
            'to_email'            => $to_email,
            'subject'       => "[RE# {$replyID}] {$msg->post_title}",
            'message'       => MailUI::panel("REPLY# {$replyID}", array($data['comment_content']."<hr style='height: 1px;border: 0;border-top: 1px solid #dddddd;'/><a style='display: block;margin: 0 !important;' class='button green' href='{$url}'>View Reply</a>"))
        );
        Email::send("default", $params);


        wp_send_json(array('success' => true, 'reply_id' => $replyID));

    }

    function searchPackages(){

        $packs = get_posts(array('post_type' => 'wpdmpro','s' => wpdm_query_var('s', 'txt'), 'posts_per_page' => 10));
        foreach ($packs as $pack){
            $data[] = array('id' => $pack->ID, 'title' => $pack->post_title);
        }
        wp_send_json($data);
        die();

    }

    function categories(){
        $cats = get_terms(array('taxonomy' => 'wpdmcategory',
            'hide_empty' => false));
        foreach ($cats as $cat){
            $data[] = array('value' => $cat->slug, 'id' => $cat->term_id, 'label' => $cat->name);
        }
        wp_send_json($data);
        die();

    }

    function deleteMessage(){
        $message_id = wpdm_query_var('id', 'int');
        $message = get_post($message_id);
        if($message->post_author === get_current_user_id() && $message->post_type === 'message'){
            update_post_meta($message_id, '__deleted_by_sender', 1);
        }
        else if((int)get_post_meta($message_id, '__receiver', true) === get_current_user_id() && $message->post_type === 'message'){
            update_post_meta($message_id, '__deleted_by_receiver', 1);
        }

        wp_send_json(array('success' => true));

    }

    function searchUsers(){
        $user_query = new \WP_User_Query( array( 'search' => "*".wpdm_query_var('keyword', 'txt')."*", 'search_columns' => array( 'user_login', 'user_email' , 'display_name', 'user_nicename' ) )  );
        $result = array();
        if ( ! empty( $user_query->get_results() ) ) {
            foreach ( $user_query->get_results() as $user ) {
                $result[] = array('name' => $user->display_name, 'email' => $user->user_email, 'picture' => get_avatar_url($user->user_email));
            }
        }
        wp_send_json($result);
    }





}

new PMAPI();