<?php

/*
  Plugin Name: WPDM - Private Message
  Plugin URI: https://www.wpdownloadmanager.com/download/wordpress-private-message/
  Description: WordPress Private Message Plugin  allows site members to send private messages (PM) to each other or site admin.
  Author: Shaon
  Version: 1.0.0
  Author URI: https://www.wpdownloadmanager.com/
 */

namespace WPDM\AddOn;

require_once dirname(__FILE__)."/libs/class.PMAPI.php";

define("PM_BASE_DIR", dirname(__FILE__).'/');
define("PM_BASE_URL", plugins_url("/wpdm-private-message/"));

global $PrivateMessage;

define('WPDMPM_TEXT_DOMAIN', 'wpdm-private-message');

class PrivateMessage{

    function __construct() {

        add_action('wp_ajax_wpdm_onesignal_player_id', array($this, 'saveOneSignalPlayerID'));

        add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));

        add_action("init", array($this,"registerPostType"));

        add_action('admin_menu', array($this, 'adminMenu'), 9999);

        add_shortcode("wpdm_private_message", array($this, "privateMessage"));

        add_filter('wpdm_user_dashboard_menu',array($this, 'dashboardMenu'),10,1);

        add_filter( 'add_wpdm_settings_tab', array( $this, 'settingsTab' ) );

    }

    function adminMenu()
    {
        add_submenu_page("edit.php?post_type=wpdmpro", __('Private Messages', 'wpdm-private-message'), __('Private Messages', 'wpdm-private-message'), 'manage_options', 'edit.php?post_type=message');
    }

    function dashboardMenu($menu_items){
        if(count($menu_items) > 4){
            $new_item['messages'] = array('name'=> __('Messages','wpdm-private-message'), 'shortcode' => '[wpdm_private_message menu="top"]');
            $menu_items = array_merge(array_splice($menu_items, 0, 2), $new_item, $menu_items);

        } else
            $menu_items['messages'] = array('name'=> __('Messages','wpdm-private-message'), 'shortcode' => '[wpdm_private_message menu="top"]');

        return $menu_items;
    }


    function enqueueScripts() {
        global $post;
        if($post && is_page($post->ID) && has_shortcode($post->post_content, 'wpdm_private_message')) {
            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-form', array('jquery'));
            wp_enqueue_script('jquery-ui-core', array('jquery'));
            wp_enqueue_script('jquery-ui-autocomplete', array('jquery'));
            wp_enqueue_style('wpdm-bootstrap');
            wp_enqueue_script('wpdm-bootstrap');
            wp_enqueue_script('wpdm-front');

        }

    }



    function registerPostType() {
        $labels = array(
            'name' => 'Messages',
            'singular_name' => 'Message',
            'add_new' => 'Add New',
            'add_new_item' => 'Add New Message',
            'edit_item' => 'Edit Message',
            'new_item' => 'New Message',
            'all_items' => 'All Messages',
            'view_item' => 'View Message',
            'search_items' => 'Search Messages',
            'not_found' => 'No Messages found',
            'not_found_in_trash' => 'No Messages found in Trash',
            'parent_item_colon' => '',
            'menu_name' => 'Messages'
        );

        $args = array(
            'labels' => $labels,
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'query_var' => true,
            'rewrite' => array('slug' => 'message'),
            'capability_type' => 'post',
            'has_archive' => false,
            'hierarchical' => false,
            'menu_position' => null,
            'menu_icon' => "dashicons-format-chat",
            'supports' => array('title', 'editor', 'author', 'comments')
        );

        register_post_type('message', $args);
    }


    function privateMessage($params = array()){
        if(!is_user_logged_in())
            return do_shortcode("[wpdm_login_form]");

        ob_start();
        include(PM_BASE_DIR."tpls/home.php");
        $data = ob_get_clean();
        return $data;
    }

    function settings(){
        if(wpdm_query_var('section') === 'pmsettings' && isset($_POST['__wpdm_pm'])){
            update_option('pm_settings',$_POST['__wpdm_pm']);
            die("Settings Saved Successfully!");
        }
        include(PM_BASE_DIR."tpls/settings.php");
    }

    function settingsTab($tabs){
        $tabs['pmsettings'] = wpdm_create_settings_tab('pmsettings', 'Private Messages', array( $this, 'settings' ), 'fas fa-comments');
        return $tabs;
    }

    function saveOneSignalPlayerID(){
        $player_ids = get_user_meta(get_current_user_id(), '__wpdm_onesignal_player_id');
        $player_ids = maybe_unserialize($player_ids);
        $player_id = wpdm_query_var('__wpdm_onesignal_player_id', 'txt');
        if(!in_array($player_id, $player_ids)){
            $player_ids[] = $player_id;
            update_user_meta(get_current_user_id(), '__wpdm_onesignal_player_id', $player_ids);
        }
        wp_send_json(array('success' => true, 'message' => 'Saved'));
    }

}

$PrivateMessage = new PrivateMessage();
