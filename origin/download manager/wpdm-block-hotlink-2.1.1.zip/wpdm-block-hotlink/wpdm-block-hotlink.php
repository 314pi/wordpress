<?php
/*
Plugin Name: WPDM - Block Hotlink
Description: Enable WPDM Pro to block hotlink from external
Plugin URI: http://www.wpdownloadmanager.com/
Author: Shaon
Version: 2.1.1
Author URI: http://www.wpdownloadmanager.com/
*/


function wpdm_protect_hotlink(){
        $vld = get_post_meta(wpdm_query_var('wpdmdl','num'), "__wpdmkey_".wpdm_query_var('_wpdmkey'), true);
        if($vld>0) return;
        $site = str_replace("http","",site_url());
        if(!isset($_SERVER['HTTP_REFERER']) || !strpos($_SERVER['HTTP_REFERER'], $site)){
        $url = (isset($_GET['wpdmdl']) && $_GET['wpdmdl']>0)?get_permalink($_GET['wpdmdl']):home_url();
        header("location: ".$url);
        die();
       }
}


add_action('wpdm_onstart_download','wpdm_protect_hotlink');
 

?>
