
=== WPS Visitor Counter Plugin ===
Contributors: arifulislamsobuj, techmix
Tags: website visitor counter, Visitor counter, visitor traffic, traffic statistics, traffic counter, blog stats, blog traffic, traffic count, visitor view count, visitor counter wordpress, visitor counter wp, website hit counter
Requires at least: 3.0.1
Tested up to: 5.3.1
Stable tag: trunk
License: GPLv2 or later

WPS Visitor Counter plugin will display your websites traffic statistics at front end. This Plugin support Widget, Shortcode and Gutenberg Block. Some of the features offered include Today Visitor, Today Hits, Yestarday Visitors, Yestraday Hits, This Month Visitors, This Months Hits, Total Hits, Total Visit, Who's Online and IP Address Visitors.

== Description ==

WPS Visitor Counter plugin is one of the best visitor counter plugin in wordpress. This plugin will help you to display the number of visitor your website have and its traffic statistics for your WordPress website. We have tried to include all the available data you needed to show in the visitor counter. Here are the items we are showing on our visitor counter:

<ul><li>Users Today </li>
<li>Users Yesterday </li>
<li>Users Last 7 days</li>
<li>Users Last 30 days</li>
<li>Users This Month </li>
<li>Users This Year</li>
<li>Total Users </li>
<li>Views Today </li>
<li>Views Yesterday</li>
<li>Views Last 7 days</li>
<li>Views Last 30 days</li>
<li>Views This Month</li>
<li>Views This Year </li>
<li>Total views </li>
<li>Who's Online</li>
<li>Your IP Address </li>
<li>Views Today </li>
<li>Total number of views</li>
<li>How many people are currently Online</li>
<li>Your IP Address </li>
<li>Server Time</li></ul>

You will find all the data authentic and this will help you to get your website traffic stat. Just install the plugin. It will affect just after you install it in your website. Our plugin is compatible for all types of websites and able to run in all versions of wordpress.
= WPS Visitor Counter shortcode =
Use this [wps_visitor_counter] Shortcode anywhere in your website where you want to show visitor counter.

== gutenberg block supported ==

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `WPS-visitor-counter.zip` to the `/wp-content/plugins/` directory. You can do this using 'Upload' functionality provided in plugins section of your wordpress dashboard
2. Activate the plugin through the `Plugins` menu in WordPress
3. Go to `Appearance` >> `Widgets` and drag `WPS - Visitor Counter` in to your WordPress sidebar
or Use this [wps_visitor_counter] Shortcode anywhere in your website where you want to show visitor counter.
4. Save
5. You are done. 

== Frequently Asked Questions ==

= How to add more counter Images? =

As of now, adding another counter images, you can do to access the folder "styles/image/" on the installation of plugins

= How to use shortcode? =

Use this [wps_visitor_counter] Shortcode anywhere in your website where you want to show visitor counter.

= Does WPS Visitor Counter Support shortcode? =
Yes. WPS Visitor Counter support shortcode. Just Use this [wps_visitor_counter] Shortcode anywhere in your website where you want to show visitor counter.

= Does WPS Visitor Counter plugin gutenberg block supported? =

Yes. WPS Visitor Counter plugin gutenberg block supported.

= What is website visitor counter? =

A website visitor counter is a type of plugin which will help you to tell how much or how many people have visited your website in a certain period of time. Different types of plugins helps you to get different types data analytics support about your website traffic.  

= How can I track visitors of my website by WPS visitor Counter? =

No. We can only show your number of visitor visti your website. We cannot help you to track your website visitor. Hope in future update we will include this feature.  
  

= Is visitor counter is free? =

Most of the case the website visitor counter is free. But in case of custom modification and for custom features you need to pay for that visitor counter. These custom website visitor counter will give you a overview on Geographical location tracking and IP address locator. 

= Can I use WPS visitor counter in my Wordpress website? =

Yes. This is absolutely free to use for your wordpress website. just download it and install it to your desired wordpress website. 

= Is WPS visitor counter is bug free? =

Yes. We have tested our plugin every now and then to find bug. Recently this plugin has been test at optimum level for the assurance of the quality of our plugin.

= Can we use WPS visitor counter plugin from any country? =

Yes. You can use this plugin from anywhere in the world.

= Do we accept custom developed visitor counter on request? =

Yes, we are. We will love to do that. For any kind of customer development support please feel free to know us.

= Is this visitor counter works on all versions of wordpress? =

We are recommend you to use our visitor counter plugin at latest version of wordpress. This will help you to get the best interface and this also makes your website secured.

= Is this works as same as visitor hit counter? =

Yes. Both of them are same thing in nature and works exactly in same way. But our visitor counter is better than the others hit counter due to secured coding and state of the art testing procedure.

= Is our visitor counter works on custom made website? =

No. This is only usable in wordpress. If you need any custom visitor counter than we will make that for you

= Is this website visitor counter online works properly all the time? =

Yes. In every geological location or for any amount of visitor or in any wordpress site this visitor counter is working in same efficiency

== Screenshots ==

1. Sample display
2. Counter options
3. Image counter options

== Changelog ==


Plug-in is now compatible upto wordpress version 5.2



= 1.1 =
<ul>
<li>We have made some arbitary changes in our plugin</li>
<li>We have updated some graphical and spelling mistakes</li>
</ul>

= 1.2 =
<ul>
<li>Counter image preview updated</li>
</ul>

= 1.3 =
<ul>
<li>CSS Update</li>
<li>Error FIX</li>
</ul>

= 1.4 =
<ul>
<li>Add More Options</li>
<li>Change Defult options</li>
</ul>

= 1.4.3 =
<ul>
<li>Add Animated counter views</li>
<li>Gutenberg block support</li>
</ul>

== Arbitrary section ==

Refer Installation and FAQ section for all required information

== A brief Markdown Example ==

Ordered list:

1. Most simple plugin available so far
1. Do not remove developer plugins link

== Upgrade Notice ==
Upgrade your already installed plug-ins to latest version 1.0